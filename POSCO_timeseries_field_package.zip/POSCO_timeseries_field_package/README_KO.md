# POSCO 3S/4S 시계열 현장 검증 패키지

이 폴더는 실제 센서 원본을 포함하지 않는다. 실제 header/time 형식 기반 Synthetic smoke, 현장 실제 CSV EDA/feature extraction, 수기 전달용 compact report 코드만 포함한다.

## 1. 대상 환경

```text
Python  3.12.11
NumPy   2.5.1
pandas  3.0.5
PyTorch 2.12.1 또는 2.12.1+cu126
```

현장에 이미 승인된 wheel/패키지 저장소를 사용한다. API key, DB, 네트워크, LLM은 필요하지 않다.

## 2. 확인된 계약

```text
delimiter=;
timestamp column=time
dayfirst=true
sampling interval=1초
header column order=무관, exact column name 집합 기준
Mixing Drum=M417
Rerolling Drum=M419
온도=degC
전류=A
윤활유 유량=l/min
윤활유 압력=Bar
```

현재 `time`은 `Asia/Seoul` 로컬 설비 event time으로 가정한다. 이 의미가 맞는지 현장에서 마지막으로 확인한다.

## 3. 압축 해제 후 Synthetic smoke

패키지 최상위 폴더에서 실행한다.

```bash
python server_deploy/timeseries_field_cli.py smoke --strict-versions
```

Windows PowerShell도 같은 Python 명령을 사용한다.

화면에서 다음 6줄을 받아 적는다.

```text
TS_SMOKE=...
RUNTIME=...
3S=...
4S=...
SAFE=...
RID=...
```

필수 기대값:

```text
TS_SMOKE=VALID 및 BUILD=HEADER-NAME-MP-v3
RUNTIME의 VM:0
FFT:1
AC:1
SAFE의 ACTUAL_VALUES:0, PROD:0, TRAIN:0, THRESHOLD:0
```

## 4. 실제 CSV EDA

Linux/macOS 예시:

```bash
python server_deploy/timeseries_field_cli.py field \
  --input-3s '/secure/pims/3s/*.csv' \
  --input-4s '/secure/pims/4s/*.csv' \
  --output '/secure/output/timeseries-field'
```

Windows PowerShell 예시:

```powershell
python server_deploy/timeseries_field_cli.py field `
  --input-3s 'D:\pims\3s\*.csv' `
  --input-4s 'D:\pims\4s\*.csv' `
  --output 'D:\pims-output\timeseries-field'
```

결과:

```text
<output>/3S-eda/eda_profile.json
<output>/3S-eda/eda_daily.csv
<output>/4S-eda/eda_profile.json
<output>/4S-eda/eda_daily.csv
<output>/field_report.txt
```

Header variable 순서는 자유롭다. `time`과 센서 column name이 정확히 존재하면 name 기준으로 처리한다. 누락·추가·오탈자·중복 이름은 거부한다.

기존 output을 명시적으로 교체할 때만 `--overwrite`를 추가한다.

## 5. 실제 Feature까지 실행

EDA가 정상일 때 실행한다. 1년 데이터는 시간이 오래 걸리고 CSV feature output이 커질 수 있다.

```bash
python server_deploy/timeseries_field_cli.py field \
  --input-3s '/secure/pims/3s/*.csv' \
  --input-4s '/secure/pims/4s/*.csv' \
  --output '/secure/output/timeseries-field' \
  --parallel-scopes \
  --features \
  --workers 4 \
  --device cpu \
  --overwrite
```

`--parallel-scopes`는 3S/4S EDA를 최대 2개 process로 실행하고, `--workers 4`는 feature window를 32개 batch로 묶어 4개 CPU process에서 처리한다. 동일 disk I/O가 병목이면 `--parallel-scopes`를 빼고 비교한다. CUDA 사용 시에는 `--workers 1 --device cuda`를 사용한다. 짧은 파일은 process 시작 비용 때문에 4 workers가 더 느릴 수 있다.

Synthetic 1,200-window benchmark: single 16.56초, 4 workers 6.05초, 약 2.74배. Feature/correlation 출력 SHA는 동일했다.

확인된 설비 사건 CSV가 있을 때만 다음을 추가한다.

```text
--events-3s /secure/events/3s_events.csv
--events-4s /secure/events/4s_events.csv
```

Event CSV 형식은 `server_deploy/config/timeseries/reference_events_template.csv`를 참고한다.

## 6. 외부에서 받아 적을 최소 결과

먼저 아래 줄만 전달한다.

```text
RUNTIME=...
D|3S|...
D|4S|...
F|3S|...    # feature 실행 시
F|4S|...    # feature 실행 시
RID=...
```

센서 품질 문제가 있을 때만 해당 `S|...` 줄을 추가한다.

```text
VR이 1이 아님
MISS가 0이 아님
NN이 0이 아님
INF가 0이 아님
```

실제 분포 분석이 필요할 때는 요청받은 센서의 `S|...` 줄을 받아 적는다. Compact report에는 원본 row가 포함되지 않는다.

## 7. 안전 경계

- Synthetic waveform·사건·lag·correlation은 실제 설비 특성이 아니다.
- 실제 threshold를 추정하지 않는다.
- correlation을 인과로 해석하지 않는다.
- event가 없는 window를 정상 label로 간주하지 않는다.
- 원본 CSV와 전체 feature output은 현장 밖으로 이동하지 않는다.
- 실제 데이터 경로, 작업자 정보, 정비 문구를 외부 API로 전송하지 않는다.

## 8. 포함 파일

```text
server_deploy/timeseries_field_cli.py
server_deploy/timeseries_pipeline.py
server_deploy/timeseries_synthetic.py
server_deploy/timeseries_compact_report.py
server_deploy/config/timeseries/sinter3_wide_1s.json
server_deploy/config/timeseries/sinter4_wide_1s.json
server_deploy/config/timeseries/reference_events_template.csv
server_deploy/tests/test_timeseries_pipeline.py
requirements-timeseries-target.txt
SHA256SUMS.txt
```
