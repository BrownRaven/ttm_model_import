"""Offline staged workflow executed after validated controls arrive.

Every stage writes machine-readable artifacts and one compact receipt line. Actual Feature
rows remain inside the field environment. No stage treats an anomaly score as confirmed failure.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

from anomaly_contract import (
    ANOMALY_CONTRACT_VERSION,
    ASSET_SCOPE,
    AnomalyContractError,
    canonical_sha256,
    content_identity,
    ensure_output_directory,
    file_identity,
    parse_offset_datetime,
    require,
    require_columns,
    sha256_file,
    write_json,
)
from timeseries_event_review import IDENTIFIER_COLUMNS, METRIC_COLUMNS

WORKFLOW_CONTRACT = "PIMS-ANOMALY-VALIDATED-WORKFLOW-v1"
M0_BUNDLE_CONTRACT = "PIMS-ANOMALY-M0-BUNDLE-v2"
DEFAULT_POLICY = Path(__file__).resolve().parent / "config" / "anomaly" / "validated_workflow_policy_v1.json"
ROLES = {"TRAIN_CONTROL", "VALIDATION_CONTROL", "TEST_CONTROL", "DESCRIPTIVE_ONLY"}
MODES = {"RUNNING", "STOPPED", "STARTUP", "SHUTDOWN", "MAINTENANCE", "UNKNOWN"}
HEALTH_STATES = {"HEALTHY_STATE", "UNHEALTHY_STATE", "UNKNOWN"}


def load_policy(path: Path) -> dict[str, Any]:
    value = json.loads(path.expanduser().resolve().read_text(encoding="utf-8"))
    require(value.get("contract_version") == WORKFLOW_CONTRACT, "WORKFLOW_POLICY_VERSION_INVALID", str(path))
    return value


def _bool(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _safe(value: Any, default: str = "") -> str:
    if value is None or pd.isna(value):
        return default
    return str(value).strip()


def _receipt(prefix: str, fields: dict[str, Any], payload: dict[str, Any], output: Path) -> dict[str, Any]:
    sha = canonical_sha256(payload)
    manifest = {**payload, "receipt_sha256": sha}
    write_json(output / f"{prefix.lower()}_manifest.json", manifest)
    line = prefix + "=VALID|" + "|".join(f"{key}:{value}" for key, value in fields.items()) + f"|SHA:{sha}"
    (output / f"{prefix.lower()}_receipt.txt").write_text(line + "\n", encoding="utf-8")
    print(line)
    return manifest


def intake_controls(controls_path: Path, policy_path: Path, output_dir: Path, overwrite: bool) -> dict[str, Any]:
    output = ensure_output_directory(output_dir, overwrite)
    policy = load_policy(policy_path)
    source = controls_path.expanduser().resolve()
    frame = pd.read_csv(source, dtype=str).fillna("")
    require_columns(frame.columns, ["control_uid", "asset_id", "start_time", "end_time"], "CONTROL_HEADER_INVALID")
    require(frame["control_uid"].is_unique, "CONTROL_UID_DUPLICATE", str(source))
    normalized, issues = [], []
    for row in frame.to_dict(orient="records"):
        uid, failures = _safe(row.get("control_uid")), []
        asset = _safe(row.get("asset_id"))
        mode = _safe(row.get("operation_mode") or row.get("operation_state"), "UNKNOWN")
        mode_status = _safe(row.get("operation_mode_status") or row.get("operation_state_status"), "UNKNOWN")
        health = _safe(row.get("health_state"), "UNKNOWN")
        health_status = _safe(row.get("health_state_status"), "UNKNOWN")
        role = _safe(row.get("control_role"), "UNASSIGNED")
        epoch = _safe(row.get("maintenance_epoch") or row.get("equipment_configuration_ref"), "UNSPECIFIED")
        validation_status = _safe(row.get("validation_status"), "NOT_VALIDATED")
        fit_eligible_source = _bool(row.get("fit_eligible")) or validation_status == "VALID_FOR_BASELINE_FIT"
        try:
            start = parse_offset_datetime(_safe(row.get("start_time")), "control.start_time")
            end = parse_offset_datetime(_safe(row.get("end_time")), "control.end_time")
            if end <= start:
                failures.append("CONTROL_RANGE_INVALID")
        except AnomalyContractError as exc:
            start, end = None, None
            failures.append(exc.code)
        if asset not in ASSET_SCOPE:
            failures.append("ASSET_UNSUPPORTED")
        if mode not in MODES:
            failures.append("OPERATION_MODE_INVALID")
        if health not in HEALTH_STATES:
            failures.append("HEALTH_STATE_INVALID")
        if role not in ROLES:
            failures.append("CONTROL_ROLE_REQUIRED")
        if validation_status != "VALID_FOR_BASELINE_FIT" or not fit_eligible_source:
            failures.append("SOURCE_NOT_VALID_FOR_BASELINE_FIT")
        if mode != "RUNNING" or not mode_status.startswith("CONFIRMED"):
            failures.append("RUNNING_MODE_CONFIRMATION_REQUIRED")
        if health != "HEALTHY_STATE" or not health_status.startswith("CONFIRMED"):
            failures.append("CONTROL_HEALTH_STATE_REQUIRED")
        if epoch == "UNSPECIFIED":
            failures.append("MAINTENANCE_EPOCH_REQUIRED")
        online_eligible = _bool(row.get("online_eligible"))
        ready = not failures and role in {"TRAIN_CONTROL", "VALIDATION_CONTROL", "TEST_CONTROL"}
        item = {
            **row,
            "operation_mode": mode,
            "operation_mode_status": mode_status,
            "health_state": health,
            "health_state_status": health_status,
            "control_role": role,
            "maintenance_epoch": epoch,
            "online_eligible": str(online_eligible).lower(),
            "workflow_ready": str(ready).lower(),
            "workflow_status": "READY" if ready else "BLOCKED",
            "workflow_failure_codes": "|".join(sorted(set(failures))),
        }
        normalized.append(item)
        for failure in sorted(set(failures)):
            issues.append({"control_uid": uid, "asset_id": asset, "issue_code": failure})
    normalized_frame = pd.DataFrame(normalized)
    normalized_path = output / "normalized_validated_controls.csv"
    normalized_frame.to_csv(normalized_path, index=False)
    issues_path = output / "control_intake_issues.csv"
    pd.DataFrame(issues, columns=["control_uid", "asset_id", "issue_code"]).to_csv(issues_path, index=False)
    ready_frame = normalized_frame[normalized_frame["workflow_status"] == "READY"]
    role_counts = ready_frame["control_role"].value_counts().to_dict()
    asset_counts = ready_frame["asset_id"].value_counts().to_dict()
    role_matrix = ready_frame.groupby(["asset_id", "control_role"]).size().unstack(fill_value=0)
    epoch_counts = ready_frame.groupby("asset_id")["maintenance_epoch"].nunique().to_dict()
    minimum_train = int(policy["minimum_train_controls"])
    minimum_validation = int(policy["minimum_validation_controls"])
    model_ready_assets = []
    for asset in sorted(asset_counts):
        train_count = int(role_matrix.loc[asset].get("TRAIN_CONTROL", 0))
        validation_count = int(role_matrix.loc[asset].get("VALIDATION_CONTROL", 0))
        if train_count >= minimum_train and validation_count >= minimum_validation:
            model_ready_assets.append(asset)
    payload = {
        "contract_version": ANOMALY_CONTRACT_VERSION,
        "workflow_contract_version": WORKFLOW_CONTRACT,
        "policy_source": content_identity(policy_path),
        "controls_source": content_identity(source),
        "control_count": len(frame),
        "ready_count": len(ready_frame),
        "blocked_count": len(frame) - len(ready_frame),
        "issue_count": len(issues),
        "role_counts": role_counts,
        "role_matrix": {asset: {role: int(count) for role, count in row.items()} for asset, row in role_matrix.to_dict(orient="index").items()},
        "asset_counts": asset_counts,
        "epoch_counts": epoch_counts,
        "model_ready_assets": model_ready_assets,
        "outputs": {"normalized_sha256": sha256_file(normalized_path), "issues_sha256": sha256_file(issues_path)},
        "safety": policy["safety"],
    }
    manifest = _receipt("VC00", {"ROWS": len(frame), "READY": len(ready_frame), "BLOCKED": len(frame)-len(ready_frame), "ISSUES": len(issues)}, payload, output)
    issue_counts = pd.Series([item["issue_code"] for item in issues], dtype="object").value_counts().to_dict()
    issue_line = "VC00I|" + ("|".join(f"{code}:{count}" for code, count in sorted(issue_counts.items())) if issue_counts else "NONE")
    asset_line = "VC00A|" + ("|".join(f"{asset}:{count}" for asset, count in sorted(asset_counts.items())) if asset_counts else "NONE")
    role_lines = []
    for asset in sorted(asset_counts):
        row = role_matrix.loc[asset]
        role_lines.append(
            f"VC00R|{asset}|T:{int(row.get('TRAIN_CONTROL', 0))}|V:{int(row.get('VALIDATION_CONTROL', 0))}|"
            f"E:{int(row.get('TEST_CONTROL', 0))}|D:{int(row.get('DESCRIPTIVE_ONLY', 0))}"
        )
    epoch_line = "VC00E|" + "|".join(f"{asset}:{count}" for asset, count in sorted(epoch_counts.items()))
    gate_line = "VC00G|MODEL_READY:" + ("|".join(model_ready_assets) if model_ready_assets else "NONE")
    compact_lines = [issue_line, asset_line, *role_lines, epoch_line, gate_line]
    (output / "vc00_compact_issues.txt").write_text("\n".join(compact_lines) + "\n", encoding="utf-8")
    for line in compact_lines:
        print(line)
    return manifest


def _load_ready_controls(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path, dtype=str).fillna("")
    require_columns(frame.columns, ["control_uid", "asset_id", "start_time", "end_time", "workflow_status", "control_role", "maintenance_epoch"], "NORMALIZED_CONTROL_HEADER_INVALID")
    ready = frame[frame["workflow_status"] == "READY"].copy()
    require(not ready.empty, "NO_READY_CONTROLS", str(path))
    return ready


def extract_control_features(
    controls_path: Path, features_3s: Path, features_4s: Path, policy_path: Path,
    output_dir: Path, chunksize: int, overwrite: bool,
) -> dict[str, Any]:
    output = ensure_output_directory(output_dir, overwrite)
    policy = load_policy(policy_path)
    controls = _load_ready_controls(controls_path)
    feature_files = {"3S": features_3s.expanduser().resolve(), "4S": features_4s.expanduser().resolve()}
    selected_chunks, scanned = [], 0
    for scope, source in feature_files.items():
        header = pd.read_csv(source, nrows=0).columns.tolist()
        usecols = [column for column in [*IDENTIFIER_COLUMNS, *METRIC_COLUMNS] if column in header]
        require_columns(usecols, ["window_start", "window_end", "asset_id", "sensor_uid", "quality_status"], "FEATURE_HEADER_INVALID")
        scope_controls = controls[controls["asset_id"].map(ASSET_SCOPE) == scope]
        for chunk in pd.read_csv(source, usecols=usecols, chunksize=chunksize, low_memory=False):
            scanned += len(chunk)
            starts = pd.to_datetime(chunk["window_start"], errors="coerce", utc=True)
            ends = pd.to_datetime(chunk["window_end"], errors="coerce", utc=True)
            require(not starts.isna().any() and not ends.isna().any(), "FEATURE_TIME_INVALID", str(source))
            midpoints = starts + (ends-starts)/2
            for control in scope_controls.to_dict(orient="records"):
                begin = pd.Timestamp(control["start_time"]).tz_convert("UTC")
                finish = pd.Timestamp(control["end_time"]).tz_convert("UTC")
                mask = (chunk["asset_id"] == control["asset_id"]) & (midpoints >= begin) & (midpoints < finish)
                if not mask.any():
                    continue
                selected = chunk.loc[mask].copy()
                for position, (name, value) in enumerate((
                    ("control_uid", control["control_uid"]), ("control_role", control["control_role"]),
                    ("maintenance_epoch", control["maintenance_epoch"]), ("operation_mode", control["operation_mode"]),
                    ("health_state", control["health_state"]),
                )):
                    selected.insert(position, name, value)
                selected_chunks.append(selected)
    require(bool(selected_chunks), "CONTROL_FEATURES_EMPTY", "No Feature rows matched controls")
    selected = pd.concat(selected_chunks, ignore_index=True)
    output_path = output / "control_feature_windows.csv"
    selected.to_csv(output_path, index=False)
    summary = selected.groupby(["control_uid", "control_role", "asset_id", "maintenance_epoch"]).agg(
        feature_rows=("sensor_uid", "size"), unique_windows=("window_start", "nunique"),
        sensor_count=("sensor_uid", "nunique"), quality_pass_ratio=("quality_status", lambda values: float((values == "PASS").mean())),
    ).reset_index()
    summary_path = output / "control_feature_inventory.csv"
    summary.to_csv(summary_path, index=False)
    dq_blocked = int((selected["quality_status"] != "PASS").sum())
    payload = {
        "contract_version": WORKFLOW_CONTRACT, "controls_source": content_identity(controls_path),
        "feature_sources": {scope: file_identity(path, include_sha256=False) for scope,path in feature_files.items()},
        "scanned_rows": scanned, "selected_rows": len(selected), "control_count": selected["control_uid"].nunique(),
        "dq_blocked_rows": dq_blocked,
        "outputs": {"windows_sha256": sha256_file(output_path), "inventory_sha256": sha256_file(summary_path)},
        "safety": policy["safety"],
    }
    return _receipt("VC02", {"SCANNED": scanned, "SELECTED": len(selected), "CONTROLS": selected["control_uid"].nunique(), "DQ": dq_blocked}, payload, output)


def control_stability(control_features: Path, policy_path: Path, output_dir: Path, overwrite: bool) -> dict[str, Any]:
    output = ensure_output_directory(output_dir, overwrite)
    policy = load_policy(policy_path)
    frame = pd.read_csv(control_features, low_memory=False)
    required = ["control_uid", "control_role", "asset_id", "maintenance_epoch", "sensor_uid", "quality_status"]
    require_columns(frame.columns, required, "CONTROL_FEATURE_HEADER_INVALID")
    quality_ratios = frame.groupby("control_uid")["quality_status"].apply(lambda values: float((values == "PASS").mean()))
    require(
        bool((quality_ratios >= float(policy["minimum_quality_pass_ratio"])).all()),
        "CONTROL_FEATURE_QUALITY_RATIO_BELOW_MINIMUM", str(control_features),
    )
    frame = frame[frame["quality_status"] == "PASS"].copy()
    metrics = [metric for metric in policy["candidate_metrics"] if metric in frame]
    rows = []
    keys = ["control_uid", "control_role", "asset_id", "maintenance_epoch", "sensor_uid", "measurement_type", "unit"]
    for group_key, group in frame.groupby(keys, dropna=False, sort=False):
        identity = dict(zip(keys, group_key))
        for metric in metrics:
            values = pd.to_numeric(group[metric], errors="coerce").dropna()
            median = float(values.median()) if not values.empty else math.nan
            mad = float((values-median).abs().median()) if not values.empty else math.nan
            rows.append({**identity, "metric": metric, "value_count": len(values), "median": median, "mad": mad,
                         "robust_scale": 1.4826*mad if math.isfinite(mad) else math.nan,
                         "p05": float(values.quantile(.05)) if not values.empty else math.nan,
                         "p95": float(values.quantile(.95)) if not values.empty else math.nan})
    detail = pd.DataFrame(rows)
    detail_path = output / "control_sensor_metric_statistics.csv"
    detail.to_csv(detail_path,index=False)
    cross_rows=[]
    cross_keys=["asset_id","maintenance_epoch","sensor_uid","measurement_type","unit","metric"]
    for key, group in detail.groupby(cross_keys,dropna=False,sort=False):
        identity=dict(zip(cross_keys,key)); scales=group["robust_scale"].replace(0,np.nan).dropna()
        pooled=float(scales.median()) if not scales.empty else 0.0
        median_shift=float(group["median"].max()-group["median"].min()) if len(group) else math.nan
        normalized=median_shift/pooled if pooled>0 else math.nan
        train_count=int((group["control_role"]=="TRAIN_CONTROL").sum())
        status="STABLE_CONTROL"
        if pooled<=0: status="ZERO_SCALE_REVIEW_REQUIRED"
        elif normalized>float(policy["maximum_control_median_shift_in_pooled_mad"]): status="DRIFT_REVIEW_REQUIRED"
        cross_rows.append({**identity,"control_count":group["control_uid"].nunique(),"train_control_count":train_count,
                           "pooled_robust_scale":pooled,"control_median_shift":median_shift,
                           "normalized_median_shift":normalized,"stability_status":status})
    cross=pd.DataFrame(cross_rows); cross_path=output/"control_stability_report.csv"; cross.to_csv(cross_path,index=False)
    counts=cross["stability_status"].value_counts().to_dict()
    payload={"contract_version":WORKFLOW_CONTRACT,"source":content_identity(control_features),"metric_rows":len(detail),
             "feature_candidates":len(cross),"status_counts":counts,
             "outputs":{"detail_sha256":sha256_file(detail_path),"stability_sha256":sha256_file(cross_path)},"safety":policy["safety"]}
    return _receipt("VC03", {"FEATURES":len(cross),"STABLE":counts.get("STABLE_CONTROL",0),"DRIFT":counts.get("DRIFT_REVIEW_REQUIRED",0),"ZERO":counts.get("ZERO_SCALE_REVIEW_REQUIRED",0)},payload,output)


def select_features(stability_path: Path, policy_path: Path, output_dir: Path, overwrite: bool) -> dict[str,Any]:
    output=ensure_output_directory(output_dir,overwrite); policy=load_policy(policy_path)
    frame=pd.read_csv(stability_path)
    require_columns(frame.columns,["asset_id","maintenance_epoch","sensor_uid","metric","train_control_count","stability_status"],"STABILITY_HEADER_INVALID")
    selected=(frame["stability_status"]=="STABLE_CONTROL") & (frame["train_control_count"]>=int(policy["minimum_train_controls"]))
    result=frame.copy(); result["selected"]=selected; result["selection_status"]=np.where(selected,"SELECTED_M0_CANDIDATE","EXCLUDED_STABILITY_OR_CONTROL_COUNT")
    path=output/"selected_feature_contract.csv"; result.to_csv(path,index=False)
    payload={"contract_version":WORKFLOW_CONTRACT,"source":content_identity(stability_path),"candidate_count":len(result),
             "selected_count":int(selected.sum()),"output_sha256":sha256_file(path),"safety":policy["safety"]}
    return _receipt("VC04",{"CAND":len(result),"SELECTED":int(selected.sum()),"EXCLUDED":int((~selected).sum())},payload,output)


def fit_m0(control_features: Path, feature_contract: Path, policy_path: Path, output_dir: Path, overwrite: bool) -> dict[str,Any]:
    output=ensure_output_directory(output_dir,overwrite); policy=load_policy(policy_path)
    features=pd.read_csv(feature_contract); features=features[features["selected"].map(_bool)]
    require(not features.empty,"NO_SELECTED_FEATURES",str(feature_contract))
    data=pd.read_csv(control_features,low_memory=False)
    require_columns(data.columns,["control_role","quality_status"],"CONTROL_FEATURE_HEADER_INVALID")
    train=data[(data["control_role"]=="TRAIN_CONTROL") & (data["quality_status"]=="PASS")]
    params=[]
    for _, spec in features.iterrows():
        mask=(train["asset_id"]==spec["asset_id"]) & (train["maintenance_epoch"]==spec["maintenance_epoch"]) & (train["sensor_uid"]==spec["sensor_uid"])
        values=pd.to_numeric(train.loc[mask,spec["metric"]],errors="coerce").dropna()
        center=float(values.median()) if not values.empty else math.nan; mad=float((values-center).abs().median()) if not values.empty else math.nan; scale=1.4826*mad if math.isfinite(mad) else 0
        status="FIT" if len(values)>=int(policy["minimum_baseline_value_count"]) and scale>0 else "BLOCKED_ZERO_SCALE_OR_COUNT"
        params.append({"asset_id":spec["asset_id"],"maintenance_epoch":spec["maintenance_epoch"],"sensor_uid":spec["sensor_uid"],"metric":spec["metric"],"center":center,"scale":scale,"value_count":len(values),"fit_status":status})
    result=pd.DataFrame(params); path=output/"baseline_parameters.csv"; result.to_csv(path,index=False)
    fit_count=int((result["fit_status"]=="FIT").sum())
    payload={"contract_version":WORKFLOW_CONTRACT,"controls_source":content_identity(control_features),"feature_contract_source":content_identity(feature_contract),
             "parameter_count":len(result),"fit_count":fit_count,"output_sha256":sha256_file(path),"safety":policy["safety"]}
    return _receipt("VC06",{"PARAMS":len(result),"FIT":fit_count,"BLOCKED":len(result)-fit_count},payload,output)


def score_review(input_path: Path, parameters_path: Path, input_kind: str, output_dir: Path, overwrite: bool) -> dict[str,Any]:
    output=ensure_output_directory(output_dir,overwrite)
    data=pd.read_csv(input_path,low_memory=False)
    require_columns(data.columns,["quality_status"],"SCORE_INPUT_QUALITY_STATUS_REQUIRED")
    data=data[data["quality_status"]=="PASS"].copy()
    params=pd.read_csv(parameters_path); params=params[params["fit_status"]=="FIT"]
    require(not params.empty,"NO_FIT_PARAMETERS",str(parameters_path))
    rows=[]
    group_identity=[column for column in ("control_uid","control_role","occurrence_uid","event_uid","phase","event_time_precision","label_status") if column in data]
    for _, param in params.iterrows():
        mask=(data["asset_id"]==param["asset_id"]) & (data["sensor_uid"]==param["sensor_uid"])
        if "maintenance_epoch" in data and input_kind=="control": mask &= data["maintenance_epoch"]==param["maintenance_epoch"]
        values=pd.to_numeric(data.loc[mask,param["metric"]],errors="coerce"); indexes=values.dropna().index
        for index in indexes:
            source=data.loc[index]
            item={column:source[column] for column in ["window_start","window_end","asset_id","sensor_uid",*group_identity] if column in source}
            item.update({"maintenance_epoch":param["maintenance_epoch"],"metric":param["metric"],"feature_score":abs(float(values.loc[index])-param["center"])/param["scale"]})
            rows.append(item)
    detail=pd.DataFrame(rows); require(not detail.empty,"SCORE_ROWS_EMPTY",str(input_path))
    detail_path=output/f"{input_kind}_feature_scores.csv"; detail.to_csv(detail_path,index=False)
    keys=[column for column in ["window_start","window_end","asset_id","sensor_uid","maintenance_epoch",*group_identity] if column in detail]
    sensor=detail.groupby(keys,dropna=False).agg(sensor_score=("feature_score","max"),top_metric=("metric",lambda values: values.iloc[detail.loc[values.index,"feature_score"].argmax()])).reset_index()
    sensor_path=output/f"{input_kind}_sensor_scores.csv"; sensor.to_csv(sensor_path,index=False)
    payload={"contract_version":WORKFLOW_CONTRACT,"input_kind":input_kind,"source":content_identity(input_path),"parameters":content_identity(parameters_path),
             "feature_score_rows":len(detail),"sensor_score_rows":len(sensor),"outputs":{"detail_sha256":sha256_file(detail_path),"sensor_sha256":sha256_file(sensor_path)},
             "safety":{"anomaly_score_is_confirmed_failure":False,"production_decision_allowed":False}}
    return _receipt("VC07",{"KIND":input_kind,"FEATURE":len(detail),"SENSOR":len(sensor)},payload,output)


def select_threshold(control_scores_path: Path, policy_path: Path, output_dir: Path, overwrite: bool) -> dict[str,Any]:
    output=ensure_output_directory(output_dir,overwrite); policy=load_policy(policy_path); data=pd.read_csv(control_scores_path)
    require_columns(data.columns,["control_role","asset_id","maintenance_epoch","window_start","sensor_score"],"CONTROL_SCORE_HEADER_INVALID")
    validation=data[data["control_role"]=="VALIDATION_CONTROL"]
    require(not validation.empty,"VALIDATION_CONTROL_SCORES_REQUIRED",str(control_scores_path))
    asset=validation.groupby(["asset_id","maintenance_epoch","window_start"],dropna=False)["sensor_score"].max().reset_index(name="asset_score")
    rows=[]; quantile=float(policy["threshold_validation_quantile"])
    for key,group in asset.groupby(["asset_id","maintenance_epoch"]):
        threshold=float(group["asset_score"].quantile(quantile)); alerts=int((group["asset_score"]>threshold).sum()); days=max(group["window_start"].nunique()*5/1440,1/288)
        rows.append({"asset_id":key[0],"maintenance_epoch":key[1],"threshold":threshold,"quantile":quantile,"validation_windows":len(group),"validation_alerts":alerts,"false_alerts_per_day":alerts/days})
    result=pd.DataFrame(rows); path=output/"selected_threshold_policy.csv"; result.to_csv(path,index=False)
    payload={"contract_version":WORKFLOW_CONTRACT,"source":content_identity(control_scores_path),"threshold_count":len(result),"output_sha256":sha256_file(path),"safety":policy["safety"]}
    return _receipt("VC08",{"ASSETS":len(result),"VAL_WINDOWS":len(asset),"ALERTS":int(result["validation_alerts"].sum())},payload,output)


def evaluate_events(event_scores_path: Path, thresholds_path: Path, output_dir: Path, overwrite: bool) -> dict[str,Any]:
    output=ensure_output_directory(output_dir,overwrite); data=pd.read_csv(event_scores_path); thresholds=pd.read_csv(thresholds_path)
    require_columns(data.columns,["occurrence_uid","event_uid","phase","asset_id","window_start","sensor_score"],"EVENT_SCORE_HEADER_INVALID")
    require(thresholds.groupby("asset_id").size().max() == 1,"MULTIPLE_EPOCH_EVENT_MAPPING_REQUIRED","Map event to maintenance_epoch before evaluation")
    threshold_map=thresholds.set_index("asset_id")["threshold"].to_dict()
    asset=data.groupby(["occurrence_uid","event_uid","phase","event_time_precision","asset_id","window_start"],dropna=False)["sensor_score"].max().reset_index(name="asset_score")
    asset["threshold"]=asset["asset_id"].map(threshold_map); asset["alert"]=asset["asset_score"]>asset["threshold"]
    rows=[]
    for occurrence,group in asset.groupby("occurrence_uid",sort=False):
        pre=group[group["phase"].astype(str).str.startswith("PRE_")]; alerts=pre[pre["alert"]]
        precision=str(group.iloc[0]["event_time_precision"]); eligible=precision=="EXACT_MINUTE"
        rows.append({"occurrence_uid":occurrence,"event_uid":group.iloc[0]["event_uid"],"asset_id":group.iloc[0]["asset_id"],"time_precision":precision,
                     "lead_time_eligible":eligible,"pre_window_count":len(pre),"pre_alert_count":len(alerts),
                     "first_pre_alert":alerts["window_start"].min() if not alerts.empty else None,
                     "detection_status":"PRE_ALERT_DETECTED" if not alerts.empty else "NO_PRE_ALERT"})
    result=pd.DataFrame(rows); path=output/"event_detection_results.csv"; result.to_csv(path,index=False); asset_path=output/"event_asset_scores.csv"; asset.to_csv(asset_path,index=False)
    payload={"contract_version":WORKFLOW_CONTRACT,"scores_source":content_identity(event_scores_path),"threshold_source":content_identity(thresholds_path),
             "occurrence_count":len(result),"detected_count":int((result["detection_status"]=="PRE_ALERT_DETECTED").sum()),
             "outputs":{"results_sha256":sha256_file(path),"scores_sha256":sha256_file(asset_path)},
             "safety":{"detection_is_confirmed_failure":False,"causality_inferred":False,"production_decision_allowed":False}}
    return _receipt("VC09",{"OCC":len(result),"DETECTED":int((result["detection_status"]=="PRE_ALERT_DETECTED").sum()),"NO_PRE":int((result["detection_status"]=="NO_PRE_ALERT").sum())},payload,output)


def compact_review(run_dir: Path, event_phase_windows: Path | None, output_file: Path, reference_phases: Path | None = None) -> None:
    root=run_dir.expanduser().resolve()
    controls=pd.read_csv(root/"vc02"/"control_feature_windows.csv",low_memory=False)
    stability=pd.read_csv(root/"vc03"/"control_stability_report.csv")
    parameters=pd.read_csv(root/"vc06"/"baseline_parameters.csv")
    thresholds=pd.read_csv(root/"vc08"/"selected_threshold_policy.csv")
    events=pd.read_csv(root/"vc09"/"event_detection_results.csv")
    lines=[]
    for asset,group in controls.groupby("asset_id",sort=True):
        dq=int((group["quality_status"]!="PASS").sum())
        lines.append(f"VC10Q|{asset}|ROWS:{len(group)}|DQ:{dq}")
    for asset,group in stability.groupby("asset_id",sort=True):
        counts=group["stability_status"].value_counts()
        lines.append(f"VC10S|{asset}|STABLE:{int(counts.get('STABLE_CONTROL',0))}|DRIFT:{int(counts.get('DRIFT_REVIEW_REQUIRED',0))}|ZERO:{int(counts.get('ZERO_SCALE_REVIEW_REQUIRED',0))}")
    for asset,group in parameters.groupby("asset_id",sort=True):
        counts=group["fit_status"].value_counts()
        lines.append(f"VC10B|{asset}|FIT:{int(counts.get('FIT',0))}|BLOCKED:{int((group['fit_status']!='FIT').sum())}")
    for _,row in thresholds.sort_values(["asset_id","maintenance_epoch"]).iterrows():
        lines.append(f"VC10T|{row['asset_id']}|VALW:{int(row['validation_windows'])}|ALERTS:{int(row['validation_alerts'])}|FAD:{float(row['false_alerts_per_day']):.4f}")
    for asset,group in events.groupby("asset_id",sort=True):
        detected=int((group["detection_status"]=="PRE_ALERT_DETECTED").sum())
        lead=int(group["lead_time_eligible"].map(_bool).sum())
        lines.append(f"VC10E|{asset}|OCC:{len(group)}|DETECTED:{detected}|NO_PRE:{len(group)-detected}|LEAD_ELIG:{lead}")
    no_pre=sorted(events.loc[events["detection_status"]!="PRE_ALERT_DETECTED","occurrence_uid"].astype(str).unique())
    lines.append("VC10N|NO_PRE:"+("|".join(no_pre) if no_pre else "NONE"))
    expected_count=None; missing=[]
    expected_source = reference_phases if reference_phases is not None else event_phase_windows
    if expected_source is not None:
        expected=pd.read_csv(expected_source,usecols=["occurrence_uid"])["occurrence_uid"].astype(str).unique().tolist()
        observed=set(events["occurrence_uid"].astype(str)); missing=sorted(set(expected)-observed); expected_count=len(expected)
        source_kind="REFERENCE_PHASES" if reference_phases is not None else "EVENT_PHASE_WINDOWS"
        lines.append(f"VC10C|SOURCE:{source_kind}|EXPECTED:{expected_count}|EVALUATED:{events['occurrence_uid'].nunique()}|MISSING:{len(missing)}")
        lines.append("VC10X|MISSING_UID:"+("|".join(missing) if missing else "NONE"))
    payload={"contract_version":WORKFLOW_CONTRACT,"control_rows":len(controls),"stability_rows":len(stability),
             "parameter_rows":len(parameters),"threshold_rows":len(thresholds),"evaluated_occurrences":events["occurrence_uid"].nunique(),
             "expected_occurrences":expected_count,"missing_occurrences":missing,"detail_lines":lines,
             "safety":{"raw_values_included":False,"threshold_values_included":False,"score_values_included":False,"production_decision_allowed":False}}
    sha=canonical_sha256(payload)
    header=f"VC10=REVIEW|ASSETS:{thresholds['asset_id'].nunique()}|OCC:{events['occurrence_uid'].nunique()}|SHA:{sha}"
    report="\n".join([header,*lines])+"\n"
    output_file.expanduser().resolve().parent.mkdir(parents=True,exist_ok=True)
    output_file.expanduser().resolve().write_text(report,encoding="utf-8")
    print(report,end="")


def _alert_runs(times: pd.Series, alerts: pd.Series) -> list[int]:
    ordered=pd.DataFrame({"time":pd.to_datetime(times,utc=True),"alert":alerts.map(_bool)}).sort_values("time")
    runs=[]; current=0; previous_time=None
    for row in ordered.itertuples(index=False):
        contiguous=previous_time is not None and row.time-previous_time<=pd.Timedelta(minutes=5)
        if row.alert:
            current=current+1 if contiguous and current else 1
        elif current:
            runs.append(current); current=0
        previous_time=row.time
    if current: runs.append(current)
    return runs


def _alert_run_stats(times: pd.Series, alerts: pd.Series) -> tuple[int,int,int]:
    runs=_alert_runs(times,alerts)
    return len(runs), max(runs,default=0), sum(run>=2 for run in runs)


def holdout_review(run_dir: Path, event_phase_windows: Path, reference_phases: Path, output_file: Path) -> None:
    root=run_dir.expanduser().resolve()
    control_scores=pd.read_csv(root/"score-control"/"control_sensor_scores.csv",low_memory=False)
    event_scores=pd.read_csv(root/"score-event"/"event_sensor_scores.csv",low_memory=False)
    thresholds=pd.read_csv(root/"vc08"/"selected_threshold_policy.csv")
    parameters=pd.read_csv(root/"vc06"/"baseline_parameters.csv")
    threshold_map={(row.asset_id,row.maintenance_epoch):float(row.threshold) for row in thresholds.itertuples()}
    control=control_scores.groupby(["asset_id","maintenance_epoch","control_role","control_uid","window_start"],dropna=False)["sensor_score"].max().reset_index(name="asset_score")
    control["threshold"]=[threshold_map.get((row.asset_id,row.maintenance_epoch),math.nan) for row in control.itertuples()]
    control["alert"]=control["asset_score"]>control["threshold"]
    lines=[]
    for (asset,role),group in control.groupby(["asset_id","control_role"],sort=True):
        if role not in {"VALIDATION_CONTROL","TEST_CONTROL"}: continue
        episodes=max_run=persistent=0
        for _,control_group in group.groupby("control_uid"):
            ep,mr,pe=_alert_run_stats(control_group["window_start"],control_group["alert"])
            episodes+=ep; max_run=max(max_run,mr); persistent+=pe
        windows=len(group); alert_windows=int(group["alert"].sum()); days=max(windows*5/1440,1/288)
        lines.append(f"VC11H|{asset}|ROLE:{role}|W:{windows}|ALERTW:{alert_windows}|FAD:{alert_windows/days:.4f}|EP:{episodes}|P2EP:{persistent}|MAXRUN:{max_run}")
    event_thresholds=thresholds.groupby("asset_id")["threshold"].agg(list).to_dict()
    event=event_scores.groupby(["occurrence_uid","event_uid","event_time_precision","asset_id","phase","window_start"],dropna=False)["sensor_score"].max().reset_index(name="asset_score")
    event["threshold"]=[values[0] if len(values)==1 else math.nan for values in event["asset_id"].map(event_thresholds)]
    event["alert"]=event["asset_score"]>event["threshold"]
    for occurrence,group in event.groupby("occurrence_uid",sort=True):
        pre=group[group["phase"].astype(str).str.startswith("PRE_")]
        ep,mr,pe=_alert_run_stats(pre["window_start"],pre["alert"])
        lines.append(f"VC11E|{occurrence}|ASSET:{group.iloc[0]['asset_id']}|PREC:{group.iloc[0]['event_time_precision']}|PREW:{len(pre)}|ALERTW:{int(pre['alert'].sum())}|EP:{ep}|P2EP:{pe}|MAXRUN:{mr}")
    blocked=parameters[parameters["fit_status"]!="FIT"]
    for row in blocked.sort_values(["asset_id","sensor_uid","metric"]).itertuples():
        lines.append(f"VC11B|{row.asset_id}|SENSOR:{row.sensor_uid}|METRIC:{row.metric}|COUNT:{int(row.value_count)}|STATUS:{row.fit_status}")
    reference=pd.read_csv(reference_phases,usecols=["occurrence_uid"])["occurrence_uid"].astype(str).unique()
    phase=pd.read_csv(event_phase_windows,usecols=["occurrence_uid"])["occurrence_uid"].astype(str).unique()
    scored=set(event_scores["occurrence_uid"].astype(str)); phase_set=set(phase)
    for occurrence in sorted(set(reference)-scored):
        reason="NO_EVENT_PHASE_FEATURE_ROWS" if occurrence not in phase_set else "NO_FITTABLE_EVENT_SCORE_ROWS"
        lines.append(f"VC11X|{occurrence}|REASON:{reason}")
    payload={"contract_version":WORKFLOW_CONTRACT,"detail_lines":lines,"safety":{"threshold_values_included":False,"score_values_included":False,
             "test_data_used_for_threshold_selection":False,"event_data_used_for_threshold_selection":False,"production_decision_allowed":False}}
    sha=canonical_sha256(payload); header=f"VC11=HOLDOUT_REVIEW|LINES:{len(lines)}|SHA:{sha}"
    report="\n".join([header,*lines])+"\n"; destination=output_file.expanduser().resolve(); destination.parent.mkdir(parents=True,exist_ok=True); destination.write_text(report,encoding="utf-8"); print(report,end="")


def poc_policy_review(run_dir: Path, policy_path: Path, output_dir: Path, overwrite: bool) -> dict[str,Any]:
    output=ensure_output_directory(output_dir,overwrite); policy=load_policy(policy_path); persistence=policy["poc_persistence_policy"]
    root=run_dir.expanduser().resolve(); control_scores=pd.read_csv(root/"score-control"/"control_sensor_scores.csv",low_memory=False)
    event_scores=pd.read_csv(root/"score-event"/"event_sensor_scores.csv",low_memory=False); thresholds=pd.read_csv(root/"vc08"/"selected_threshold_policy.csv")
    threshold_map={(row.asset_id,row.maintenance_epoch):float(row.threshold) for row in thresholds.itertuples()}
    control=control_scores.groupby(["asset_id","maintenance_epoch","control_role","control_uid","window_start"],dropna=False)["sensor_score"].max().reset_index(name="asset_score")
    control["threshold"]=[threshold_map.get((row.asset_id,row.maintenance_epoch),math.nan) for row in control.itertuples()]; control["alert"]=control["asset_score"]>control["threshold"]
    candidates=[int(value) for value in persistence["candidate_min_consecutive_windows"]]; maximum_validation=float(persistence["maximum_validation_episodes_per_7_asset_days"]); maximum_test=float(persistence["maximum_test_episodes_per_7_asset_days"])
    candidate_rows=[]; selected={}
    for asset,asset_group in control.groupby("asset_id",sort=True):
        for minimum_run in candidates:
            result={"asset_id":asset,"minimum_consecutive_windows":minimum_run}
            for role,prefix in (("VALIDATION_CONTROL","validation"),("TEST_CONTROL","test")):
                role_group=asset_group[asset_group["control_role"]==role]; episodes=0
                for _,group in role_group.groupby("control_uid"): episodes+=sum(run>=minimum_run for run in _alert_runs(group["window_start"],group["alert"]))
                days=len(role_group)*5/1440; normalized=episodes*7/days if days>0 else math.nan
                result[f"{prefix}_windows"]=len(role_group); result[f"{prefix}_episodes"]=episodes; result[f"{prefix}_episodes_per_7_days"]=normalized
            result["validation_pass"]=result["validation_episodes_per_7_days"]<=maximum_validation
            candidate_rows.append(result)
        eligible=[row for row in candidate_rows if row["asset_id"]==asset and row["validation_pass"]]
        if eligible: selected[asset]=min(eligible,key=lambda row:row["minimum_consecutive_windows"])
    require(len(selected)==control["asset_id"].nunique(),"POC_PERSISTENCE_POLICY_NOT_SELECTABLE",str(run_dir))
    selected_rows=[]
    for asset,row in selected.items():
        test_pass=row["test_episodes_per_7_days"]<=maximum_test
        selected_rows.append({**row,"test_pass":test_pass,"holdout_status":"PASS" if test_pass else "FAIL_NO_RESELECTION"})
    selected_frame=pd.DataFrame(selected_rows).sort_values("asset_id"); selected_path=output/"poc_selected_persistence_policy.csv"; selected_frame.to_csv(selected_path,index=False)
    candidate_frame=pd.DataFrame(candidate_rows).sort_values(["asset_id","minimum_consecutive_windows"]); candidate_path=output/"poc_persistence_candidates.csv"; candidate_frame.to_csv(candidate_path,index=False)
    event_thresholds=thresholds.groupby("asset_id")["threshold"].agg(list).to_dict(); event=event_scores.groupby(["occurrence_uid","event_uid","event_time_precision","asset_id","phase","window_start"],dropna=False)["sensor_score"].max().reset_index(name="asset_score")
    event["threshold"]=[values[0] if len(values)==1 else math.nan for values in event["asset_id"].map(event_thresholds)]; event["alert"]=event["asset_score"]>event["threshold"]
    event_rows=[]
    for occurrence,group in event.groupby("occurrence_uid",sort=True):
        asset=group.iloc[0]["asset_id"]; minimum_run=int(selected[asset]["minimum_consecutive_windows"]); pre=group[group["phase"].astype(str).str.startswith("PRE_")]; runs=_alert_runs(pre["window_start"],pre["alert"]); detected=any(run>=minimum_run for run in runs); precision=group.iloc[0]["event_time_precision"]
        event_rows.append({"occurrence_uid":occurrence,"asset_id":asset,"event_time_precision":precision,"minimum_consecutive_windows":minimum_run,"persistent_episode_count":sum(run>=minimum_run for run in runs),"maximum_run":max(runs,default=0),"poc_detection_status":"PERSISTENT_PRE_ALERT" if detected else "NO_PERSISTENT_PRE_ALERT","lead_time_eligible":precision=="EXACT_MINUTE"})
    event_frame=pd.DataFrame(event_rows); event_path=output/"poc_event_persistence_results.csv"; event_frame.to_csv(event_path,index=False)
    lines=[]
    for row in selected_frame.itertuples(): lines.append(f"VC12P|{row.asset_id}|RUN:{row.minimum_consecutive_windows}|V7:{row.validation_episodes_per_7_days:.4f}|T7:{row.test_episodes_per_7_days:.4f}|HOLDOUT:{row.holdout_status}")
    exact=event_frame[event_frame["lead_time_eligible"]]
    for asset,group in exact.groupby("asset_id",sort=True): lines.append(f"VC12E|{asset}|EXACT:{len(group)}|PERSIST_DET:{int((group['poc_detection_status']=='PERSISTENT_PRE_ALERT').sum())}|NO_PERSIST:{int((group['poc_detection_status']!='PERSISTENT_PRE_ALERT').sum())}")
    failed=int((selected_frame["holdout_status"]!="PASS").sum()); payload={"contract_version":WORKFLOW_CONTRACT,"policy_source":content_identity(policy_path),"run_source":str(root.name),"selected_asset_count":len(selected_frame),"holdout_failed_assets":failed,"exact_event_count":len(exact),"exact_persistent_detection_count":int((exact["poc_detection_status"]=="PERSISTENT_PRE_ALERT").sum()),"detail_lines":lines,"outputs":{"candidates_sha256":sha256_file(candidate_path),"selected_sha256":sha256_file(selected_path),"events_sha256":sha256_file(event_path)},"safety":persistence}
    manifest=_receipt("VC12",{"ASSETS":len(selected_frame),"HOLDOUT_FAIL":failed,"EXACT":len(exact),"PERSIST_DET":int((exact["poc_detection_status"]=="PERSISTENT_PRE_ALERT").sum())},payload,output)
    detail="\n".join(lines)+"\n"; (output/"vc12_compact_detail.txt").write_text(detail,encoding="utf-8"); print(detail,end=""); return manifest


def freeze_m0_bundle(run_dir: Path, vc12_dir: Path, policy_path: Path, output_dir: Path, overwrite: bool) -> dict[str,Any]:
    output=ensure_output_directory(output_dir,overwrite); root=run_dir.expanduser().resolve(); vc12=vc12_dir.expanduser().resolve(); policy=load_policy(policy_path)
    params_path=root/"vc06"/"baseline_parameters.csv"; thresholds_path=root/"vc08"/"selected_threshold_policy.csv"; persistence_path=vc12/"poc_selected_persistence_policy.csv"; features_path=root/"vc04"/"selected_feature_contract.csv"; controls_path=root/"vc00"/"normalized_validated_controls.csv"
    params=pd.read_csv(params_path); params=params[params["fit_status"]=="FIT"].copy(); thresholds=pd.read_csv(thresholds_path); persistence=pd.read_csv(persistence_path); features=pd.read_csv(features_path); controls=pd.read_csv(controls_path)
    require(not params.empty,"M0_FIT_PARAMETERS_REQUIRED",str(params_path)); require((persistence["holdout_status"]=="PASS").all(),"M0_HOLDOUT_PASS_REQUIRED",str(persistence_path))
    models=[]
    for threshold in thresholds.sort_values(["asset_id","maintenance_epoch"]).itertuples():
        selected=persistence[persistence["asset_id"]==threshold.asset_id]; require(len(selected)==1,"M0_PERSISTENCE_POLICY_REQUIRED",str(threshold.asset_id)); selected_row=selected.iloc[0]
        subset=params[(params["asset_id"]==threshold.asset_id)&(params["maintenance_epoch"]==threshold.maintenance_epoch)]
        require(not subset.empty,"M0_ASSET_PARAMETERS_REQUIRED",str(threshold.asset_id))
        feature_rows=[]
        for row in subset.sort_values(["sensor_uid","metric"]).itertuples():
            feature_rows.append({"sensor_uid":str(row.sensor_uid),"metric":str(row.metric),"center":float(row.center),"robust_scale":float(row.scale),"value_count":int(row.value_count)})
        asset_controls=controls[(controls["asset_id"]==threshold.asset_id)&(controls["maintenance_epoch"]==threshold.maintenance_epoch)].copy(); require(not asset_controls.empty,"M0_CONTROL_DEPENDENCIES_REQUIRED",str(threshold.asset_id)); asset_controls["end_utc"]=pd.to_datetime(asset_controls["end_time"],utc=True)
        fit_controls=asset_controls[asset_controls["control_role"].isin(["TRAIN_CONTROL","VALIDATION_CONTROL"])]; require(not fit_controls.empty,"M0_FIT_CONTROL_DEPENDENCIES_REQUIRED",str(threshold.asset_id))
        models.append({"asset_id":str(threshold.asset_id),"maintenance_epoch":str(threshold.maintenance_epoch),"asset_threshold":float(threshold.threshold),"minimum_consecutive_windows":int(selected_row["minimum_consecutive_windows"]),"score_available_after":fit_controls["end_utc"].max().isoformat(),"shadow_eligible_after":asset_controls["end_utc"].max().isoformat(),"feature_parameters":feature_rows})
    base={"contract_version":M0_BUNDLE_CONTRACT,"workflow_contract_version":WORKFLOW_CONTRACT,"poc_only":True,"production_use_allowed":False,"window_minutes":5,
          "score_rule":"MAX_ABS_ROBUST_Z_BY_SENSOR_THEN_ASSET","threshold_rule":"VALIDATION_CONTROL_QUANTILE","persistence_rule":"CONSECUTIVE_COMPLETE_WINDOWS",
          "required_operation_mode":"RUNNING","baseline_required_health_state":"HEALTHY_STATE","detection_allowed_health_states":["HEALTHY_STATE","UNHEALTHY_STATE","UNKNOWN"],"unknown_operation_mode_detection_allowed":False,"health_state_inferred_by_detector":False,"quality_pass_required":True,
          "gap_fill_allowed":False,"future_data_allowed":False,"minimum_scored_parameter_ratio":0.95,"event_data_used_for_fit":False,"test_data_used_for_selection":False,"models":models,
          "source_hashes":{"parameters_sha256":sha256_file(params_path),"thresholds_sha256":sha256_file(thresholds_path),"persistence_sha256":sha256_file(persistence_path),"feature_contract_sha256":sha256_file(features_path),"controls_sha256":sha256_file(controls_path),"policy_sha256":sha256_file(policy_path)}}
    identity=canonical_sha256(base); bundle={**base,"model_bundle_id":f"M0-POC-{identity[:12]}","model_bundle_sha256":identity}; bundle_path=output/"m0_model_bundle.json"; write_json(bundle_path,bundle)
    feature_count=sum(len(model["feature_parameters"]) for model in models); sensor_count=len({(model["asset_id"],feature["sensor_uid"]) for model in models for feature in model["feature_parameters"]})
    payload={"contract_version":M0_BUNDLE_CONTRACT,"model_bundle_id":bundle["model_bundle_id"],"bundle_file_sha256":sha256_file(bundle_path),"asset_count":len(models),"sensor_count":sensor_count,"feature_parameter_count":feature_count,
             "excluded_selected_feature_count":int((features["selected"].map(_bool)).sum())-feature_count,"poc_only":True,"production_use_allowed":False,"safety":policy["safety"]}
    return _receipt("VC13",{"MODEL":bundle["model_bundle_id"],"ASSETS":len(models),"SENSORS":sensor_count,"PARAMS":feature_count,"EXCLUDED":payload["excluded_selected_feature_count"]},payload,output)


def exact_lead_review(run_dir: Path, vc12_dir: Path, reference_phases: Path, output_dir: Path, overwrite: bool) -> dict[str,Any]:
    output=ensure_output_directory(output_dir,overwrite); root=run_dir.expanduser().resolve(); vc12=vc12_dir.expanduser().resolve()
    scores=pd.read_csv(root/"score-event"/"event_sensor_scores.csv",low_memory=False); thresholds=pd.read_csv(root/"vc08"/"selected_threshold_policy.csv"); persistence=pd.read_csv(vc12/"poc_selected_persistence_policy.csv"); controls=pd.read_csv(root/"vc00"/"normalized_validated_controls.csv")
    phases=pd.read_csv(reference_phases); require_columns(phases.columns,["occurrence_uid","asset_id","event_start","event_time_precision"],"PHASE_HEADER_INVALID")
    exact=phases[phases["event_time_precision"]=="EXACT_MINUTE"].drop_duplicates("occurrence_uid")
    threshold_map=thresholds.groupby("asset_id")["threshold"].agg(list).to_dict(); run_map=persistence.set_index("asset_id")["minimum_consecutive_windows"].astype(int).to_dict()
    event=scores.groupby(["occurrence_uid","asset_id","phase","window_start","window_end"],dropna=False)["sensor_score"].max().reset_index(name="asset_score")
    event["threshold"]=[values[0] if len(values)==1 else math.nan for values in event["asset_id"].map(threshold_map)]; event["alert"]=event["asset_score"]>event["threshold"]
    rows=[]
    for phase in exact.sort_values("occurrence_uid").itertuples():
        occurrence=str(phase.occurrence_uid); asset=str(phase.asset_id); minimum_run=int(run_map[asset]); group=event[(event["occurrence_uid"]==occurrence)&event["phase"].astype(str).str.startswith("PRE_")].copy(); group["start"]=pd.to_datetime(group["window_start"],utc=True); group["end"]=pd.to_datetime(group["window_end"],utc=True); group=group.sort_values("start")
        current=0; previous=None; detection_time=None
        for item in group.itertuples(index=False):
            contiguous=previous is not None and item.start-previous<=pd.Timedelta(minutes=5)
            if item.alert: current=current+1 if contiguous and current else 1
            else: current=0
            if current>=minimum_run and detection_time is None: detection_time=item.end
            previous=item.start
        event_start=pd.Timestamp(phase.event_start).tz_convert("UTC"); lead_minutes=(event_start-detection_time).total_seconds()/60 if detection_time is not None else math.nan
        dependencies=controls[(controls["asset_id"]==asset)&controls["control_role"].isin(["TRAIN_CONTROL","VALIDATION_CONTROL"])]
        dependency_ends=pd.to_datetime(dependencies["end_time"],utc=True); temporal_prior=not dependencies.empty and bool((dependency_ends<=event_start).all())
        rows.append({"occurrence_uid":occurrence,"asset_id":asset,"event_start":str(phase.event_start),"minimum_consecutive_windows":minimum_run,"persistent_detection":detection_time is not None,"first_persistent_detection_time":detection_time.isoformat() if detection_time is not None else "","lead_minutes":lead_minutes,"temporal_fit_status":"ALL_FIT_INPUTS_PRIOR" if temporal_prior else "RETROSPECTIVE_LOOKAHEAD_PRESENT","event_epoch_status":"UNVERIFIED","online_evaluation_status":"ONLINE_NOT_EVALUABLE_EVENT_EPOCH_UNVERIFIED"})
    result=pd.DataFrame(rows); result_path=output/"exact_event_lead_results.csv"; result.to_csv(result_path,index=False)
    lines=[]
    for row in result.itertuples():
        lead="NA" if pd.isna(row.lead_minutes) else f"{float(row.lead_minutes):.1f}"
        lines.append(f"VC14E|{row.occurrence_uid}|ASSET:{row.asset_id}|RUN:{row.minimum_consecutive_windows}|PERSIST:{'Y' if row.persistent_detection else 'N'}|LEAD_MIN:{lead}|TEMPORAL:{row.temporal_fit_status}|ONLINE:NOT_EVALUABLE_EPOCH_UNVERIFIED")
    detected=int(result["persistent_detection"].map(_bool).sum()); prior=int((result["temporal_fit_status"]=="ALL_FIT_INPUTS_PRIOR").sum())
    payload={"contract_version":WORKFLOW_CONTRACT,"exact_occurrences":len(result),"persistent_detected":detected,"all_fit_inputs_prior_count":prior,"online_evaluable_count":0,"event_epoch_status":"UNVERIFIED","detail_lines":lines,"output_sha256":sha256_file(result_path),"safety":{"retrospective_result_is_online_claim":False,"event_epoch_inferred":False,"production_use_allowed":False}}
    manifest=_receipt("VC14",{"EXACT":len(result),"PERSIST":detected,"TEMPORAL_PRIOR":prior,"ONLINE":0},payload,output); detail="\n".join(lines)+"\n"; (output/"vc14_compact_detail.txt").write_text(detail,encoding="utf-8"); print(detail,end=""); return manifest


def build_parser() -> argparse.ArgumentParser:
    parser=argparse.ArgumentParser(description=__doc__); commands=parser.add_subparsers(dest="command",required=True)
    def common(stage): stage.add_argument("--output",type=Path,required=True); stage.add_argument("--overwrite",action="store_true")
    p=commands.add_parser("intake"); p.add_argument("--controls",type=Path,required=True); p.add_argument("--policy",type=Path,default=DEFAULT_POLICY); common(p)
    p=commands.add_parser("control-features"); p.add_argument("--controls",type=Path,required=True); p.add_argument("--features-3s",type=Path,required=True);p.add_argument("--features-4s",type=Path,required=True);p.add_argument("--policy",type=Path,default=DEFAULT_POLICY);p.add_argument("--chunksize",type=int,default=200000);common(p)
    p=commands.add_parser("stability");p.add_argument("--control-features",type=Path,required=True);p.add_argument("--policy",type=Path,default=DEFAULT_POLICY);common(p)
    p=commands.add_parser("select-features");p.add_argument("--stability",type=Path,required=True);p.add_argument("--policy",type=Path,default=DEFAULT_POLICY);common(p)
    p=commands.add_parser("fit-m0");p.add_argument("--control-features",type=Path,required=True);p.add_argument("--feature-contract",type=Path,required=True);p.add_argument("--policy",type=Path,default=DEFAULT_POLICY);common(p)
    p=commands.add_parser("score-review");p.add_argument("--input",type=Path,required=True);p.add_argument("--parameters",type=Path,required=True);p.add_argument("--kind",choices=["control","event"],required=True);common(p)
    p=commands.add_parser("threshold");p.add_argument("--control-scores",type=Path,required=True);p.add_argument("--policy",type=Path,default=DEFAULT_POLICY);common(p)
    p=commands.add_parser("evaluate");p.add_argument("--event-scores",type=Path,required=True);p.add_argument("--thresholds",type=Path,required=True);common(p)
    p=commands.add_parser("run-all");p.add_argument("--controls",type=Path,required=True);p.add_argument("--features-3s",type=Path,required=True);p.add_argument("--features-4s",type=Path,required=True);p.add_argument("--event-phase-windows",type=Path,required=True);p.add_argument("--policy",type=Path,default=DEFAULT_POLICY);p.add_argument("--chunksize",type=int,default=200000);common(p)
    p=commands.add_parser("compact-review");p.add_argument("--run-dir",type=Path,required=True);p.add_argument("--event-phase-windows",type=Path);p.add_argument("--reference-phases",type=Path);p.add_argument("--output-file",type=Path,required=True)
    p=commands.add_parser("holdout-review");p.add_argument("--run-dir",type=Path,required=True);p.add_argument("--event-phase-windows",type=Path,required=True);p.add_argument("--reference-phases",type=Path,required=True);p.add_argument("--output-file",type=Path,required=True)
    p=commands.add_parser("poc-policy-review");p.add_argument("--run-dir",type=Path,required=True);p.add_argument("--policy",type=Path,default=DEFAULT_POLICY);common(p)
    p=commands.add_parser("freeze-m0");p.add_argument("--run-dir",type=Path,required=True);p.add_argument("--vc12-dir",type=Path,required=True);p.add_argument("--policy",type=Path,default=DEFAULT_POLICY);common(p)
    p=commands.add_parser("exact-lead-review");p.add_argument("--run-dir",type=Path,required=True);p.add_argument("--vc12-dir",type=Path,required=True);p.add_argument("--reference-phases",type=Path,required=True);common(p)
    return parser


def run_all(args: argparse.Namespace) -> None:
    root=ensure_output_directory(args.output,args.overwrite)
    stages={name:root/name for name in ("vc00","vc02","vc03","vc04","vc06","score-control","vc08","score-event","vc09")}
    intake_controls(args.controls,args.policy,stages["vc00"],False)
    normalized=stages["vc00"]/"normalized_validated_controls.csv"
    ready=pd.read_csv(normalized)
    require((ready["workflow_status"]=="READY").any(),"VC00_NO_READY_CONTROLS",str(stages["vc00"] / "control_intake_issues.csv"))
    role_matrix=ready[ready["workflow_status"]=="READY"].groupby(["asset_id","control_role"]).size().unstack(fill_value=0)
    policy=load_policy(args.policy)
    for asset,row in role_matrix.iterrows():
        require(
            int(row.get("TRAIN_CONTROL",0))>=int(policy["minimum_train_controls"])
            and int(row.get("VALIDATION_CONTROL",0))>=int(policy["minimum_validation_controls"]),
            "VC00_CONTROL_ROLE_COUNT_INSUFFICIENT", str(asset),
        )
    extract_control_features(normalized,args.features_3s,args.features_4s,args.policy,stages["vc02"],args.chunksize,False)
    control_features=stages["vc02"]/"control_feature_windows.csv"
    control_stability(control_features,args.policy,stages["vc03"],False)
    select_features(stages["vc03"]/"control_stability_report.csv",args.policy,stages["vc04"],False)
    fit_m0(control_features,stages["vc04"]/"selected_feature_contract.csv",args.policy,stages["vc06"],False)
    parameters=stages["vc06"]/"baseline_parameters.csv"
    score_review(control_features,parameters,"control",stages["score-control"],False)
    select_threshold(stages["score-control"]/"control_sensor_scores.csv",args.policy,stages["vc08"],False)
    score_review(args.event_phase_windows,parameters,"event",stages["score-event"],False)
    evaluate_events(stages["score-event"]/"event_sensor_scores.csv",stages["vc08"]/"selected_threshold_policy.csv",stages["vc09"],False)
    receipt_paths=[
        stages["vc00"]/"vc00_receipt.txt", stages["vc00"]/"vc00_compact_issues.txt",
        stages["vc02"]/"vc02_receipt.txt",
        stages["vc03"]/"vc03_receipt.txt", stages["vc04"]/"vc04_receipt.txt",
        stages["vc06"]/"vc06_receipt.txt", stages["score-control"]/"vc07_receipt.txt",
        stages["vc08"]/"vc08_receipt.txt", stages["score-event"]/"vc07_receipt.txt",
        stages["vc09"]/"vc09_receipt.txt",
    ]
    lines=["ANOMALY_VALIDATED_WORKFLOW=COMPLETED",*[path.read_text(encoding="utf-8").strip() for path in receipt_paths]]
    (root/"field_compact_report.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print("\n".join(lines))


def main() -> int:
    args=build_parser().parse_args()
    if args.command=="run-all": run_all(args)
    elif args.command=="compact-review": compact_review(args.run_dir,args.event_phase_windows,args.output_file,args.reference_phases)
    elif args.command=="holdout-review": holdout_review(args.run_dir,args.event_phase_windows,args.reference_phases,args.output_file)
    elif args.command=="poc-policy-review": poc_policy_review(args.run_dir,args.policy,args.output,args.overwrite)
    elif args.command=="freeze-m0": freeze_m0_bundle(args.run_dir,args.vc12_dir,args.policy,args.output,args.overwrite)
    elif args.command=="exact-lead-review": exact_lead_review(args.run_dir,args.vc12_dir,args.reference_phases,args.output,args.overwrite)
    elif args.command=="intake": intake_controls(args.controls,args.policy,args.output,args.overwrite)
    elif args.command=="control-features": extract_control_features(args.controls,args.features_3s,args.features_4s,args.policy,args.output,args.chunksize,args.overwrite)
    elif args.command=="stability": control_stability(args.control_features,args.policy,args.output,args.overwrite)
    elif args.command=="select-features": select_features(args.stability,args.policy,args.output,args.overwrite)
    elif args.command=="fit-m0": fit_m0(args.control_features,args.feature_contract,args.policy,args.output,args.overwrite)
    elif args.command=="score-review": score_review(args.input,args.parameters,args.kind,args.output,args.overwrite)
    elif args.command=="threshold": select_threshold(args.control_scores,args.policy,args.output,args.overwrite)
    else: evaluate_events(args.event_scores,args.thresholds,args.output,args.overwrite)
    return 0


if __name__=="__main__":
    try:
        raise SystemExit(main())
    except AnomalyContractError as exc:
        print(f"ANOMALY_VALIDATED_WORKFLOW=BLOCKED|CODE:{exc.code}")
        raise SystemExit(2) from None
