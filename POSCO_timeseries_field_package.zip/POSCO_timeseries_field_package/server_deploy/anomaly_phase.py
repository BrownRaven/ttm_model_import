"""AA01 event-phase generation and bounded single-pass Feature review."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict
from datetime import timedelta
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd

from anomaly_contract import (
    ANOMALY_CONTRACT_VERSION,
    ASSET_SCOPE,
    PHASE_CONTRACT_VERSION,
    AnomalyContractError,
    PhaseInterval,
    canonical_sha256,
    content_identity,
    ensure_output_directory,
    file_identity,
    parse_offset_datetime,
    require,
    require_columns,
    sha256_file,
    write_csv,
    write_json,
)
from timeseries_event_review import (
    IDENTIFIER_COLUMNS,
    METRIC_COLUMNS,
    EventOccurrence,
    parse_priority_events,
    select_occurrences,
)

PHASE_FIELDS = list(PhaseInterval.__dataclass_fields__)
PHASE_REVIEW_CONTRACT = "PIMS-ANOMALY-PHASE-REVIEW-v1"


def load_phase_policy(path: Path) -> dict[str, Any]:
    resolved = path.expanduser().resolve()
    policy = json.loads(resolved.read_text(encoding="utf-8"))
    require(policy.get("contract_version") == PHASE_CONTRACT_VERSION, "PHASE_POLICY_VERSION_INVALID", str(path))
    require(policy.get("timezone") == "Asia/Seoul", "PHASE_TIMEZONE_INVALID", str(policy.get("timezone")))
    require(
        policy.get("window_assignment_rule") == "WINDOW_MIDPOINT_IN_HALF_OPEN_PHASE",
        "PHASE_WINDOW_ASSIGNMENT_INVALID", str(policy.get("window_assignment_rule")),
    )
    phases = policy.get("phases", [])
    require(len(phases) > 0, "PHASE_POLICY_EMPTY", str(path))
    names = [item.get("name") for item in phases]
    require(len(names) == len(set(names)), "PHASE_POLICY_DUPLICATE_NAME", "|".join(str(value) for value in names))
    require("DURING" in names, "PHASE_POLICY_DURING_REQUIRED", str(path))
    for item in phases:
        require(item.get("anchor") in {"EVENT_START", "EVENT_END", "EVENT_RANGE"}, "PHASE_ANCHOR_INVALID", str(item))
        if item.get("anchor") != "EVENT_RANGE":
            require(float(item["end_offset_hours"]) > float(item["start_offset_hours"]), "PHASE_RANGE_INVALID", str(item))
    return policy


def _phase_range(occurrence: EventOccurrence, definition: dict[str, Any]) -> tuple[Any, Any]:
    anchor = definition["anchor"]
    if anchor == "EVENT_RANGE":
        return occurrence.start, occurrence.end
    base = occurrence.start if anchor == "EVENT_START" else occurrence.end
    return (
        base + timedelta(hours=float(definition["start_offset_hours"])),
        base + timedelta(hours=float(definition["end_offset_hours"])),
    )


def build_phase_intervals(
    occurrences: Sequence[EventOccurrence], policy: dict[str, Any], source_ref: str
) -> list[PhaseInterval]:
    intervals: list[PhaseInterval] = []
    for occurrence in occurrences:
        per_occurrence: list[tuple[Any, Any, str]] = []
        for phase_order, definition in enumerate(policy["phases"], start=1):
            start, end = _phase_range(occurrence, definition)
            require(end > start, "PHASE_RANGE_INVALID", f"{occurrence.occurrence_uid}:{definition['name']}")
            low_precision = occurrence.precision != "EXACT_MINUTE"
            label_status = "LOW_TIME_PRECISION" if low_precision else str(definition["label_status"])
            interval = PhaseInterval(
                phase_uid=f"{occurrence.occurrence_uid}:{definition['name']}",
                occurrence_uid=occurrence.occurrence_uid,
                event_uid=occurrence.event.event_uid,
                priority=occurrence.event.priority,
                event_score=occurrence.event.score,
                asset_id=occurrence.event.asset_id,
                phase=str(definition["name"]),
                phase_order=phase_order,
                start_time=start.isoformat(),
                end_time=end.isoformat(),
                event_start=occurrence.start.isoformat(),
                event_end=occurrence.end.isoformat(),
                event_time_precision=occurrence.precision,
                label_status=label_status,
                lead_time_eligible=not low_precision,
                source_ref=source_ref,
            )
            intervals.append(interval)
            per_occurrence.append((start, end, interval.phase_uid))
        ordered = sorted(per_occurrence)
        for previous, current in zip(ordered, ordered[1:]):
            require(previous[1] <= current[0], "PHASE_OVERLAP", f"{previous[2]}|{current[2]}")
    phase_uids = [interval.phase_uid for interval in intervals]
    require(len(phase_uids) == len(set(phase_uids)), "PHASE_UID_DUPLICATE", "generated")
    return intervals


def generate_phases(
    events_markdown: Path,
    policy_path: Path,
    output_dir: Path,
    top: int | None,
    event_ids: set[str],
    overwrite: bool,
) -> dict[str, Any]:
    output = ensure_output_directory(output_dir, overwrite)
    events_path = events_markdown.expanduser().resolve()
    policy_resolved = policy_path.expanduser().resolve()
    events = parse_priority_events(events_path)
    occurrences = select_occurrences(events, None if event_ids else top, event_ids)
    require(bool(occurrences), "PHASE_OCCURRENCE_REQUIRED", str(events_path))
    policy = load_phase_policy(policy_resolved)
    intervals = build_phase_intervals(occurrences, policy, events_path.name)
    rows = [interval.as_row() for interval in intervals]
    phases_path = output / "reference_event_phases.csv"
    write_csv(phases_path, rows, PHASE_FIELDS)
    event_ids_selected = sorted({item.event.event_uid for item in occurrences})
    low_precision_count = sum(not item.lead_time_eligible for item in intervals)
    payload = {
        "contract_version": ANOMALY_CONTRACT_VERSION,
        "phase_contract_version": PHASE_CONTRACT_VERSION,
        "events_source": content_identity(events_path),
        "policy_source": content_identity(policy_resolved),
        "phases_file": {
            "sha256": sha256_file(phases_path), "size_bytes": phases_path.stat().st_size, "row_count": len(rows)
        },
        "event_ids": event_ids_selected,
        "occurrence_uids": [item.occurrence_uid for item in occurrences],
        "phase_count": len(rows),
        "low_time_precision_phase_count": low_precision_count,
        "safety": policy["safety"],
    }
    receipt = canonical_sha256(payload)
    manifest = {**payload, "receipt_sha256": receipt}
    write_json(output / "phase_manifest.json", manifest)
    compact = (
        f"ANOMALY_PHASES=VALID|EVENTS:{len(event_ids_selected)}|OCCURRENCES:{len(occurrences)}|"
        f"PHASES:{len(rows)}|LOWPREC:{low_precision_count}|SHA:{receipt}\n"
    )
    (output / "phase_receipt.txt").write_text(compact, encoding="utf-8")
    return manifest


def load_phase_intervals(path: Path) -> list[PhaseInterval]:
    frame = pd.read_csv(path)
    require_columns(frame.columns, PHASE_FIELDS, "PHASE_HEADER_INVALID")
    intervals = []
    for row in frame.to_dict(orient="records"):
        intervals.append(PhaseInterval(
            phase_uid=str(row["phase_uid"]),
            occurrence_uid=str(row["occurrence_uid"]),
            event_uid=str(row["event_uid"]),
            priority=int(row["priority"]),
            event_score=int(row["event_score"]),
            asset_id=str(row["asset_id"]),
            phase=str(row["phase"]),
            phase_order=int(row["phase_order"]),
            start_time=str(row["start_time"]),
            end_time=str(row["end_time"]),
            event_start=str(row["event_start"]),
            event_end=str(row["event_end"]),
            event_time_precision=str(row["event_time_precision"]),
            label_status=str(row["label_status"]),
            lead_time_eligible=str(row["lead_time_eligible"]).lower() == "true",
            source_ref=str(row["source_ref"]),
        ))
    for interval in intervals:
        require(interval.asset_id in ASSET_SCOPE, "PHASE_ASSET_UNSUPPORTED", interval.asset_id)
        require(parse_offset_datetime(interval.end_time, "end_time") > parse_offset_datetime(interval.start_time, "start_time"), "PHASE_RANGE_INVALID", interval.phase_uid)
    return intervals


def _validate_phase_manifest(phases_path: Path, manifest_path: Path) -> dict[str, Any]:
    manifest = json.loads(manifest_path.expanduser().resolve().read_text(encoding="utf-8"))
    require(manifest.get("phase_contract_version") == PHASE_CONTRACT_VERSION, "PHASE_MANIFEST_VERSION_INVALID", str(manifest_path))
    expected = manifest.get("phases_file", {})
    require(expected.get("sha256") == sha256_file(phases_path), "PHASE_FILE_SHA_MISMATCH", str(phases_path))
    return manifest


def _mark_numerical_constants(frame: pd.DataFrame) -> int:
    frame["spectral_review_status"] = frame.get("spectral_status", pd.Series("NOT_AVAILABLE", index=frame.index))
    if "range" not in frame or "spectral_status" not in frame:
        return 0
    numeric_range = pd.to_numeric(frame["range"], errors="coerce")
    mask = (frame["spectral_status"] == "PASS") & (numeric_range == 0)
    frame.loc[mask, "spectral_review_status"] = "REVIEW_NUMERICAL_CONSTANT"
    spectral_columns = [column for column in METRIC_COLUMNS if column.startswith("spectral_") or column.startswith("dominant_") or column.startswith("relative_power_")]
    frame.loc[mask, [column for column in spectral_columns if column in frame]] = np.nan
    return int(mask.sum())


def scan_phase_windows(
    feature_files: dict[str, Path],
    intervals: Sequence[PhaseInterval],
    chunksize: int,
    max_selected_rows: int,
) -> tuple[pd.DataFrame, dict[str, int]]:
    selected_chunks: list[pd.DataFrame] = []
    scanned = 0
    numerical_constants = 0
    by_scope = {
        scope: [interval for interval in intervals if ASSET_SCOPE[interval.asset_id] == scope]
        for scope in feature_files
    }
    for scope, source in feature_files.items():
        source = source.expanduser().resolve()
        header = pd.read_csv(source, nrows=0).columns.tolist()
        require_columns(header, ["window_start", "window_end", "asset_id", "sensor_uid", "measurement_type"], "FEATURE_HEADER_INVALID")
        usecols = [column for column in [*IDENTIFIER_COLUMNS, *METRIC_COLUMNS] if column in header]
        for chunk in pd.read_csv(source, usecols=usecols, chunksize=chunksize, low_memory=False):
            scanned += len(chunk)
            starts = pd.to_datetime(chunk["window_start"], errors="coerce", utc=True)
            ends = pd.to_datetime(chunk["window_end"], errors="coerce", utc=True)
            require(not starts.isna().any() and not ends.isna().any(), "FEATURE_TIME_INVALID", str(source))
            midpoints = starts + (ends - starts) / 2
            for interval in by_scope[scope]:
                phase_start = pd.Timestamp(interval.start_time).tz_convert("UTC")
                phase_end = pd.Timestamp(interval.end_time).tz_convert("UTC")
                mask = (
                    (chunk["asset_id"] == interval.asset_id)
                    & (midpoints >= phase_start)
                    & (midpoints < phase_end)
                )
                if not mask.any():
                    continue
                selected = chunk.loc[mask].copy()
                selected.insert(0, "phase_uid", interval.phase_uid)
                selected.insert(1, "occurrence_uid", interval.occurrence_uid)
                selected.insert(2, "event_uid", interval.event_uid)
                selected.insert(3, "priority", interval.priority)
                selected.insert(4, "phase", interval.phase)
                selected.insert(5, "phase_order", interval.phase_order)
                selected.insert(6, "phase_start", interval.start_time)
                selected.insert(7, "phase_end", interval.end_time)
                selected.insert(8, "event_time_precision", interval.event_time_precision)
                selected.insert(9, "label_status", interval.label_status)
                selected.insert(10, "lead_time_eligible", interval.lead_time_eligible)
                numerical_constants += _mark_numerical_constants(selected)
                selected_chunks.append(selected)
                if sum(len(item) for item in selected_chunks) > max_selected_rows:
                    raise AnomalyContractError("SELECTED_ROW_LIMIT_EXCEEDED", str(max_selected_rows))
    if not selected_chunks:
        return pd.DataFrame(), {"source_rows_scanned": scanned, "selected_rows": 0, "numerical_constant_rows": 0, "context_overlap_rows": 0}
    windows = pd.concat(selected_chunks, ignore_index=True)
    identity_columns = ["dataset_id", "window_start", "sensor_uid"] if "dataset_id" in windows else ["window_start", "sensor_uid"]
    overlap_count = windows.groupby(identity_columns)["occurrence_uid"].transform("nunique")
    windows["context_occurrence_count"] = overlap_count
    windows["context_overlap_status"] = np.where(overlap_count > 1, "SHARED_ACROSS_OCCURRENCE_CONTEXTS", "UNIQUE_CONTEXT")
    windows.sort_values(["priority", "occurrence_uid", "phase_order", "window_start", "sensor_uid"], inplace=True)
    return windows, {
        "source_rows_scanned": scanned,
        "selected_rows": len(windows),
        "numerical_constant_rows": numerical_constants,
        "context_overlap_rows": int((overlap_count > 1).sum()),
    }


def summarize_phase_windows(windows: pd.DataFrame) -> pd.DataFrame:
    if windows.empty:
        return pd.DataFrame()
    keys = [
        "event_uid", "occurrence_uid", "priority", "asset_id", "phase", "phase_order",
        "event_time_precision", "label_status", "lead_time_eligible", "sensor_uid", "measurement_type", "unit",
    ]
    metrics = [metric for metric in METRIC_COLUMNS if metric in windows]
    rows: list[dict[str, Any]] = []
    for group_key, group in windows.groupby(keys, dropna=False, sort=False):
        identity = dict(zip(keys, group_key))
        quality_pass = float((group["quality_status"] == "PASS").mean()) if "quality_status" in group else math.nan
        spectral_pass = float((group["spectral_review_status"] == "PASS").mean()) if "spectral_review_status" in group else math.nan
        context_overlap = int((group["context_overlap_status"] == "SHARED_ACROSS_OCCURRENCE_CONTEXTS").sum())
        for metric in metrics:
            values = pd.to_numeric(group[metric], errors="coerce").dropna()
            rows.append({
                **identity,
                "metric": metric,
                "value_count": len(values),
                "median": float(values.median()) if not values.empty else math.nan,
                "p05": float(values.quantile(0.05)) if not values.empty else math.nan,
                "p95": float(values.quantile(0.95)) if not values.empty else math.nan,
                "min": float(values.min()) if not values.empty else math.nan,
                "max": float(values.max()) if not values.empty else math.nan,
                "quality_pass_ratio": quality_pass,
                "spectral_pass_ratio": spectral_pass,
                "context_overlap_row_count": context_overlap,
                "baseline_status": "PHASE_CONTEXT_ONLY_NOT_CONFIRMED_NORMAL",
                "interpretation": "DESCRIPTIVE_ONLY_NOT_ANOMALY_OR_CAUSALITY",
            })
    return pd.DataFrame(rows)


def _write_phase_markdown(path: Path, windows: pd.DataFrame, intervals: Sequence[PhaseInterval]) -> None:
    lines = [
        "# 사건 Phase Feature 검토", "",
        f"- 계약: `{PHASE_REVIEW_CONTRACT}`",
        "- PRE phase는 정상 또는 이상 label이 아니라 precursor 평가 문맥이다.",
        "- POST phase는 복구·정비 영향을 포함하며 precursor fit에 사용하지 않는다.",
        "- Context overlap row는 occurrence별 문맥이 겹친 것이며 unique physical window 수가 아니다.", "",
        "| Occurrence | Asset | Phase | Sensor-window rows | Quality PASS | Spectral PASS | Shared context rows |",
        "| --- | --- | --- | ---: | ---: | ---: | ---: |",
    ]
    if not windows.empty:
        grouped = windows.groupby(["occurrence_uid", "asset_id", "phase", "phase_order"], sort=False)
        for (occurrence_uid, asset_id, phase, _), group in grouped:
            quality = (group["quality_status"] == "PASS").mean() if "quality_status" in group else math.nan
            spectral = (group["spectral_review_status"] == "PASS").mean() if "spectral_review_status" in group else math.nan
            shared = int((group["context_overlap_status"] == "SHARED_ACROSS_OCCURRENCE_CONTEXTS").sum())
            lines.append(f"| `{occurrence_uid}` | {asset_id} | `{phase}` | {len(group)} | {quality:.6f} | {spectral:.6f} | {shared} |")
    low_precision = sorted({item.occurrence_uid for item in intervals if not item.lead_time_eligible})
    if low_precision:
        lines.extend(["", "## Lead time 제외", "", *[f"- `{value}`: LOW_TIME_PRECISION" for value in low_precision]])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def review_phases(
    phases_path: Path,
    phase_manifest_path: Path,
    features_3s: Path,
    features_4s: Path,
    output_dir: Path,
    chunksize: int,
    max_selected_rows: int,
    overwrite: bool,
) -> dict[str, Any]:
    output = ensure_output_directory(output_dir, overwrite)
    phases_resolved = phases_path.expanduser().resolve()
    phase_manifest = _validate_phase_manifest(phases_resolved, phase_manifest_path)
    intervals = load_phase_intervals(phases_resolved)
    feature_files = {"3S": features_3s.expanduser().resolve(), "4S": features_4s.expanduser().resolve()}
    windows, scan = scan_phase_windows(feature_files, intervals, chunksize, max_selected_rows)
    windows_path = output / "event_phase_windows.csv"
    windows.to_csv(windows_path, index=False)
    summary = summarize_phase_windows(windows)
    summary_path = output / "event_phase_feature_summary.csv"
    summary.to_csv(summary_path, index=False)
    _write_phase_markdown(output / "event_phase_review.md", windows, intervals)
    payload = {
        "contract_version": ANOMALY_CONTRACT_VERSION,
        "review_contract_version": PHASE_REVIEW_CONTRACT,
        "phase_manifest_receipt_sha256": phase_manifest["receipt_sha256"],
        "phases_source": content_identity(phases_resolved),
        "feature_sources": {scope: file_identity(path, include_sha256=False) for scope, path in feature_files.items()},
        "scan": scan,
        "summary_rows": len(summary),
        "outputs": {
            "windows": {"sha256": sha256_file(windows_path), "size_bytes": windows_path.stat().st_size},
            "summary": {"sha256": sha256_file(summary_path), "size_bytes": summary_path.stat().st_size},
        },
        "safety": {
            "pre_assumed_normal": False,
            "pre_assumed_anomalous": False,
            "threshold_inferred": False,
            "causality_inferred": False,
            "production_decision_allowed": False,
        },
    }
    receipt = canonical_sha256(payload)
    manifest = {**payload, "receipt_sha256": receipt}
    write_json(output / "event_phase_review_manifest.json", manifest)
    compact = (
        f"ANOMALY_PHASE_REVIEW=VALID|SCANNED:{scan['source_rows_scanned']}|SELECTED:{scan['selected_rows']}|"
        f"NUMCONST:{scan['numerical_constant_rows']}|CTXOVER:{scan['context_overlap_rows']}|"
        f"SUMMARY:{len(summary)}|SHA:{receipt}\n"
    )
    (output / "event_phase_review_receipt.txt").write_text(compact, encoding="utf-8")
    return manifest
