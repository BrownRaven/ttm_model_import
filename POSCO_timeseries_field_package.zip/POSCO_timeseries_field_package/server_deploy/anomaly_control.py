"""AA02 confirmed-control registry validation with event and Feature coverage gates."""

from __future__ import annotations

import json
import math
from dataclasses import asdict
from datetime import UTC
from pathlib import Path
from typing import Any, Sequence

import pandas as pd

from anomaly_contract import (
    ANOMALY_CONTRACT_VERSION,
    ASSET_SCOPE,
    CONTROL_CONTRACT_VERSION,
    AnomalyContractError,
    ControlInterval,
    canonical_sha256,
    content_identity,
    ensure_output_directory,
    file_identity,
    parse_offset_datetime,
    read_csv_rows,
    require,
    require_columns,
    sha256_file,
    write_csv,
    write_json,
)
from anomaly_phase import PHASE_FIELDS, load_phase_intervals

CONTROL_FIELDS = list(ControlInterval.__dataclass_fields__)
REVIEW_STATUSES = {"PROPOSED", "CONFIRMED_CONTROL", "REJECTED", "EXPIRED_REVIEW_REQUIRED"}
OPERATION_STATES = {"RUNNING", "STOPPED", "MAINTENANCE", "UNKNOWN"}
OPERATION_STATE_STATUSES = {"CONFIRMED_BY_OWNER", "CONFIRMED_FROM_SOURCE", "UNKNOWN"}
MAINTENANCE_STATUSES = {"NO_OVERLAP_CONFIRMED", "OVERLAP", "UNKNOWN"}
COMMUNICATION_STATUSES = {"HEALTHY_CONFIRMED", "DEGRADED", "UNKNOWN"}


def load_controls(path: Path) -> list[ControlInterval]:
    rows = read_csv_rows(path)
    if not rows:
        raise AnomalyContractError("CONTROL_REGISTRY_EMPTY", str(path))
    require_columns(rows[0], CONTROL_FIELDS, "CONTROL_HEADER_INVALID")
    controls = [ControlInterval(**{field: str(row.get(field, "")).strip() for field in CONTROL_FIELDS}) for row in rows]
    uids = [control.control_uid for control in controls]
    require(all(uids), "CONTROL_UID_REQUIRED", str(path))
    require(len(uids) == len(set(uids)), "CONTROL_UID_DUPLICATE", "|".join(uids))
    return controls


def _base_validation(control: ControlInterval) -> tuple[Any, Any, list[str]]:
    failures: list[str] = []
    if control.asset_id not in ASSET_SCOPE:
        failures.append("ASSET_UNSUPPORTED")
    if control.review_status not in REVIEW_STATUSES:
        failures.append("REVIEW_STATUS_INVALID")
    if control.operation_state not in OPERATION_STATES:
        failures.append("OPERATION_STATE_INVALID")
    if control.operation_state_status not in OPERATION_STATE_STATUSES:
        failures.append("OPERATION_STATE_STATUS_INVALID")
    if control.maintenance_overlap_status not in MAINTENANCE_STATUSES:
        failures.append("MAINTENANCE_STATUS_INVALID")
    if control.communication_status not in COMMUNICATION_STATUSES:
        failures.append("COMMUNICATION_STATUS_INVALID")
    try:
        start = parse_offset_datetime(control.start_time, "control.start_time")
        end = parse_offset_datetime(control.end_time, "control.end_time")
    except AnomalyContractError as exc:
        return None, None, [exc.code]
    if end <= start:
        failures.append("CONTROL_RANGE_INVALID")
    duration_days = (end - start).total_seconds() / 86400
    if duration_days < 7:
        failures.append("CONTROL_DURATION_LT_7D")
    if control.timezone != "Asia/Seoul":
        failures.append("CONTROL_TIMEZONE_INVALID")
    if control.review_status == "CONFIRMED_CONTROL":
        if not control.reviewed_by_ref or not control.reviewed_at:
            failures.append("CONTROL_REVIEW_EVIDENCE_REQUIRED")
        else:
            try:
                parse_offset_datetime(control.reviewed_at, "control.reviewed_at")
            except AnomalyContractError:
                failures.append("CONTROL_REVIEW_TIME_INVALID")
        if control.operation_state == "UNKNOWN" or control.operation_state_status == "UNKNOWN":
            failures.append("CONTROL_OPERATION_STATE_CONFIRMATION_REQUIRED")
        if control.maintenance_overlap_status != "NO_OVERLAP_CONFIRMED":
            failures.append("CONTROL_MAINTENANCE_CLEARANCE_REQUIRED")
        if control.communication_status != "HEALTHY_CONFIRMED":
            failures.append("CONTROL_COMMUNICATION_HEALTH_REQUIRED")
    return start, end, failures


def _event_overlaps(control: ControlInterval, start: Any, end: Any, phases: Sequence[Any]) -> list[str]:
    if start is None or end is None:
        return []
    overlaps = []
    for phase in phases:
        if phase.asset_id != control.asset_id:
            continue
        phase_start = parse_offset_datetime(phase.start_time, "phase.start_time")
        phase_end = parse_offset_datetime(phase.end_time, "phase.end_time")
        if start < phase_end and end > phase_start:
            overlaps.append(phase.phase_uid)
    return overlaps


def _control_overlap_failures(controls_with_time: list[tuple[ControlInterval, Any, Any]]) -> dict[str, list[str]]:
    failures = {control.control_uid: [] for control, _, _ in controls_with_time}
    for index, (left, left_start, left_end) in enumerate(controls_with_time):
        if left_start is None or left_end is None:
            continue
        for right, right_start, right_end in controls_with_time[index + 1:]:
            if right_start is None or right_end is None or left.asset_id != right.asset_id:
                continue
            if left_start < right_end and left_end > right_start:
                failures[left.control_uid].append(right.control_uid)
                failures[right.control_uid].append(left.control_uid)
    return failures


def scan_control_coverage(
    controls: Sequence[ControlInterval], feature_files: dict[str, Path], chunksize: int
) -> dict[str, dict[str, Any]]:
    stats = {
        control.control_uid: {
            "window_starts": set(), "feature_rows": 0, "quality_pass_rows": 0,
            "sensor_uids": set(), "source_rows_scanned": 0,
        }
        for control in controls
    }
    controls_by_scope = {
        scope: [control for control in controls if ASSET_SCOPE.get(control.asset_id) == scope]
        for scope in feature_files
    }
    for scope, path in feature_files.items():
        path = path.expanduser().resolve()
        header = pd.read_csv(path, nrows=0).columns
        require_columns(header, ["window_start", "window_end", "asset_id", "sensor_uid", "quality_status"], "FEATURE_HEADER_INVALID")
        for chunk in pd.read_csv(
            path, usecols=["window_start", "window_end", "asset_id", "sensor_uid", "quality_status"],
            chunksize=chunksize, low_memory=False,
        ):
            starts = pd.to_datetime(chunk["window_start"], errors="coerce", utc=True)
            ends = pd.to_datetime(chunk["window_end"], errors="coerce", utc=True)
            require(not starts.isna().any() and not ends.isna().any(), "FEATURE_TIME_INVALID", str(path))
            midpoints = starts + (ends - starts) / 2
            for control in controls_by_scope[scope]:
                stat = stats[control.control_uid]
                stat["source_rows_scanned"] += len(chunk)
                control_start = pd.Timestamp(control.start_time).tz_convert("UTC")
                control_end = pd.Timestamp(control.end_time).tz_convert("UTC")
                mask = (
                    (chunk["asset_id"] == control.asset_id)
                    & (midpoints >= control_start)
                    & (midpoints < control_end)
                )
                if not mask.any():
                    continue
                selected = chunk.loc[mask]
                stat["feature_rows"] += len(selected)
                stat["quality_pass_rows"] += int((selected["quality_status"] == "PASS").sum())
                stat["window_starts"].update(selected["window_start"].astype(str))
                stat["sensor_uids"].update(selected["sensor_uid"].astype(str))
    output: dict[str, dict[str, Any]] = {}
    for control in controls:
        stat = stats[control.control_uid]
        start = parse_offset_datetime(control.start_time, "control.start_time")
        end = parse_offset_datetime(control.end_time, "control.end_time")
        expected_windows = max(1, math.ceil((end - start).total_seconds() / 300))
        observed_windows = len(stat["window_starts"])
        coverage_ratio = min(observed_windows / expected_windows, 1.0)
        quality_ratio = stat["quality_pass_rows"] / stat["feature_rows"] if stat["feature_rows"] else 0.0
        output[control.control_uid] = {
            "expected_window_count": expected_windows,
            "observed_window_count": observed_windows,
            "window_coverage_ratio": coverage_ratio,
            "feature_row_count": stat["feature_rows"],
            "quality_pass_ratio": quality_ratio,
            "sensor_count": len(stat["sensor_uids"]),
            "feature_coverage_status": "PASS" if coverage_ratio >= 0.99 and quality_ratio >= 0.95 else "INSUFFICIENT",
        }
    return output


def validate_controls(
    controls_path: Path,
    phases_path: Path,
    feature_files: dict[str, Path] | None,
    output_dir: Path,
    chunksize: int,
    overwrite: bool,
) -> dict[str, Any]:
    output = ensure_output_directory(output_dir, overwrite)
    controls_resolved = controls_path.expanduser().resolve()
    phases_resolved = phases_path.expanduser().resolve()
    controls = load_controls(controls_resolved)
    phases = load_phase_intervals(phases_resolved)
    base: dict[str, tuple[Any, Any, list[str]]] = {
        control.control_uid: _base_validation(control) for control in controls
    }
    overlap_controls = _control_overlap_failures([
        (control, base[control.control_uid][0], base[control.control_uid][1]) for control in controls
    ])
    coverage = scan_control_coverage(controls, feature_files, chunksize) if feature_files else {}
    rows = []
    fit_eligible_count = 0
    for control in controls:
        start, end, failures = base[control.control_uid]
        failures = list(failures)
        phase_overlaps = _event_overlaps(control, start, end, phases)
        if phase_overlaps:
            failures.append("CONTROL_EVENT_CONTEXT_OVERLAP")
        if overlap_controls[control.control_uid]:
            failures.append("CONTROL_INTERVAL_OVERLAP")
        coverage_row = coverage.get(control.control_uid, {
            "expected_window_count": None, "observed_window_count": None,
            "window_coverage_ratio": None, "feature_row_count": None,
            "quality_pass_ratio": None, "sensor_count": None,
            "feature_coverage_status": "NOT_CHECKED",
        })
        if coverage_row["feature_coverage_status"] != "PASS":
            failures.append("CONTROL_FEATURE_COVERAGE_REQUIRED")
        fit_eligible = control.review_status == "CONFIRMED_CONTROL" and not failures
        fit_eligible_count += int(fit_eligible)
        rows.append({
            **asdict(control),
            "duration_days": (end - start).total_seconds() / 86400 if start and end else None,
            "computed_event_overlap_status": "OVERLAP" if phase_overlaps else "NO_OVERLAP",
            "overlapping_phase_uids": "|".join(phase_overlaps),
            "overlapping_control_uids": "|".join(overlap_controls[control.control_uid]),
            **coverage_row,
            "fit_eligible": str(fit_eligible).lower(),
            "validation_status": "VALID_FOR_BASELINE_FIT" if fit_eligible else "NOT_ELIGIBLE",
            "failure_codes": "|".join(sorted(set(failures))),
        })
    validated_path = output / "validated_control_intervals.csv"
    write_csv(validated_path, rows)
    payload = {
        "contract_version": ANOMALY_CONTRACT_VERSION,
        "control_contract_version": CONTROL_CONTRACT_VERSION,
        "controls_source": content_identity(controls_resolved),
        "phases_source": content_identity(phases_resolved),
        "feature_sources": {
            scope: file_identity(path, include_sha256=False) for scope, path in (feature_files or {}).items()
        },
        "control_count": len(controls),
        "fit_eligible_count": fit_eligible_count,
        "validated_controls": {
            "sha256": sha256_file(validated_path), "size_bytes": validated_path.stat().st_size,
            "row_count": len(rows),
        },
        "safety": {
            "unconfirmed_control_used_for_fit": False,
            "unknown_operation_state_used_for_fit": False,
            "event_context_used_for_fit": False,
            "production_decision_allowed": False,
        },
    }
    receipt = canonical_sha256(payload)
    manifest = {**payload, "receipt_sha256": receipt}
    write_json(output / "control_manifest.json", manifest)
    compact = (
        f"ANOMALY_CONTROLS=VALID|CONTROLS:{len(controls)}|FIT:{fit_eligible_count}|"
        f"BLOCKED:{len(controls) - fit_eligible_count}|SHA:{receipt}\n"
    )
    (output / "control_review_receipt.txt").write_text(compact, encoding="utf-8")
    return manifest
