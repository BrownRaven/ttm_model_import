"""Read-only causal batch/shadow evaluator for a frozen M0 PoC bundle.

The command never writes to CMMS/WO/alarm APIs. Detailed score output remains in the field.
Only compact counts and hashes are suitable for manual transfer.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from anomaly_contract import AnomalyContractError, canonical_sha256, ensure_output_directory, require, require_columns, sha256_file, write_json
from anomaly_validated_workflow import M0_BUNDLE_CONTRACT, _bool

SHADOW_CONTRACT="PIMS-ANOMALY-M0-SHADOW-v1"
STATE_COLUMNS=["state_uid","asset_id","start_time","end_time","maintenance_epoch","operation_mode","operation_mode_status","health_state","health_state_status"]


def load_bundle(path: Path) -> dict[str,Any]:
    bundle=json.loads(path.expanduser().resolve().read_text(encoding="utf-8"))
    require(bundle.get("contract_version")==M0_BUNDLE_CONTRACT,"M0_BUNDLE_VERSION_INVALID",str(path))
    require(bundle.get("poc_only") is True and bundle.get("production_use_allowed") is False,"M0_BUNDLE_SAFETY_INVALID",str(path))
    require(bundle.get("future_data_allowed") is False and bundle.get("gap_fill_allowed") is False,"M0_BUNDLE_CAUSALITY_INVALID",str(path))
    return bundle


def load_states(path: Path) -> pd.DataFrame:
    frame=pd.read_csv(path,dtype=str).fillna(""); require_columns(frame.columns,STATE_COLUMNS,"SHADOW_STATE_HEADER_INVALID")
    require(frame["state_uid"].is_unique,"SHADOW_STATE_UID_DUPLICATE",str(path)); frame["start_utc"]=pd.to_datetime(frame["start_time"],utc=True,errors="coerce"); frame["end_utc"]=pd.to_datetime(frame["end_time"],utc=True,errors="coerce")
    require(not frame[["start_utc","end_utc"]].isna().any().any(),"SHADOW_STATE_TIME_INVALID",str(path)); require(bool((frame["end_utc"]>frame["start_utc"]).all()),"SHADOW_STATE_RANGE_INVALID",str(path))
    for asset,group in frame.groupby("asset_id"):
        ordered=group.sort_values("start_utc"); require(bool((ordered["start_utc"].iloc[1:].reset_index(drop=True)>=ordered["end_utc"].iloc[:-1].reset_index(drop=True)).all()),"SHADOW_STATE_OVERLAP",str(asset))
    return frame


def _score_chunks(bundle: dict[str,Any], feature_paths: list[Path], chunksize: int) -> tuple[dict[tuple[str,str,str],float],dict[tuple[str,str,str],int],dict[tuple[str,str,str],tuple[str,str,float]],dict[str,int]]:
    models={model["asset_id"]:model for model in bundle["models"]}; scores:dict[tuple[str,str,str],float]={}; match_counts:dict[tuple[str,str,str],int]={}; top_triggers:dict[tuple[str,str,str],tuple[str,str,float]]={}; counts={"scanned":0,"after_cutoff":0,"quality_blocked":0,"parameter_matches":0}
    for source in feature_paths:
        header=pd.read_csv(source,nrows=0).columns.tolist(); required=["window_start","window_end","asset_id","sensor_uid","quality_status"]; require_columns(header,required,"SHADOW_FEATURE_HEADER_INVALID")
        metric_columns=sorted({feature["metric"] for model in models.values() for feature in model["feature_parameters"]}); usecols=[column for column in [*required,*metric_columns] if column in header]
        for chunk in pd.read_csv(source,usecols=usecols,chunksize=chunksize,low_memory=False):
            counts["scanned"]+=len(chunk); ends=pd.to_datetime(chunk["window_end"],utc=True,errors="coerce"); require(not ends.isna().any(),"SHADOW_FEATURE_TIME_INVALID",str(source)); chunk=chunk.assign(_end_utc=ends)
            cutoff_mask=pd.Series(False,index=chunk.index)
            for asset,model in models.items(): cutoff_mask|=(chunk["asset_id"]==asset)&(chunk["_end_utc"]>pd.Timestamp(model["shadow_eligible_after"]))
            chunk=chunk[cutoff_mask]; counts["after_cutoff"]+=len(chunk); counts["quality_blocked"]+=int((chunk["quality_status"]!="PASS").sum()); chunk=chunk[chunk["quality_status"]=="PASS"]
            for asset,model in models.items():
                asset_rows=chunk[chunk["asset_id"]==asset]
                if asset_rows.empty: continue
                by_sensor:dict[str,list[dict[str,Any]]]={}
                for feature in model["feature_parameters"]: by_sensor.setdefault(feature["sensor_uid"],[]).append(feature)
                for sensor,parameters in by_sensor.items():
                    sensor_rows=asset_rows[asset_rows["sensor_uid"]==sensor]
                    if sensor_rows.empty: continue
                    for parameter in parameters:
                        metric=parameter["metric"]
                        if metric not in sensor_rows: continue
                        value=pd.to_numeric(sensor_rows[metric],errors="coerce"); score=(value-float(parameter["center"])).abs()/float(parameter["robust_scale"]); counts["parameter_matches"]+=int(value.notna().sum())
                        for index,score_value in score.dropna().items():
                            row=sensor_rows.loc[index]; key=(asset,str(row["window_start"]),str(row["window_end"])); numeric_score=float(score_value); match_counts[key]=match_counts.get(key,0)+1
                            if numeric_score>scores.get(key,-math.inf): scores[key]=numeric_score; top_triggers[key]=(sensor,metric,numeric_score)
    return scores,match_counts,top_triggers,counts


def _apply_states(windows: pd.DataFrame, states: pd.DataFrame, bundle: dict[str,Any]) -> pd.DataFrame:
    model_map={model["asset_id"]:model for model in bundle["models"]}; windows=windows.copy(); windows["start_utc"]=pd.to_datetime(windows["window_start"],utc=True); windows["end_utc"]=pd.to_datetime(windows["window_end"],utc=True); windows["mid_utc"]=windows["start_utc"]+(windows["end_utc"]-windows["start_utc"])/2
    state_values=[]
    for row in windows.itertuples():
        matches=states[(states["asset_id"]==row.asset_id)&(states["start_utc"]<=row.mid_utc)&(states["end_utc"]>row.mid_utc)]
        if len(matches)!=1: state_values.append(("UNKNOWN","UNKNOWN","UNKNOWN","UNKNOWN","UNMAPPED",False,"REVIEW_REQUIRED_NO_STATE")); continue
        state=matches.iloc[0]; model=model_map[row.asset_id]
        require(state["health_state"] in {"HEALTHY_STATE","UNHEALTHY_STATE","UNKNOWN"},"SHADOW_HEALTH_STATE_INVALID",str(state["state_uid"]))
        if state["maintenance_epoch"]!=model["maintenance_epoch"]: gate="FAIL_EPOCH_MISMATCH"
        elif state["operation_mode"]=="RUNNING" and str(state["operation_mode_status"]).startswith("CONFIRMED"): gate="PASS"
        elif state["operation_mode"] in {"STOPPED","STARTUP","SHUTDOWN","MAINTENANCE"} and str(state["operation_mode_status"]).startswith("CONFIRMED"): gate="FAIL_CONFIRMED_NON_RUNNING"
        else: gate="REVIEW_REQUIRED_OPERATION_MODE"
        state_values.append((state["operation_mode"],state["operation_mode_status"],state["health_state"],state["health_state_status"],state["maintenance_epoch"],gate=="PASS",gate))
    columns=["operation_mode","operation_mode_status","health_state","health_state_status","observed_maintenance_epoch","state_eligible","state_gate_status"]
    for position,column in enumerate(columns): windows[column]=[value[position] for value in state_values]
    return windows


def run_shadow(bundle_path: Path,state_path: Path,feature_paths:list[Path],output_dir:Path,chunksize:int,overwrite:bool)->dict[str,Any]:
    output=ensure_output_directory(output_dir,overwrite); bundle=load_bundle(bundle_path); states=load_states(state_path); score_map,match_counts,top_triggers,counts=_score_chunks(bundle,feature_paths,chunksize)
    expected_counts={model["asset_id"]:len(model["feature_parameters"]) for model in bundle["models"]}
    rows=[{"asset_id":key[0],"window_start":key[1],"window_end":key[2],"asset_score":value,"trigger_sensor_uid":top_triggers[key][0],"trigger_metric":top_triggers[key][1],"trigger_score":top_triggers[key][2],"scored_parameter_count":match_counts.get(key,0),"expected_parameter_count":expected_counts[key[0]],"feature_coverage_ratio":min(match_counts.get(key,0)/expected_counts[key[0]],1.0)} for key,value in score_map.items()]; require(bool(rows),"SHADOW_WINDOWS_EMPTY","No post-bundle score windows")
    windows=_apply_states(pd.DataFrame(rows),states,bundle); model_map={model["asset_id"]:model for model in bundle["models"]}; windows["threshold"]=[float(model_map[asset]["asset_threshold"]) for asset in windows["asset_id"]]; windows["minimum_consecutive_windows"]=[int(model_map[asset]["minimum_consecutive_windows"]) for asset in windows["asset_id"]]; windows["threshold_exceeded"]=windows["asset_score"]>windows["threshold"]
    windows["feature_coverage_eligible"]=windows["feature_coverage_ratio"]>=float(bundle["minimum_scored_parameter_ratio"])
    decisions=[]
    for asset,group in windows.groupby("asset_id",sort=True):
        machine_count=0; qualified_count=0; previous=None
        for row in group.sort_values("start_utc").itertuples():
            contiguous=previous is not None and row.start_utc-previous<=pd.Timedelta(minutes=5)
            machine_eligible=row.feature_coverage_eligible and row.threshold_exceeded
            machine_count=machine_count+1 if machine_eligible and contiguous and machine_count else (1 if machine_eligible else 0)
            qualified_eligible=machine_eligible and row.state_eligible
            qualified_count=qualified_count+1 if qualified_eligible and contiguous and qualified_count else (1 if qualified_eligible else 0)
            machine_candidate=machine_count>=row.minimum_consecutive_windows; candidate=qualified_count>=row.minimum_consecutive_windows
            if candidate: decision="POC_ANOMALY_CANDIDATE"
            elif machine_candidate and str(row.state_gate_status).startswith("FAIL_"): decision="POC_ANOMALY_PRE_CANDIDATE_STATE_REJECTED"
            elif machine_candidate: decision="POC_ANOMALY_PRE_CANDIDATE_REVIEW_REQUIRED"
            else: decision="NO_CANDIDATE"
            decisions.append({"asset_id":asset,"window_start":row.window_start,"window_end":row.window_end,"asset_score":row.asset_score,"asset_threshold":row.threshold,"trigger_sensor_uid":row.trigger_sensor_uid,"trigger_metric":row.trigger_metric,"trigger_score":row.trigger_score,"scored_parameter_count":row.scored_parameter_count,"expected_parameter_count":row.expected_parameter_count,"feature_coverage_ratio":row.feature_coverage_ratio,"feature_coverage_eligible":row.feature_coverage_eligible,"minimum_consecutive_windows":row.minimum_consecutive_windows,"machine_persistence_count":machine_count,"qualified_persistence_count":qualified_count,"machine_pre_candidate":machine_candidate,"threshold_exceeded":row.threshold_exceeded,"state_eligible":row.state_eligible,"state_gate_status":row.state_gate_status,"operation_mode":row.operation_mode,"health_state":row.health_state,"observed_maintenance_epoch":row.observed_maintenance_epoch,"decision":decision})
            previous=row.start_utc
    result=pd.DataFrame(decisions); detail_path=output/"m0_shadow_window_decisions.csv"; result.to_csv(detail_path,index=False)
    lines=[]
    for asset,group in result.groupby("asset_id",sort=True):
        machine=group["machine_pre_candidate"].map(_bool); candidate=group["decision"]=="POC_ANOMALY_CANDIDATE"; review=group["decision"]=="POC_ANOMALY_PRE_CANDIDATE_REVIEW_REQUIRED"; starts=candidate&~candidate.shift(fill_value=False); lines.append(f"VC15A|{asset}|W:{len(group)}|STATE_ELIG:{int(group['state_eligible'].map(_bool).sum())}|STATE_BLOCK:{int((~group['state_eligible'].map(_bool)).sum())}|FEATURE_BLOCK:{int((~group['feature_coverage_eligible'].map(_bool)).sum())}|HEALTH_UNKNOWN:{int((group['health_state']=='UNKNOWN').sum())}|EXCEED:{int(group['threshold_exceeded'].map(_bool).sum())}|PREW:{int(machine.sum())}|REVIEWW:{int(review.sum())}|CANDW:{int(candidate.sum())}|CANDEP:{int(starts.sum())}")
    payload={"contract_version":SHADOW_CONTRACT,"model_bundle_id":bundle["model_bundle_id"],"model_bundle_sha256":bundle["model_bundle_sha256"],"feature_source_sha256":[sha256_file(path) for path in feature_paths],"state_source_sha256":sha256_file(state_path),"scanned_rows":counts["scanned"],"post_cutoff_rows":counts["after_cutoff"],"quality_blocked_rows":counts["quality_blocked"],"decision_windows":len(result),"machine_pre_candidate_windows":int(result["machine_pre_candidate"].map(_bool).sum()),"review_required_windows":int((result["decision"]=="POC_ANOMALY_PRE_CANDIDATE_REVIEW_REQUIRED").sum()),"candidate_windows":int((result["decision"]=="POC_ANOMALY_CANDIDATE").sum()),"detail_lines":lines,"output_sha256":sha256_file(detail_path),"safety":{"external_write_allowed":False,"wo_allowed":False,"production_use_allowed":False,"raw_score_transfer_allowed":False}}
    sha=canonical_sha256(payload); manifest={**payload,"receipt_sha256":sha}; write_json(output/"vc15_manifest.json",manifest); receipt=f"VC15=VALID|MODEL:{bundle['model_bundle_id']}|SCANNED:{counts['scanned']}|POST:{counts['after_cutoff']}|W:{len(result)}|PREW:{payload['machine_pre_candidate_windows']}|REVIEWW:{payload['review_required_windows']}|CANDW:{payload['candidate_windows']}|SHA:{sha}"; (output/"vc15_receipt.txt").write_text(receipt+"\n",encoding="utf-8"); (output/"vc15_compact_detail.txt").write_text("\n".join(lines)+"\n",encoding="utf-8"); print(receipt); print("\n".join(lines)); return manifest


def parser()->argparse.ArgumentParser:
    value=argparse.ArgumentParser(description=__doc__); value.add_argument("--bundle",type=Path,required=True); value.add_argument("--states",type=Path,required=True); value.add_argument("--features",type=Path,nargs="+",required=True); value.add_argument("--output",type=Path,required=True); value.add_argument("--chunksize",type=int,default=200000); value.add_argument("--overwrite",action="store_true"); return value


def main()->int:
    args=parser().parse_args(); run_shadow(args.bundle,args.states,args.features,args.output,args.chunksize,args.overwrite); return 0

if __name__=="__main__":
    try: raise SystemExit(main())
    except AnomalyContractError as exc:
        print(f"M0_SHADOW=BLOCKED|CODE:{exc.code}"); raise SystemExit(2) from None
