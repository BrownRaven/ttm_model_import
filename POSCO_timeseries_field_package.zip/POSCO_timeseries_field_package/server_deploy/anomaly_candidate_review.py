"""Validate offline field decisions for machine-selected PoC candidate episodes."""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import pandas as pd

from anomaly_contract import AnomalyContractError, canonical_sha256, ensure_output_directory, require, require_columns, sha256_file, write_json

REVIEW_CONTRACT="PIMS-ANOMALY-CANDIDATE-FIELD-REVIEW-v1"
DECISIONS={"PENDING","CONFIRM_POC_CANDIDATE","REJECT_NON_RUNNING","REJECT_MAINTENANCE_CONTEXT","REJECT_EPOCH_MISMATCH","REJECT_SENSOR_ISSUE","INCONCLUSIVE"}
REQUIRED=["candidate_uid","field_decision","confirmed_operation_mode","maintenance_overlap","epoch_review_status","sensor_condition","process_context","reviewer_reference","reviewed_at","review_notes"]


def validate_review(index_path:Path,review_path:Path,output_dir:Path,overwrite:bool)->dict[str,Any]:
    output=ensure_output_directory(output_dir,overwrite); index=pd.read_csv(index_path,dtype=str).fillna(""); review=pd.read_csv(review_path,dtype=str).fillna(""); require_columns(index.columns,["candidate_uid","asset_id","episode_start","episode_end"],"CANDIDATE_INDEX_INVALID"); require_columns(review.columns,REQUIRED,"CANDIDATE_REVIEW_HEADER_INVALID")
    require(index["candidate_uid"].is_unique,"CANDIDATE_INDEX_UID_DUPLICATE",str(index_path)); require(review["candidate_uid"].is_unique,"CANDIDATE_REVIEW_UID_DUPLICATE",str(review_path)); require(set(index["candidate_uid"])==set(review["candidate_uid"]),"CANDIDATE_REVIEW_UID_SET_MISMATCH",str(review_path))
    issues=[]
    for row in review.to_dict(orient="records"):
        uid=row["candidate_uid"]; decision=row["field_decision"]
        if decision not in DECISIONS: issues.append((uid,"FIELD_DECISION_INVALID")); continue
        if decision=="PENDING": continue
        if not row["reviewer_reference"]: issues.append((uid,"REVIEWER_REFERENCE_REQUIRED"))
        if not row["reviewed_at"]: issues.append((uid,"REVIEWED_AT_REQUIRED"))
        else:
            timestamp=pd.to_datetime(row["reviewed_at"],errors="coerce")
            if pd.isna(timestamp) or timestamp.tzinfo is None: issues.append((uid,"REVIEWED_AT_OFFSET_REQUIRED"))
        if decision=="CONFIRM_POC_CANDIDATE":
            if row["confirmed_operation_mode"]!="RUNNING": issues.append((uid,"CONFIRM_RUNNING_REQUIRED"))
            if row["maintenance_overlap"]!="NO": issues.append((uid,"CONFIRM_NO_MAINTENANCE_REQUIRED"))
            if row["epoch_review_status"]!="MATCH": issues.append((uid,"CONFIRM_EPOCH_MATCH_REQUIRED"))
            if row["sensor_condition"]!="NO_SENSOR_ISSUE_CONFIRMED": issues.append((uid,"CONFIRM_SENSOR_REVIEW_REQUIRED"))
        if decision.startswith("REJECT_") and not row["review_notes"]: issues.append((uid,"REJECTION_NOTES_REQUIRED"))
    issue_frame=pd.DataFrame(issues,columns=["candidate_uid","issue_code"]); issue_path=output/"candidate_review_issues.csv"; issue_frame.to_csv(issue_path,index=False)
    require(issue_frame.empty,"CANDIDATE_FIELD_REVIEW_INVALID",str(issue_path))
    merged=index.merge(review[REQUIRED],on="candidate_uid",how="left",validate="one_to_one"); merged["production_use_allowed"]=False; merged["failure_confirmed"]=False; merged["causality_inferred"]=False; result_path=output/"reviewed_candidate_decisions.csv"; merged.to_csv(result_path,index=False)
    counts=merged["field_decision"].value_counts(); lines=[]
    for asset,group in merged.groupby("asset_id",sort=True): lines.append(f"VC17A|{asset}|TOTAL:{len(group)}|CONFIRM:{int((group['field_decision']=='CONFIRM_POC_CANDIDATE').sum())}|REJECT:{int(group['field_decision'].str.startswith('REJECT_').sum())}|INCONCLUSIVE:{int((group['field_decision']=='INCONCLUSIVE').sum())}|PENDING:{int((group['field_decision']=='PENDING').sum())}")
    payload={"contract_version":REVIEW_CONTRACT,"candidate_index_sha256":sha256_file(index_path),"review_source_sha256":sha256_file(review_path),"candidate_count":len(merged),"confirmed_count":int(counts.get("CONFIRM_POC_CANDIDATE",0)),"rejected_count":int(sum(count for decision,count in counts.items() if str(decision).startswith("REJECT_"))),"inconclusive_count":int(counts.get("INCONCLUSIVE",0)),"pending_count":int(counts.get("PENDING",0)),"detail_lines":lines,"output_sha256":sha256_file(result_path),"safety":{"production_use_allowed":False,"failure_confirmed":False,"causality_inferred":False,"external_write_allowed":False}}
    sha=canonical_sha256(payload); manifest={**payload,"receipt_sha256":sha}; write_json(output/"vc17_manifest.json",manifest); receipt=f"VC17=VALID|TOTAL:{len(merged)}|CONFIRM:{payload['confirmed_count']}|REJECT:{payload['rejected_count']}|INCONCLUSIVE:{payload['inconclusive_count']}|PENDING:{payload['pending_count']}|SHA:{sha}"; (output/"vc17_receipt.txt").write_text(receipt+"\n",encoding="utf-8"); (output/"vc17_compact_detail.txt").write_text("\n".join(lines)+"\n",encoding="utf-8"); print(receipt); print("\n".join(lines)); return manifest


def parser()->argparse.ArgumentParser:
    value=argparse.ArgumentParser(description=__doc__); value.add_argument("--candidate-index",type=Path,required=True); value.add_argument("--reviews",type=Path,required=True); value.add_argument("--output",type=Path,required=True); value.add_argument("--overwrite",action="store_true"); return value


def main()->int:
    args=parser().parse_args(); validate_review(args.candidate_index,args.reviews,args.output,args.overwrite); return 0

if __name__=="__main__":
    try: raise SystemExit(main())
    except AnomalyContractError as exc:
        print(f"CANDIDATE_REVIEW=BLOCKED|CODE:{exc.code}"); raise SystemExit(2) from None
