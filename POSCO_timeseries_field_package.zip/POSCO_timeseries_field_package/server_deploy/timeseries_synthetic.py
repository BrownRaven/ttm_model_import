"""Generate deterministic Synthetic 3S/4S wide time-series fixtures.

Only the confirmed CSV shape, header names, timestamp representation, units, and
one-second cadence are retained. Source sample values are not copied. All waveforms,
incidents, lags, and correlations are artificial and prohibited for production use.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Sequence

SERVER_DEPLOY = Path(__file__).resolve().parent
CONFIG_DIR = SERVER_DEPLOY / "config" / "timeseries"
DEFAULT_OUTPUT_DIR = SERVER_DEPLOY / "fixtures" / "timeseries_synthetic"
CONTRACT_VERSION = "PIMS-TS-SYNTHETIC-SHAPE-v1"
SAMPLE_COUNT = 1_800
SEED = 20260831


@dataclass(frozen=True)
class SyntheticDataset:
    name: str
    config_path: Path
    output_name: str
    events_name: str
    start: datetime
    asset_event_offsets: dict[str, tuple[int, int]]


DATASETS = (
    SyntheticDataset(
        name="3S",
        config_path=CONFIG_DIR / "sinter3_wide_1s.json",
        output_name="synthetic_3s_wide_1s.csv",
        events_name="synthetic_3s_reference_events.csv",
        start=datetime(2026, 12, 8, 0, 27, 22, 140_000),
        asset_event_offsets={"M-317": (600, 720), "M-319": (960, 1_080)},
    ),
    SyntheticDataset(
        name="4S",
        config_path=CONFIG_DIR / "sinter4_wide_1s.json",
        output_name="synthetic_4s_wide_1s.csv",
        events_name="synthetic_4s_reference_events.csv",
        start=datetime(2026, 2, 2, 0, 14, 54, 850_000),
        asset_event_offsets={"M-417": (600, 720), "M-419": (960, 1_080)},
    ),
)


def _config(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _baseline(sensor: dict[str, Any], index: int) -> tuple[float, float]:
    measurement = sensor["measurement_type"]
    asset_shift = (sum(ord(char) for char in sensor["asset_id"]) % 7) * 0.7
    if measurement == "MOTOR_CURRENT":
        return 64.0 + asset_shift + index * 0.35, 0.55
    if measurement == "LUBE_OIL_FLOW":
        return 53.0 + asset_shift, 0.08
    if measurement == "LUBE_OIL_PRESSURE":
        return 2.35 + asset_shift * 0.03, 0.004
    if measurement == "LUBE_OIL_TEMPERATURE":
        return 61.0 + asset_shift, 0.025
    if "REDUCER" in measurement:
        return 68.0 + asset_shift + index * 0.2, 0.035
    if "WINDING" in measurement or "PHASE" in measurement:
        return 43.0 + asset_shift + index * 0.12, 0.025
    return 29.0 + asset_shift + index * 0.1, 0.018


def _synthetic_value(
    sensor: dict[str, Any], sensor_index: int, second: int,
    event_start: int, event_end: int, rng: random.Random,
) -> float:
    measurement = sensor["measurement_type"]
    baseline, noise = _baseline(sensor, sensor_index)
    slow = 0.18 * math.sin(2.0 * math.pi * second / 900.0 + sensor_index * 0.31)
    value = baseline + slow + rng.gauss(0.0, noise)

    if measurement == "MOTOR_CURRENT":
        value += 1.1 * math.sin(2.0 * math.pi * second / 17.0 + sensor_index)
        if event_start <= second < event_end:
            value += 11.0 + 4.5 * math.sin(2.0 * math.pi * (second - event_start) / 7.0)
    elif measurement == "LUBE_OIL_FLOW":
        if event_start + 15 <= second < event_end:
            value -= 5.0 + 0.8 * math.sin(2.0 * math.pi * (second - event_start) / 19.0)
    elif measurement == "LUBE_OIL_PRESSURE":
        if event_start + 20 <= second < event_end:
            value -= 0.28
    elif measurement == "LUBE_OIL_TEMPERATURE":
        if event_start + 30 <= second < event_end + 120:
            progress = min((second - event_start - 30) / 120.0, 1.0)
            value += 3.8 * max(progress, 0.0)
    elif "TEMPERATURE" in measurement:
        if event_start + 60 <= second < event_end + 180:
            progress = min((second - event_start - 60) / 180.0, 1.0)
            value += 2.4 * max(progress, 0.0)
    return value


def _format_value(value: float, measurement_type: str) -> str:
    if measurement_type in {"MOTOR_CURRENT", "LUBE_OIL_PRESSURE"}:
        return f"{value:.4f}"
    if measurement_type == "LUBE_OIL_FLOW":
        return f"{value:.2f}"
    return f"{value:.3f}"


def _write_dataset(dataset: SyntheticDataset, output_dir: Path, sample_count: int, seed: int) -> dict[str, Any]:
    config = _config(dataset.config_path)
    sensors = config["sensors"]
    destination = output_dir / dataset.output_name
    events_destination = output_dir / dataset.events_name
    rng = random.Random(seed + sum(ord(char) for char in dataset.name))

    with destination.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter=";", lineterminator="\r\n")
        writer.writerow([config["timestamp"]["column"], *(sensor["source_column"] for sensor in sensors)])
        for second in range(sample_count):
            timestamp = dataset.start + timedelta(seconds=second)
            row = [timestamp.strftime("%d.%m.%Y %H:%M:%S.%f")]
            for sensor_index, sensor in enumerate(sensors):
                event_start, event_end = dataset.asset_event_offsets[sensor["asset_id"]]
                value = _synthetic_value(sensor, sensor_index, second, event_start, event_end, rng)
                row.append(_format_value(value, sensor["measurement_type"]))
            writer.writerow(row)

    with events_destination.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["event_uid", "start_time", "end_time", "asset_id", "sensor_uid", "label", "source_ref"])
        for asset_id, (event_start, event_end) in dataset.asset_event_offsets.items():
            writer.writerow([
                f"SYNTHETIC-{dataset.name}-{asset_id}-EVENT",
                (dataset.start + timedelta(seconds=event_start)).isoformat() + "+09:00",
                (dataset.start + timedelta(seconds=event_end)).isoformat() + "+09:00",
                asset_id,
                "",
                "SYNTHETIC_ARTIFICIAL_MOVEMENT",
                f"{CONTRACT_VERSION}:{dataset.output_name}",
            ])

    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    return {
        "dataset": dataset.name,
        "csv_file": destination.name,
        "reference_events_file": events_destination.name,
        "sha256": digest,
        "table_row_count": sample_count,
        "sensor_count": len(sensors),
        "canonical_value_count": sample_count * len(sensors),
        "config_sha256": hashlib.sha256(dataset.config_path.read_bytes()).hexdigest(),
        "units": {sensor["source_column"]: sensor["unit"] for sensor in sensors},
        "start_time": dataset.start.isoformat() + "+09:00",
        "end_time": (dataset.start + timedelta(seconds=sample_count - 1)).isoformat() + "+09:00",
        "delimiter": ";",
        "timestamp_column": "time",
        "dayfirst": True,
        "expected_interval_seconds": 1,
        "source_values_copied": False,
    }


def generate(output_dir: Path = DEFAULT_OUTPUT_DIR, sample_count: int = SAMPLE_COUNT, seed: int = SEED) -> dict[str, Any]:
    if sample_count < 600:
        raise ValueError("sample_count must be at least 600 for complete five-minute smoke windows")
    output_dir = output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    datasets = [_write_dataset(dataset, output_dir, sample_count, seed) for dataset in DATASETS]
    manifest = {
        "contract_version": CONTRACT_VERSION,
        "synthetic_only": True,
        "production_use_allowed": False,
        "model_training_allowed": False,
        "threshold_tuning_allowed": False,
        "actual_source_values_copied": False,
        "shape_contract_source": "LOCAL_3S_4S_THREE_ROW_SAMPLES",
        "seed": seed,
        "datasets": datasets,
        "limitations": [
            "ARTIFICIAL_WAVEFORMS",
            "ARTIFICIAL_INCIDENTS",
            "ARTIFICIAL_LAGS",
            "ARTIFICIAL_CORRELATIONS",
            "NO_OPERATING_STATE",
            "NO_ACTUAL_THRESHOLD",
        ],
    }
    manifest_path = output_dir / "synthetic_timeseries_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--sample-count", type=int, default=SAMPLE_COUNT)
    parser.add_argument("--seed", type=int, default=SEED)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    print(json.dumps(generate(args.output_dir, args.sample_count, args.seed), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
