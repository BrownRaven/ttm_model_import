"""Render field-only sensor time-series figures around machine candidate episodes.

Uses 5-minute Feature mean values, Statsmodels LOWESS, and a standard-library SVG renderer.
Figures contain actual field values and MUST remain inside the field environment.
"""
from __future__ import annotations

import argparse
from html import escape
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from anomaly_contract import AnomalyContractError, ASSET_SCOPE, canonical_sha256, ensure_output_directory, require, require_columns, sha256_file, write_json

FIGURE_CONTRACT="PIMS-ANOMALY-CANDIDATE-SENSOR-FIGURE-v1"
REQUIRED_FEATURES=["window_start","window_end","asset_id","sensor_uid","measurement_type","unit","quality_status","mean"]


def _statsmodels() -> Any:
    try:
        import statsmodels.api as sm
    except ImportError as exc:
        raise AnomalyContractError("STATSMODELS_REQUIRED","Use the approved field Statsmodels build") from exc
    return sm


def collect_plot_data(candidates:pd.DataFrame,feature_paths:list[Path],context_hours:float,chunksize:int)->tuple[pd.DataFrame,int]:
    selected=[]; scanned=0; intervals=[]
    for row in candidates.itertuples(index=False):
        start=pd.Timestamp(row.episode_start).tz_convert("UTC")-pd.Timedelta(hours=context_hours); end=pd.Timestamp(row.episode_end).tz_convert("UTC")+pd.Timedelta(hours=context_hours)
        intervals.append((str(row.candidate_uid),str(row.asset_id),start,end))
    for source in feature_paths:
        header=pd.read_csv(source,nrows=0).columns.tolist(); require_columns(header,REQUIRED_FEATURES,"CANDIDATE_FIGURE_FEATURE_HEADER_INVALID"); usecols=[*REQUIRED_FEATURES,*(["coverage_ratio"] if "coverage_ratio" in header else [])]
        for chunk in pd.read_csv(source,usecols=usecols,chunksize=chunksize,low_memory=False):
            scanned+=len(chunk); starts=pd.to_datetime(chunk["window_start"],utc=True,errors="coerce"); require(not starts.isna().any(),"CANDIDATE_FIGURE_TIME_INVALID",str(source)); numeric=pd.to_numeric(chunk["mean"],errors="coerce")
            for candidate_uid,asset,start,end in intervals:
                mask=(chunk["asset_id"]==asset)&(starts>=start)&(starts<end)
                if not mask.any(): continue
                part=chunk.loc[mask].copy(); part.insert(0,"candidate_uid",candidate_uid); part["plot_time_utc"]=starts.loc[mask]; part["plot_value"]=numeric.loc[mask]; selected.append(part)
    require(bool(selected),"CANDIDATE_FIGURE_DATA_EMPTY","No Feature values matched candidate contexts")
    return pd.concat(selected,ignore_index=True),scanned


def _continuous_groups(frame:pd.DataFrame)->list[pd.DataFrame]:
    ordered=frame.sort_values("plot_time_utc"); breaks=ordered["plot_time_utc"].diff().gt(pd.Timedelta(minutes=10))|ordered["plot_time_utc"].diff().isna(); return [group for _,group in ordered.groupby(breaks.cumsum())]


def _render(candidate:pd.Series,data:pd.DataFrame,path:Path,context_hours:float,lowess_fraction:float)->int:
    sm=_statsmodels(); sensors=sorted(data["sensor_uid"].astype(str).unique()); width,left,right,top,panel_height,gap=1600,155,55,125,220,25; height=top+len(sensors)*(panel_height+gap)+65
    start=pd.Timestamp(candidate["episode_start"]).tz_convert("UTC")-pd.Timedelta(hours=context_hours); end=pd.Timestamp(candidate["episode_end"]).tz_convert("UTC")+pd.Timedelta(hours=context_hours); episode_start=pd.Timestamp(candidate["episode_start"]).tz_convert("UTC"); episode_end=pd.Timestamp(candidate["episode_end"]).tz_convert("UTC")
    trigger_labels=[str(candidate.get(f"top_trigger_{index}","")) for index in range(1,4) if str(candidate.get(f"top_trigger_{index}","")) not in {"","NONE"}]; trigger_sensors={label.split("::",1)[0] for label in trigger_labels}
    def xpos(ts:pd.Timestamp)->float: return left+(ts.value-start.value)/max(end.value-start.value,1)*(width-left-right)
    svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">','<rect width="100%" height="100%" fill="white"/>','<style>text{font-family:Arial,"Malgun Gothic","Noto Sans KR",sans-serif;fill:#172033}.grid{stroke:#e2e8f0;stroke-width:1}.actual{fill:none;stroke:#64748b;stroke-width:1}.smooth{fill:none;stroke:#2563eb;stroke-width:2}.small{font-size:11px}</style>',f'<text x="{left}" y="30" font-size="20" font-weight="bold">{escape(str(candidate["candidate_uid"]))} / {escape(str(candidate["asset_id"]))} — 실제 5분 Sensor Mean</text>',f'<text x="{left}" y="55" font-size="13">회색: quality PASS 실제 5분 mean · 파랑: Statsmodels LOWESS · 빨강 영역: machine pre-candidate episode</text>',f'<text x="{left}" y="78" font-size="12" fill="#b91c1c">현장 내부 전용 실제 값 Figure · POC candidate ≠ 고장/원인 확정</text>',f'<text x="{left}" y="99" font-size="11">Top score triggers: {escape(" | ".join(trigger_labels) if trigger_labels else "NOT_AVAILABLE")}</text>']
    for panel_index,sensor in enumerate(sensors):
        panel=data[data["sensor_uid"]==sensor].sort_values("plot_time_utc"); valid=panel[(panel["quality_status"]=="PASS")&panel["plot_value"].notna()]; panel_top=top+panel_index*(panel_height+gap); plot_top,plot_bottom=panel_top+28,panel_top+panel_height-35; unit=str(panel.iloc[0]["unit"]); measurement=str(panel.iloc[0]["measurement_type"])
        panel_fill="#fffbeb" if sensor in trigger_sensors else "#fff"; trigger_marker=" · TOP TRIGGER SENSOR" if sensor in trigger_sensors else ""
        svg.extend([f'<rect x="{left}" y="{plot_top}" width="{width-left-right}" height="{plot_bottom-plot_top}" fill="{panel_fill}" stroke="#cbd5e1"/>',f'<text x="{left}" y="{panel_top+17}" font-size="13" font-weight="bold">{escape(sensor)} · {escape(measurement)} [{escape(unit)}]{escape(trigger_marker)}</text>'])
        x1,x2=xpos(episode_start),xpos(episode_end); svg.append(f'<rect x="{x1:.2f}" y="{plot_top}" width="{max(x2-x1,2):.2f}" height="{plot_bottom-plot_top}" fill="#ef4444" opacity="0.14"/>')
        if valid.empty:
            svg.append(f'<text x="{left+20}" y="{plot_top+35}" font-size="12">No quality-PASS values in context</text>'); continue
        y_min,y_max=float(valid["plot_value"].min()),float(valid["plot_value"].max()); padding=max((y_max-y_min)*.08,abs(y_max)*.001,1e-9); y_min-=padding; y_max+=padding
        def ypos(value:float)->float: return plot_bottom-(value-y_min)/max(y_max-y_min,1e-12)*(plot_bottom-plot_top)
        for tick in range(5):
            y=plot_top+tick*(plot_bottom-plot_top)/4; value=y_max-tick*(y_max-y_min)/4; svg.extend([f'<line x1="{left}" y1="{y:.2f}" x2="{width-right}" y2="{y:.2f}" class="grid"/>',f'<text x="{left-8}" y="{y+4:.2f}" text-anchor="end" class="small">{value:.5g}</text>'])
        for tick in range(7):
            timestamp=start+(end-start)*tick/6; x=xpos(timestamp); svg.append(f'<line x1="{x:.2f}" y1="{plot_top}" x2="{x:.2f}" y2="{plot_bottom}" class="grid"/>')
            if panel_index==len(sensors)-1: svg.append(f'<text x="{x:.2f}" y="{plot_bottom+19}" text-anchor="middle" class="small">{timestamp.strftime("%m-%d %H:%M")}</text>')
        for segment in _continuous_groups(valid):
            points=" ".join(f'{xpos(row.plot_time_utc):.2f},{ypos(float(row.plot_value)):.2f}' for row in segment.itertuples())
            if len(segment)>1: svg.append(f'<polyline points="{points}" class="actual"/>')
            if len(segment)>=8:
                values=segment["plot_value"].to_numpy(dtype=float); smooth=sm.nonparametric.lowess(values,np.arange(len(values)),frac=lowess_fraction,return_sorted=False); smooth_points=" ".join(f'{xpos(timestamp):.2f},{ypos(float(value)):.2f}' for timestamp,value in zip(segment["plot_time_utc"],smooth)); svg.append(f'<polyline points="{smooth_points}" class="smooth"/>')
        blocked=int((panel["quality_status"]!="PASS").sum()); svg.append(f'<text x="{width-right-5}" y="{panel_top+17}" text-anchor="end" class="small">PASS={len(valid)} · blocked={blocked} · min={float(valid["plot_value"].min()):.5g} · max={float(valid["plot_value"].max()):.5g}</text>')
    svg.append(f'<text x="{left}" y="{height-20}" font-size="12">현장 검수 질문: 운전모드/정비/부하변화/센서 이상/동시 센서 반응을 확인하십시오. 값은 외부 반출 금지.</text>'); svg.append('</svg>'); path.write_text("\n".join(svg)+"\n",encoding="utf-8"); return len(sensors)


def build_figures(candidates_path:Path,feature_paths:list[Path],output_dir:Path,context_hours:float,lowess_fraction:float,chunksize:int,overwrite:bool)->dict[str,Any]:
    require(context_hours>0,"CANDIDATE_FIGURE_CONTEXT_INVALID",str(context_hours)); require(0<lowess_fraction<=1,"CANDIDATE_FIGURE_LOWESS_INVALID",str(lowess_fraction)); output=ensure_output_directory(output_dir,overwrite); candidates=pd.read_csv(candidates_path,dtype=str).fillna(""); require_columns(candidates.columns,["candidate_uid","asset_id","episode_start","episode_end"],"CANDIDATE_INDEX_INVALID"); data,scanned=collect_plot_data(candidates,feature_paths,context_hours,chunksize); data_path=output/"candidate_sensor_plot_data.csv"; data.to_csv(data_path,index=False); figure_dir=output/"figures"; figure_dir.mkdir(); index_rows=[]
    for _,candidate in candidates.iterrows():
        subset=data[data["candidate_uid"]==candidate["candidate_uid"]]; path=figure_dir/f'{candidate["candidate_uid"]}_sensor_values.svg'; sensor_count=_render(candidate,subset,path,context_hours,lowess_fraction); index_rows.append({"candidate_uid":candidate["candidate_uid"],"asset_id":candidate["asset_id"],"figure_file":path.name,"sensor_count":sensor_count,"context_hours_before":context_hours,"context_hours_after":context_hours,"actual_values_included":True,"field_only":True})
    index=pd.DataFrame(index_rows); index_path=output/"candidate_sensor_figure_index.csv"; index.to_csv(index_path,index=False); lines=[]
    for asset,group in index.groupby("asset_id",sort=True): lines.append(f"VC18A|{asset}|EP:{len(group)}|FIG:{len(group)}|SENSOR_PANELS:{int(group['sensor_count'].sum())}")
    payload={"contract_version":FIGURE_CONTRACT,"candidate_index_sha256":sha256_file(candidates_path),"feature_source_sha256":[sha256_file(path) for path in feature_paths],"scanned_rows":scanned,"selected_plot_rows":len(data),"candidate_count":len(index),"figure_count":len(index),"sensor_panel_count":int(index["sensor_count"].sum()),"context_hours":context_hours,"lowess_fraction":lowess_fraction,"detail_lines":lines,"outputs":{"plot_data_sha256":sha256_file(data_path),"index_sha256":sha256_file(index_path),"figure_sha256":{row["figure_file"]:sha256_file(figure_dir/row["figure_file"]) for row in index_rows}},"safety":{"actual_values_present":True,"field_only":True,"external_transfer_allowed":False,"failure_confirmed":False,"causality_inferred":False,"production_use_allowed":False}}
    sha=canonical_sha256(payload); manifest={**payload,"receipt_sha256":sha}; write_json(output/"vc18_manifest.json",manifest); receipt=f"VC18=VALID|EP:{len(index)}|FIG:{len(index)}|PANELS:{payload['sensor_panel_count']}|SCANNED:{scanned}|PLOT_ROWS:{len(data)}|SHA:{sha}"; (output/"vc18_receipt.txt").write_text(receipt+"\n",encoding="utf-8"); (output/"vc18_compact_detail.txt").write_text("\n".join(lines)+"\n",encoding="utf-8"); print(receipt); print("\n".join(lines)); return manifest


def parser()->argparse.ArgumentParser:
    value=argparse.ArgumentParser(description=__doc__); value.add_argument("--candidates",type=Path,required=True); value.add_argument("--features",type=Path,nargs="+",required=True); value.add_argument("--output",type=Path,required=True); value.add_argument("--context-hours",type=float,default=24); value.add_argument("--lowess-fraction",type=float,default=.08); value.add_argument("--chunksize",type=int,default=200000); value.add_argument("--overwrite",action="store_true"); return value


def main()->int:
    args=parser().parse_args(); build_figures(args.candidates,args.features,args.output,args.context_hours,args.lowess_fraction,args.chunksize,args.overwrite); return 0

if __name__=="__main__":
    try: raise SystemExit(main())
    except AnomalyContractError as exc:
        print(f"CANDIDATE_FIGURE=BLOCKED|CODE:{exc.code}"); raise SystemExit(2) from None
