"""Shared contracts and deterministic artifact helpers for anomaly analysis."""

from __future__ import annotations

import csv
import hashlib
import json
import os
import tempfile
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

ANOMALY_CONTRACT_VERSION = "PIMS-ANOMALY-ANALYSIS-v1"
PHASE_CONTRACT_VERSION = "PIMS-ANOMALY-PHASE-v1"
CONTROL_CONTRACT_VERSION = "PIMS-ANOMALY-CONTROL-v1"
ASSET_SCOPE = {"M-317": "3S", "M-319": "3S", "M-417": "4S", "M-419": "4S"}


class AnomalyContractError(RuntimeError):
    """Stable failure with a machine-readable code."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code


@dataclass(frozen=True)
class PhaseInterval:
    phase_uid: str
    occurrence_uid: str
    event_uid: str
    priority: int
    event_score: int
    asset_id: str
    phase: str
    phase_order: int
    start_time: str
    end_time: str
    event_start: str
    event_end: str
    event_time_precision: str
    label_status: str
    lead_time_eligible: bool
    source_ref: str

    def as_row(self) -> dict[str, Any]:
        row = asdict(self)
        row["lead_time_eligible"] = str(self.lead_time_eligible).lower()
        return row


@dataclass(frozen=True)
class ControlInterval:
    control_uid: str
    asset_id: str
    start_time: str
    end_time: str
    timezone: str
    operation_state: str
    operation_state_status: str
    maintenance_overlap_status: str
    communication_status: str
    event_exclusion_status: str
    review_status: str
    reviewed_by_ref: str
    reviewed_at: str
    source_ref: str
    notes: str


def require(condition: bool, code: str, message: str) -> None:
    if not condition:
        raise AnomalyContractError(code, message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.expanduser().resolve().open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_sha256(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def file_identity(path: Path, include_sha256: bool = True) -> dict[str, Any]:
    resolved = path.expanduser().resolve()
    stat = resolved.stat()
    identity = {
        "path": str(resolved),
        "size_bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
    }
    if include_sha256:
        identity["sha256"] = sha256_file(resolved)
    return identity


def content_identity(path: Path) -> dict[str, Any]:
    resolved = path.expanduser().resolve()
    return {"size_bytes": resolved.stat().st_size, "sha256": sha256_file(resolved)}


def parse_offset_datetime(value: str, field: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as exc:
        raise AnomalyContractError("TIME_INVALID", f"{field}={value}") from exc
    require(parsed.tzinfo is not None and parsed.utcoffset() is not None, "TIMEZONE_REQUIRED", field)
    return parsed


def _atomic_replace(path: Path, writer: Any) -> None:
    path = path.expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        writer(temporary)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def write_json(path: Path, value: Mapping[str, Any]) -> None:
    def writer(temporary: Path) -> None:
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    _atomic_replace(path, writer)


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]], fieldnames: Sequence[str] | None = None) -> None:
    names = list(fieldnames or (list(rows[0]) if rows else []))
    require(bool(names), "CSV_FIELDNAMES_REQUIRED", str(path))

    def writer(temporary: Path) -> None:
        with temporary.open("w", encoding="utf-8", newline="") as handle:
            csv_writer = csv.DictWriter(handle, fieldnames=names, extrasaction="raise")
            csv_writer.writeheader()
            csv_writer.writerows(rows)
    _atomic_replace(path, writer)


def ensure_output_directory(path: Path, overwrite: bool) -> Path:
    resolved = path.expanduser().resolve()
    if resolved.exists() and any(resolved.iterdir()) and not overwrite:
        raise AnomalyContractError("OUTPUT_EXISTS", str(resolved))
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.expanduser().resolve().open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def require_columns(observed: Iterable[str], required: Iterable[str], code: str) -> None:
    missing = sorted(set(required) - set(observed))
    require(not missing, code, "|".join(missing))
