"""Scalable 1-second sensor EDA and feature extraction for wide PIMS CSV files.

The pipeline is intentionally read-only and threshold-free. It profiles source quality,
extracts window features, and optionally links known event intervals as reference labels.
An unlabelled window is never treated as a confirmed normal window, and lag correlation
is never treated as causality.

Target runtime: Python 3.12.11, NumPy 2.5.1, pandas 3.0.5, PyTorch 2.12.1.
"""

from __future__ import annotations

import argparse
import csv
import glob
import multiprocessing as mp
import time
from collections import deque
from concurrent.futures import Future, ProcessPoolExecutor
import hashlib
import json
import math
import os
import platform
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

import numpy as np
import pandas as pd
import torch

try:
    import pyarrow as pa
    import pyarrow.parquet as pq
except ImportError:  # CSV-only environments remain supported.
    pa = None
    pq = None

CONTRACT_VERSION = "PIMS-TS-EDA-FEATURE-v1"
BUILD_VERSION = "DUP-AUDIT-v5"
TARGET_VERSIONS = {
    "python": "3.12.11",
    "numpy": "2.5.1",
    "pandas": "3.0.5",
    "torch": "2.12.1",
    "pyarrow": "25.0.0",
}


class PipelineError(RuntimeError):
    """Stable, user-facing pipeline failure."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code


@dataclass(frozen=True)
class SensorSpec:
    source_column: str
    sensor_uid: str
    asset_id: str
    measurement_type: str
    unit: str | None
    unit_status: str


@dataclass(frozen=True)
class PipelineConfig:
    path: Path
    raw: dict[str, Any]
    dataset_id: str
    mapping_status: str
    asset_mapping_status: str
    delimiter: str
    encoding: str
    timestamp_column: str
    timestamp_format: str | None
    dayfirst: bool
    timezone: str
    timezone_status: str
    time_semantics: str
    expected_interval_seconds: float
    allow_extra_columns: bool
    sensors: tuple[SensorSpec, ...]
    window_seconds: int
    stride_seconds: int
    min_coverage_ratio: float
    spectral_max_missing_ratio: float
    flatline_epsilon: float
    robust_z_threshold: float
    correlation_lags_seconds: tuple[int, ...]

    @property
    def expected_columns(self) -> list[str]:
        return [self.timestamp_column, *(sensor.source_column for sensor in self.sensors)]

    @property
    def config_sha256(self) -> str:
        return hashlib.sha256(self.path.read_bytes()).hexdigest()


def _require(condition: bool, code: str, message: str) -> None:
    if not condition:
        raise PipelineError(code, message)


def load_config(path: Path) -> PipelineConfig:
    path = path.expanduser().resolve()
    raw = json.loads(path.read_text(encoding="utf-8"))
    _require(raw.get("contract_version") == CONTRACT_VERSION, "CONFIG_VERSION_INVALID", str(path))
    csv_contract = raw["csv"]
    timestamp = raw["timestamp"]
    feature = raw["feature_extraction"]
    sensors = tuple(
        SensorSpec(
            source_column=str(item["source_column"]),
            sensor_uid=str(item["sensor_uid"]),
            asset_id=str(item["asset_id"]),
            measurement_type=str(item["measurement_type"]),
            unit=item.get("unit"),
            unit_status=str(item.get("unit_status", "MAPPING_REQUIRED")),
        )
        for item in raw["sensors"]
    )
    _require(len(sensors) > 0, "CONFIG_SENSOR_REQUIRED", str(path))
    _require(len({item.source_column for item in sensors}) == len(sensors), "CONFIG_DUPLICATE_COLUMN", str(path))
    _require(len({item.sensor_uid for item in sensors}) == len(sensors), "CONFIG_DUPLICATE_SENSOR", str(path))
    delimiter = str(csv_contract["delimiter"])
    _require(len(delimiter) == 1, "CONFIG_DELIMITER_INVALID", repr(delimiter))
    expected_interval = float(timestamp["expected_interval_seconds"])
    window_seconds = int(feature["window_seconds"])
    stride_seconds = int(feature["stride_seconds"])
    _require(expected_interval > 0, "CONFIG_INTERVAL_INVALID", str(expected_interval))
    _require(window_seconds > 0 and stride_seconds > 0, "CONFIG_WINDOW_INVALID", str(feature))
    _require(window_seconds % expected_interval == 0, "CONFIG_WINDOW_INTERVAL_MISMATCH", str(feature))
    return PipelineConfig(
        path=path,
        raw=raw,
        dataset_id=str(raw["dataset_id"]),
        mapping_status=str(raw.get("mapping_status", "UNCONFIRMED")),
        asset_mapping_status=str(raw.get("asset_mapping_status", "UNCONFIRMED")),
        delimiter=delimiter,
        encoding=str(csv_contract.get("encoding", "utf-8-sig")),
        timestamp_column=str(timestamp["column"]),
        timestamp_format=timestamp.get("format"),
        dayfirst=bool(timestamp.get("dayfirst", False)),
        timezone=str(timestamp["timezone"]),
        timezone_status=str(timestamp.get("timezone_status", "UNCONFIRMED")),
        time_semantics=str(timestamp.get("time_semantics", "UNCONFIRMED")),
        expected_interval_seconds=expected_interval,
        allow_extra_columns=bool(csv_contract.get("allow_extra_columns", False)),
        sensors=sensors,
        window_seconds=window_seconds,
        stride_seconds=stride_seconds,
        min_coverage_ratio=float(feature.get("min_coverage_ratio", 0.95)),
        spectral_max_missing_ratio=float(feature.get("spectral_max_missing_ratio", 0.01)),
        flatline_epsilon=float(feature.get("flatline_epsilon", 0.0)),
        robust_z_threshold=float(feature.get("robust_z_threshold", 6.0)),
        correlation_lags_seconds=tuple(int(value) for value in feature.get("correlation_lags_seconds", [0, 1, 5, 10, 30])),
    )


def runtime_versions(strict: bool = False) -> dict[str, Any]:
    versions = {
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "torch": torch.__version__,
        "pyarrow": pa.__version__ if pa is not None else "NOT_INSTALLED",
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda,
    }
    mismatches = {}
    for name, target in TARGET_VERSIONS.items():
        observed = str(versions[name]).split("+")[0]
        if observed != target:
            mismatches[name] = {"target": target, "observed": versions[name]}
    versions["target_versions"] = TARGET_VERSIONS
    versions["mismatches"] = mismatches
    if strict and mismatches:
        raise PipelineError("RUNTIME_VERSION_MISMATCH", json.dumps(mismatches, ensure_ascii=False))
    return versions


def discover_files(patterns: Sequence[str]) -> list[Path]:
    found: dict[str, Path] = {}
    for pattern in patterns:
        expanded = Path(os.path.expanduser(pattern))
        if expanded.is_dir():
            matches = [
                str(path) for path in expanded.rglob("*")
                if path.is_file() and path.suffix.lower() in {".csv", ".txt", ".parquet", ".pq"}
            ]
        else:
            matches = glob.glob(str(expanded), recursive=True)
            if not matches and expanded.is_file():
                matches = [str(expanded)]
        for match in matches:
            path = Path(match).expanduser().resolve()
            if path.is_file():
                found[str(path)] = path
    files = [found[key] for key in sorted(found)]
    _require(bool(files), "INPUT_FILE_NOT_FOUND", repr(list(patterns)))
    return files


def validate_single_input_format(files: Sequence[Path]) -> str:
    formats = {_input_format(path) for path in files}
    if len(formats) != 1:
        raise PipelineError(
            "MIXED_INPUT_FORMATS",
            "Do not mix CSV/TXT and Parquet in one scope; select one format to avoid duplicate periods",
        )
    return next(iter(formats))


def validate_mapping_gate(config: PipelineConfig, allow_unconfirmed: bool) -> None:
    confirmed = {"CONFIRMED_FROM_SAMPLE", "CONFIRMED_BY_OWNER"}
    if config.mapping_status not in confirmed and not allow_unconfirmed:
        raise PipelineError(
            "UNCONFIRMED_HEADER_MAPPING",
            f"{config.dataset_id} mapping_status={config.mapping_status}; inspect the real header and pass --allow-unconfirmed-mapping only after review",
        )


def _input_format(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".parquet", ".pq"}:
        return "PARQUET"
    if suffix in {".csv", ".txt"}:
        return "CSV"
    raise PipelineError("INPUT_FORMAT_UNSUPPORTED", f"{path}: expected .csv, .txt, .parquet, or .pq")


def _require_pyarrow() -> None:
    if pa is None or pq is None:
        raise PipelineError(
            "PYARROW_REQUIRED",
            "Parquet input requires pyarrow; install the approved pyarrow==25.0.0 wheel",
        )
    configured = int(os.environ.get("TIMESERIES_ARROW_THREADS", min(os.cpu_count() or 1, 4)))
    pa.set_cpu_count(max(1, min(configured, 4)))


def read_header(path: Path, config: PipelineConfig) -> list[str]:
    try:
        if _input_format(path) == "PARQUET":
            _require_pyarrow()
            return list(pq.ParquetFile(path).schema_arrow.names)
        return list(pd.read_csv(path, sep=config.delimiter, encoding=config.encoding, nrows=0).columns)
    except PipelineError:
        raise
    except Exception as error:
        raise PipelineError("INPUT_HEADER_READ_FAILED", f"{path}: {error}") from error


def validate_headers(files: Sequence[Path], config: PipelineConfig) -> list[dict[str, Any]]:
    expected = config.expected_columns
    output = []
    for path in files:
        observed = read_header(path, config)
        missing = [column for column in expected if column not in observed]
        extras = [column for column in observed if column not in expected]
        if missing or (extras and not config.allow_extra_columns):
            raise PipelineError(
                "CSV_HEADER_MISMATCH",
                json.dumps({
                    "file": str(path),
                    "missing": missing,
                    "unexpected": extras,
                    "expected_names": sorted(expected),
                    "observed_names": sorted(observed),
                    "column_order_required": False,
                }, ensure_ascii=False),
            )
        output.append({
            "path": str(path),
            "size_bytes": path.stat().st_size,
            "input_format": _input_format(path),
            "header": observed,
            "column_order_required": False,
        })
    return output


def _parse_timestamps(raw: pd.Series, config: PipelineConfig) -> pd.Series:
    try:
        if pd.api.types.is_datetime64_any_dtype(raw.dtype) or isinstance(raw.dtype, pd.DatetimeTZDtype):
            parsed = pd.to_datetime(raw, errors="coerce")
        else:
            parsed = pd.to_datetime(
                raw,
                format=config.timestamp_format,
                errors="coerce",
                dayfirst=config.dayfirst,
            )
        if parsed.dt.tz is None:
            parsed = parsed.dt.tz_localize(config.timezone, ambiguous="NaT", nonexistent="NaT")
        else:
            parsed = parsed.dt.tz_convert(config.timezone)
        return parsed
    except Exception as error:
        raise PipelineError("TIMESTAMP_PARSE_FAILED", str(error)) from error


def _read_timestamp_sample(path: Path, config: PipelineConfig, sample_rows: int) -> pd.Series:
    if _input_format(path) == "PARQUET":
        _require_pyarrow()
        batches = pq.ParquetFile(path).iter_batches(
            batch_size=sample_rows,
            columns=[config.timestamp_column],
            use_threads=True,
        )
        first = next(batches, None)
        if first is None:
            return pd.Series([], dtype="string", name=config.timestamp_column)
        return first.to_pandas()[config.timestamp_column]
    return pd.read_csv(
        path,
        sep=config.delimiter,
        encoding=config.encoding,
        usecols=[config.timestamp_column],
        dtype="string",
        nrows=sample_rows,
    )[config.timestamp_column]


def validate_timestamp_samples(
    files: Sequence[Path], config: PipelineConfig, sample_rows: int = 1000
) -> list[dict[str, Any]]:
    results = []
    for path in files:
        raw = _read_timestamp_sample(path, config, sample_rows)
        parsed = _parse_timestamps(raw, config)
        invalid = parsed.isna()
        result = {
            "path": str(path),
            "sample_row_count": int(len(raw)),
            "valid_timestamp_count": int((~invalid).sum()),
            "invalid_timestamp_count": int(invalid.sum()),
            "dayfirst": config.dayfirst,
            "invalid_examples": [str(value) for value in raw.loc[invalid].head(5)],
            "min_event_time": parsed.min().isoformat() if (~invalid).any() else None,
            "max_event_time": parsed.max().isoformat() if (~invalid).any() else None,
        }
        if invalid.any():
            raise PipelineError("TIMESTAMP_SAMPLE_INVALID", json.dumps(result, ensure_ascii=False))
        results.append(result)
    return results


@dataclass
class ParsedChunk:
    frame: pd.DataFrame
    source_rows: int
    invalid_timestamp_count: int
    missing_counts: dict[str, int]
    non_numeric_counts: dict[str, int]
    infinite_counts: dict[str, int]


def _iter_raw_chunks(
    path: Path, config: PipelineConfig, usecols: Sequence[str], chunksize: int
) -> Iterator[pd.DataFrame]:
    if _input_format(path) == "PARQUET":
        _require_pyarrow()
        parquet = pq.ParquetFile(path)
        for batch in parquet.iter_batches(batch_size=chunksize, columns=list(usecols), use_threads=True):
            yield batch.to_pandas()
        return
    with pd.read_csv(
        path,
        sep=config.delimiter,
        encoding=config.encoding,
        usecols=list(usecols),
        dtype="string",
        chunksize=chunksize,
        low_memory=False,
    ) as chunks:
        yield from chunks


def _parse_raw_chunk(raw: pd.DataFrame, config: PipelineConfig) -> ParsedChunk:
    timestamps = _parse_timestamps(raw[config.timestamp_column], config)
    invalid_timestamp_count = int(timestamps.isna().sum())
    frame = pd.DataFrame({"event_time": timestamps})
    missing_counts: dict[str, int] = {}
    non_numeric_counts: dict[str, int] = {}
    infinite_counts: dict[str, int] = {}
    for sensor in config.sensors:
        source = raw[sensor.source_column]
        if pd.api.types.is_numeric_dtype(source.dtype):
            blank = source.isna()
            numeric = pd.to_numeric(source, errors="coerce").astype("float64")
        else:
            text = source.astype("string")
            blank = text.isna() | text.str.strip().eq("")
            numeric = pd.to_numeric(text, errors="coerce").astype("float64")
        values = numeric.to_numpy(dtype=np.float64, na_value=np.nan, copy=True)
        infinite = np.isinf(values)
        values[infinite] = np.nan
        frame[sensor.sensor_uid] = values
        missing_counts[sensor.sensor_uid] = int(blank.sum())
        non_numeric_counts[sensor.sensor_uid] = int((~blank & numeric.isna()).sum())
        infinite_counts[sensor.sensor_uid] = int(infinite.sum())
    return ParsedChunk(
        frame=frame,
        source_rows=len(raw),
        invalid_timestamp_count=invalid_timestamp_count,
        missing_counts=missing_counts,
        non_numeric_counts=non_numeric_counts,
        infinite_counts=infinite_counts,
    )


def iter_parsed_chunks(files: Sequence[Path], config: PipelineConfig, chunksize: int) -> Iterator[ParsedChunk]:
    usecols = config.expected_columns
    for path in files:
        try:
            for raw in _iter_raw_chunks(path, config, usecols, chunksize):
                yield _parse_raw_chunk(raw, config)
        except PipelineError:
            raise
        except Exception as error:
            raise PipelineError("INPUT_CHUNK_READ_FAILED", f"{path}: {error}") from error


def _canonical_duplicate_kind(frame: pd.DataFrame, sensor_uids: Sequence[str]) -> tuple[str, list[str], float | None]:
    vectors = []
    conflict_sensors = []
    max_abs_difference: float | None = None
    for sensor_uid in sensor_uids:
        values = frame[sensor_uid].to_numpy(dtype=np.float64)
        finite = values[np.isfinite(values)]
        unique = np.unique(finite)
        if unique.size > 1:
            conflict_sensors.append(sensor_uid)
            difference = float(unique.max() - unique.min())
            max_abs_difference = difference if max_abs_difference is None else max(max_abs_difference, difference)
    for _, row in frame.iterrows():
        vectors.append(tuple(None if pd.isna(row[uid]) else float(row[uid]) for uid in sensor_uids))
    if all(vector == vectors[0] for vector in vectors[1:]):
        return "IDENTICAL_DUPLICATE", [], 0.0
    if not conflict_sensors:
        return "COMPLEMENTARY_DUPLICATE", [], 0.0
    return "CONFLICTING_DUPLICATE", conflict_sensors, max_abs_difference


def _audit_scalar(value: Any) -> float | None | str:
    if value is None or pd.isna(value) or (isinstance(value, str) and not value.strip()):
        return None
    try:
        numeric = float(value)
        return numeric if math.isfinite(numeric) else str(value)
    except (TypeError, ValueError):
        return str(value)


def audit_duplicate_timestamps(
    files: Sequence[Path],
    config: PipelineConfig,
    output_dir: Path,
    chunksize: int,
    overwrite: bool,
) -> dict[str, Any]:
    output_dir = output_dir.expanduser().resolve()
    if output_dir.exists() and any(output_dir.iterdir()) and not overwrite:
        raise PipelineError("OUTPUT_EXISTS", str(output_dir))
    output_dir.mkdir(parents=True, exist_ok=True)
    groups: dict[int, dict[tuple[str, int], dict[str, Any]]] = {}
    previous: tuple[int, dict[str, Any]] | None = None
    usecols = config.expected_columns

    for path in files:
        source_offset = 0
        for raw in _iter_raw_chunks(path, config, usecols, chunksize):
            parsed = _parse_timestamps(raw[config.timestamp_column], config)
            if parsed.isna().any():
                raise PipelineError("TIMESTAMP_SAMPLE_INVALID", str(path))
            times = _timestamp_ns(parsed)
            differences = np.diff(times)
            if (differences < 0).any() or (previous is not None and times.size and times[0] < previous[0]):
                raise PipelineError("NON_MONOTONIC_TIME", "Audit requires nondecreasing timestamps")
            duplicate_indexes: set[int] = set()
            for index in np.flatnonzero(differences == 0):
                duplicate_indexes.update((int(index), int(index + 1)))
            if previous is not None and times.size and int(times[0]) == previous[0]:
                groups.setdefault(previous[0], {})[(previous[1]["source_file"], previous[1]["source_row"])] = previous[1]
                duplicate_indexes.add(0)

            def make_row(index: int) -> dict[str, Any]:
                source_row = source_offset + index + (2 if _input_format(path) == "CSV" else 1)
                item = {
                    "source_file": str(path),
                    "source_row": source_row,
                    "event_time": parsed.iloc[index].isoformat(),
                }
                for sensor in config.sensors:
                    item[sensor.sensor_uid] = _audit_scalar(raw.iloc[index][sensor.source_column])
                return item

            for index in duplicate_indexes:
                item = make_row(index)
                groups.setdefault(int(times[index]), {})[(item["source_file"], item["source_row"])] = item
            if times.size:
                previous = (int(times[-1]), make_row(len(raw) - 1))
            source_offset += len(raw)

    group_rows = []
    detail_rows = []
    canonical_groups = []
    sensor_uids = [sensor.sensor_uid for sensor in config.sensors]
    type_counts: dict[str, int] = {
        "IDENTICAL_DUPLICATE": 0,
        "COMPLEMENTARY_DUPLICATE": 0,
        "CONFLICTING_DUPLICATE": 0,
    }
    for group_number, (timestamp_ns, source_rows) in enumerate(sorted(groups.items()), start=1):
        rows = list(source_rows.values())
        frame = pd.DataFrame([{uid: row[uid] for uid in sensor_uids} for row in rows])
        frame = frame.apply(pd.to_numeric, errors="coerce").astype("float64")
        kind, conflict_sensors, max_difference = _canonical_duplicate_kind(frame, sensor_uids)
        type_counts[kind] += 1
        duplicate_uid = f"DUP-{config.dataset_id}-{group_number:06d}"
        group_rows.append({
            "duplicate_uid": duplicate_uid,
            "event_time": rows[0]["event_time"],
            "duplicate_type": kind,
            "row_count": len(rows),
            "conflicting_sensor_count": len(conflict_sensors),
            "conflicting_sensor_uids": "|".join(conflict_sensors),
            "max_abs_difference": max_difference,
            "source_refs": "|".join(f"{row['source_file']}:{row['source_row']}" for row in rows),
            "recommended_action": {
                "IDENTICAL_DUPLICATE": "KEEP_ONE",
                "COMPLEMENTARY_DUPLICATE": "COALESCE_NON_NULL",
                "CONFLICTING_DUPLICATE": "FIELD_REVIEW_REQUIRED",
            }[kind],
        })
        for row in rows:
            detail_rows.append({"duplicate_uid": duplicate_uid, **row})
        canonical_groups.append({
            "duplicate_uid": duplicate_uid,
            "event_time": rows[0]["event_time"],
            "duplicate_type": kind,
            "conflicting_sensor_uids": conflict_sensors,
            "max_abs_difference": max_difference,
            "rows": rows,
        })

    input_files = [_file_metadata(path, False) for path in files]
    audit_payload = {
        "contract_version": CONTRACT_VERSION,
        "dataset_id": config.dataset_id,
        "config_sha256": config.config_sha256,
        "input_files": input_files,
        "groups": canonical_groups,
    }
    audit_sha256 = hashlib.sha256(
        json.dumps(audit_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    manifest = {
        **audit_payload,
        "created_at": datetime.now(UTC).isoformat(),
        "audit_sha256": audit_sha256,
        "duplicate_timestamp_count": len(canonical_groups),
        "duplicate_row_count": sum(len(item["rows"]) for item in canonical_groups),
        "type_counts": type_counts,
        "field_review_required": type_counts["CONFLICTING_DUPLICATE"] > 0,
        "groups_file": "duplicate_groups.csv",
        "rows_file": "duplicate_rows.csv",
    }
    _atomic_csv(output_dir / "duplicate_groups.csv", group_rows)
    _atomic_csv(output_dir / "duplicate_rows.csv", detail_rows)
    _atomic_json(output_dir / "duplicate_audit_manifest.json", manifest)
    return manifest


def _validate_duplicate_authorization(
    files: Sequence[Path],
    config: PipelineConfig,
    policy: str,
    manifest_path: Path | None,
    expected_audit_sha256: str | None,
    reviewed: bool,
    mean_approved: bool,
    mean_approval_ref: str | None,
) -> dict[str, Any] | None:
    if policy not in {"exclude-conflicts", "mean-conflicts"}:
        return None
    if manifest_path is None or not expected_audit_sha256 or not reviewed:
        raise PipelineError(
            "DUPLICATE_AUDIT_APPROVAL_REQUIRED",
            "Provide --duplicate-audit-manifest, --duplicate-audit-sha256, and --confirm-conflicting-action-reviewed",
        )
    manifest = json.loads(manifest_path.expanduser().resolve().read_text(encoding="utf-8"))
    if manifest.get("audit_sha256") != expected_audit_sha256:
        raise PipelineError("DUPLICATE_AUDIT_SHA_MISMATCH", "Audit receipt does not match")
    if manifest.get("config_sha256") != config.config_sha256:
        raise PipelineError("DUPLICATE_AUDIT_CONFIG_MISMATCH", config.dataset_id)
    current_files = [_file_metadata(path, False) for path in files]
    if manifest.get("input_files") != current_files:
        raise PipelineError("DUPLICATE_AUDIT_INPUT_CHANGED", "Input files changed after duplicate review")
    if policy == "mean-conflicts" and (not mean_approved or not mean_approval_ref or not mean_approval_ref.strip()):
        raise PipelineError(
            "DUPLICATE_MEAN_APPROVAL_REQUIRED",
            "Mean requires --confirm-conflicting-mean-approved and --conflicting-mean-approval-ref",
        )
    return manifest


def _resolve_duplicate_frame(
    frame: pd.DataFrame,
    config: PipelineConfig,
    policy: str,
    stats: dict[str, int],
) -> pd.DataFrame:
    duplicate_mask = frame["event_time"].duplicated(keep=False)
    if not duplicate_mask.any():
        return frame
    if policy == "error":
        raise PipelineError("DUPLICATE_TIMESTAMP", "Run duplicate audit before feature extraction")
    sensor_uids = [sensor.sensor_uid for sensor in config.sensors]
    resolved_rows = []
    for _, group in frame.loc[duplicate_mask].groupby("event_time", sort=False):
        kind, _, _ = _canonical_duplicate_kind(group, sensor_uids)
        stats["duplicate_groups"] += 1
        stats[kind] += 1
        if kind == "CONFLICTING_DUPLICATE":
            if policy == "safe":
                raise PipelineError(
                    "CONFLICTING_DUPLICATE_REVIEW_REQUIRED",
                    "Inspect duplicate_rows.csv before selecting exclude or approved mean",
                )
            if policy == "exclude-conflicts":
                stats["conflicting_groups_excluded"] += 1
                stats["rows_removed"] += len(group)
                continue
            if policy != "mean-conflicts":
                raise PipelineError("DUPLICATE_POLICY_INVALID", policy)
            row = group.iloc[0].copy()
            row.loc[sensor_uids] = group.loc[:, sensor_uids].mean(axis=0, skipna=True)
            stats["conflicting_groups_mean"] += 1
            stats["rows_removed"] += len(group) - 1
            resolved_rows.append(row)
            continue
        row = group.iloc[0].copy()
        if kind == "COMPLEMENTARY_DUPLICATE":
            for sensor_uid in sensor_uids:
                finite = group[sensor_uid].dropna()
                row[sensor_uid] = finite.iloc[0] if not finite.empty else np.nan
            stats["complementary_groups_coalesced"] += 1
        else:
            stats["identical_groups_deduplicated"] += 1
        stats["rows_removed"] += len(group) - 1
        resolved_rows.append(row)
    unique = frame.loc[~duplicate_mask]
    if resolved_rows:
        resolved = pd.DataFrame(resolved_rows, columns=frame.columns)
        unique = pd.concat([unique, resolved], ignore_index=True)
    return unique.sort_values("event_time", kind="mergesort").reset_index(drop=True)


def _iter_feature_frames(
    files: Sequence[Path],
    config: PipelineConfig,
    chunksize: int,
    duplicate_policy: str,
    stats: dict[str, int],
) -> Iterator[pd.DataFrame]:
    pending = pd.DataFrame()
    previous_time: int | None = None
    for parsed in iter_parsed_chunks(files, config, chunksize):
        frame = parsed.frame.loc[parsed.frame["event_time"].notna()].copy()
        if frame.empty:
            continue
        if not pending.empty:
            frame = pd.concat([pending, frame], ignore_index=True)
        times = _timestamp_ns(frame["event_time"])
        if np.any(np.diff(times) < 0) or (previous_time is not None and int(times[0]) < previous_time):
            raise PipelineError("NON_MONOTONIC_TIME", "feature extraction requires nondecreasing timestamps")
        last_time = frame["event_time"].iloc[-1]
        complete = frame.loc[frame["event_time"] < last_time]
        pending = frame.loc[frame["event_time"] == last_time].copy()
        if not complete.empty:
            resolved = _resolve_duplicate_frame(complete, config, duplicate_policy, stats)
            if not resolved.empty:
                previous_time = int(_timestamp_ns(resolved["event_time"])[-1])
                yield resolved
    if not pending.empty:
        resolved = _resolve_duplicate_frame(pending, config, duplicate_policy, stats)
        if not resolved.empty:
            yield resolved


class PriorityReservoir:
    """Mergeable uniform sample using random priorities; no per-value Python loop."""

    def __init__(self, capacity: int, seed: int) -> None:
        self.capacity = capacity
        self.rng = np.random.default_rng(seed)
        self.values = np.empty(0, dtype=np.float64)
        self.priorities = np.empty(0, dtype=np.float64)

    def update(self, values: np.ndarray) -> None:
        values = values[np.isfinite(values)]
        if values.size == 0 or self.capacity <= 0:
            return
        priorities = self.rng.random(values.size)
        all_values = np.concatenate((self.values, values))
        all_priorities = np.concatenate((self.priorities, priorities))
        if all_values.size > self.capacity:
            indexes = np.argpartition(all_priorities, self.capacity - 1)[: self.capacity]
            all_values = all_values[indexes]
            all_priorities = all_priorities[indexes]
        self.values = all_values
        self.priorities = all_priorities


class RunningStats:
    def __init__(self, sample_capacity: int, seed: int) -> None:
        self.total_rows = 0
        self.valid_count = 0
        self.missing_count = 0
        self.non_numeric_count = 0
        self.infinite_count = 0
        self.value_sum = 0.0
        self.value_sum_sq = 0.0
        self.minimum = math.inf
        self.maximum = -math.inf
        self.reservoir = PriorityReservoir(sample_capacity, seed)

    def update(self, values: np.ndarray, missing: int, non_numeric: int, infinite: int) -> None:
        finite = values[np.isfinite(values)]
        self.total_rows += values.size
        self.valid_count += finite.size
        self.missing_count += missing
        self.non_numeric_count += non_numeric
        self.infinite_count += infinite
        if finite.size:
            self.value_sum += float(finite.sum(dtype=np.float64))
            self.value_sum_sq += float(np.square(finite, dtype=np.float64).sum(dtype=np.float64))
            self.minimum = min(self.minimum, float(finite.min()))
            self.maximum = max(self.maximum, float(finite.max()))
            self.reservoir.update(finite)

    def result(self) -> dict[str, Any]:
        mean = self.value_sum / self.valid_count if self.valid_count else None
        variance = None
        if self.valid_count > 1 and mean is not None:
            variance = max((self.value_sum_sq - self.valid_count * mean * mean) / (self.valid_count - 1), 0.0)
        sample = self.reservoir.values
        quantiles = {}
        if sample.size:
            for probability in (0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99):
                quantiles[f"p{int(probability * 100):02d}"] = float(np.quantile(sample, probability))
        return {
            "total_rows": self.total_rows,
            "valid_count": self.valid_count,
            "missing_count": self.missing_count,
            "non_numeric_count": self.non_numeric_count,
            "infinite_count": self.infinite_count,
            "valid_ratio": self.valid_count / self.total_rows if self.total_rows else None,
            "mean": mean,
            "std": math.sqrt(variance) if variance is not None else None,
            "min": self.minimum if self.valid_count else None,
            "max": self.maximum if self.valid_count else None,
            "approximate_quantiles": quantiles,
            "quantile_sample_count": int(sample.size),
            "quantile_method": "UNIFORM_RANDOM_PRIORITY_RESERVOIR",
        }


class DailyStats:
    def __init__(self) -> None:
        self.values: dict[tuple[str, str], dict[str, float | int]] = {}

    def update(self, day_values: np.ndarray, sensor_uid: str, values: np.ndarray) -> None:
        valid = np.isfinite(values)
        if not valid.any():
            unique_days, counts = np.unique(day_values, return_counts=True)
            for day, count in zip(unique_days, counts, strict=True):
                item = self.values.setdefault((str(day), sensor_uid), self._empty())
                item["source_rows"] += int(count)
            return
        for day in np.unique(day_values):
            day_mask = day_values == day
            finite = values[day_mask & valid]
            item = self.values.setdefault((str(day), sensor_uid), self._empty())
            item["source_rows"] += int(day_mask.sum())
            item["valid_count"] += int(finite.size)
            if finite.size:
                item["sum"] += float(finite.sum(dtype=np.float64))
                item["sum_sq"] += float(np.square(finite, dtype=np.float64).sum(dtype=np.float64))
                item["min"] = min(float(item["min"]), float(finite.min()))
                item["max"] = max(float(item["max"]), float(finite.max()))

    @staticmethod
    def _empty() -> dict[str, float | int]:
        return {"source_rows": 0, "valid_count": 0, "sum": 0.0, "sum_sq": 0.0, "min": math.inf, "max": -math.inf}

    def rows(self) -> list[dict[str, Any]]:
        output = []
        for (day, sensor_uid), item in sorted(self.values.items()):
            count = int(item["valid_count"])
            mean = float(item["sum"]) / count if count else None
            variance = None
            if count > 1 and mean is not None:
                variance = max((float(item["sum_sq"]) - count * mean * mean) / (count - 1), 0.0)
            output.append({
                "day": day,
                "sensor_uid": sensor_uid,
                "source_rows": int(item["source_rows"]),
                "valid_count": count,
                "missing_or_invalid_count": int(item["source_rows"]) - count,
                "mean": mean,
                "std": math.sqrt(variance) if variance is not None else None,
                "min": float(item["min"]) if count else None,
                "max": float(item["max"]) if count else None,
            })
        return output


def _timestamp_ns(series: pd.Series) -> np.ndarray:
    """Return epoch nanoseconds regardless of pandas' inferred datetime resolution."""
    return np.asarray(series.array.as_unit("ns").asi8, dtype=np.int64).copy()


def run_eda(
    files: Sequence[Path],
    config: PipelineConfig,
    output_dir: Path,
    chunksize: int,
    reservoir_size: int,
    overwrite: bool,
    hash_inputs: bool,
) -> dict[str, Any]:
    output_dir = output_dir.expanduser().resolve()
    if output_dir.exists() and any(output_dir.iterdir()) and not overwrite:
        raise PipelineError("OUTPUT_EXISTS", str(output_dir))
    output_dir.mkdir(parents=True, exist_ok=True)
    stats = {
        sensor.sensor_uid: RunningStats(reservoir_size, 417 + index)
        for index, sensor in enumerate(config.sensors)
    }
    daily = DailyStats()
    source_rows = 0
    valid_timestamp_rows = 0
    invalid_timestamp_rows = 0
    duplicate_timestamps = 0
    reversed_timestamps = 0
    gap_count = 0
    estimated_missing_timestamps = 0
    min_time: int | None = None
    max_time: int | None = None
    last_time: int | None = None
    expected_ns = int(config.expected_interval_seconds * 1_000_000_000)

    for parsed in iter_parsed_chunks(files, config, chunksize):
        source_rows += parsed.source_rows
        invalid_timestamp_rows += parsed.invalid_timestamp_count
        valid_frame = parsed.frame.loc[parsed.frame["event_time"].notna()]
        valid_timestamp_rows += len(valid_frame)
        if not valid_frame.empty:
            times = _timestamp_ns(valid_frame["event_time"])
            if last_time is not None:
                times_for_diff = np.concatenate((np.array([last_time], dtype=np.int64), times))
            else:
                times_for_diff = times
            differences = np.diff(times_for_diff)
            duplicate_timestamps += int((differences == 0).sum())
            reversed_timestamps += int((differences < 0).sum())
            positive_gaps = differences[differences > int(expected_ns * 1.5)]
            gap_count += int(positive_gaps.size)
            if positive_gaps.size:
                estimated_missing_timestamps += int(np.maximum(np.rint(positive_gaps / expected_ns).astype(np.int64) - 1, 0).sum())
            last_time = int(times[-1])
            min_time = int(times.min()) if min_time is None else min(min_time, int(times.min()))
            max_time = int(times.max()) if max_time is None else max(max_time, int(times.max()))
            day_values = valid_frame["event_time"].dt.strftime("%Y-%m-%d").to_numpy()
        else:
            day_values = np.empty(0, dtype=str)
        for sensor in config.sensors:
            values = parsed.frame[sensor.sensor_uid].to_numpy(dtype=np.float64)
            stats[sensor.sensor_uid].update(
                values,
                parsed.missing_counts[sensor.sensor_uid],
                parsed.non_numeric_counts[sensor.sensor_uid],
                parsed.infinite_counts[sensor.sensor_uid],
            )
            if not valid_frame.empty:
                daily.update(day_values, sensor.sensor_uid, valid_frame[sensor.sensor_uid].to_numpy(dtype=np.float64))

    profile = {
        "contract_version": CONTRACT_VERSION,
        "created_at": datetime.now(UTC).isoformat(),
        "dataset_id": config.dataset_id,
        "config_path": str(config.path),
        "config_sha256": config.config_sha256,
        "asset_mapping_status": config.asset_mapping_status,
        "runtime": runtime_versions(False),
        "input_files": [_file_metadata(path, hash_inputs) for path in files],
        "timestamp_quality": {
            "source_rows": source_rows,
            "valid_timestamp_rows": valid_timestamp_rows,
            "invalid_timestamp_rows": invalid_timestamp_rows,
            "duplicate_timestamp_count": duplicate_timestamps,
            "reversed_timestamp_count": reversed_timestamps,
            "sampling_gap_count": gap_count,
            "estimated_missing_timestamp_count": estimated_missing_timestamps,
            "expected_interval_seconds": config.expected_interval_seconds,
            "timezone": config.timezone,
            "timezone_status": config.timezone_status,
            "time_semantics": config.time_semantics,
            "min_event_time": _ns_to_iso(min_time, config.timezone),
            "max_event_time": _ns_to_iso(max_time, config.timezone),
        },
        "sensors": {
            sensor.sensor_uid: {
                "source_column": sensor.source_column,
                "asset_id": sensor.asset_id,
                "measurement_type": sensor.measurement_type,
                "unit": sensor.unit,
                "unit_status": sensor.unit_status,
                **stats[sensor.sensor_uid].result(),
            }
            for sensor in config.sensors
        },
        "safety": {
            "thresholds_inferred": False,
            "unlabelled_assumed_normal": False,
            "correlation_interpreted_as_causality": False,
        },
    }
    _atomic_json(output_dir / "eda_profile.json", profile)
    _atomic_csv(output_dir / "eda_daily.csv", daily.rows())
    return profile


def _ns_to_iso(value: int | None, timezone: str) -> str | None:
    if value is None:
        return None
    return pd.Timestamp(value, tz="UTC").tz_convert(timezone).isoformat()


def _file_metadata(path: Path, include_hash: bool) -> dict[str, Any]:
    stat = path.stat()
    result = {
        "path": str(path),
        "input_format": _input_format(path),
        "size_bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
    }
    if include_hash:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
                digest.update(block)
        result["sha256"] = digest.hexdigest()
    return result


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def _atomic_csv(path: Path, rows: Sequence[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    if not rows:
        temporary.write_text("", encoding="utf-8")
    else:
        with temporary.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    temporary.replace(path)


class StreamingCsvWriter:
    def __init__(self, destination: Path, overwrite: bool) -> None:
        self.destination = destination.expanduser().resolve()
        if self.destination.exists() and not overwrite:
            raise PipelineError("OUTPUT_EXISTS", str(self.destination))
        self.destination.parent.mkdir(parents=True, exist_ok=True)
        self.temporary = self.destination.with_name(f".{self.destination.name}.tmp")
        self.handle = self.temporary.open("w", encoding="utf-8", newline="")
        self.writer: csv.DictWriter[str] | None = None
        self.row_count = 0

    def write(self, rows: Iterable[dict[str, Any]]) -> None:
        for row in rows:
            if self.writer is None:
                self.writer = csv.DictWriter(self.handle, fieldnames=list(row))
                self.writer.writeheader()
            self.writer.writerow(row)
            self.row_count += 1

    def commit(self) -> None:
        self.handle.flush()
        os.fsync(self.handle.fileno())
        self.handle.close()
        self.temporary.replace(self.destination)

    def abort(self) -> None:
        if not self.handle.closed:
            self.handle.close()
        self.temporary.unlink(missing_ok=True)


@dataclass(frozen=True)
class ReferenceEvent:
    event_uid: str
    start_ns: int
    end_ns: int
    asset_id: str | None
    sensor_uid: str | None
    label: str
    source_ref: str


def load_reference_events(path: Path | None, timezone: str) -> list[ReferenceEvent]:
    if path is None:
        return []
    frame = pd.read_csv(path, dtype="string")
    required = {"event_uid", "start_time", "end_time", "label", "source_ref"}
    missing = required - set(frame.columns)
    _require(not missing, "REFERENCE_EVENT_COLUMNS_MISSING", repr(sorted(missing)))
    starts = pd.to_datetime(frame["start_time"], errors="coerce")
    ends = pd.to_datetime(frame["end_time"], errors="coerce")
    if starts.dt.tz is None:
        starts = starts.dt.tz_localize(timezone, ambiguous="NaT", nonexistent="NaT")
        ends = ends.dt.tz_localize(timezone, ambiguous="NaT", nonexistent="NaT")
    _require(not starts.isna().any() and not ends.isna().any(), "REFERENCE_EVENT_TIME_INVALID", str(path))
    events = []
    for index, row in frame.iterrows():
        start_ns = int(starts.iloc[index].value)
        end_ns = int(ends.iloc[index].value)
        _require(end_ns > start_ns, "REFERENCE_EVENT_RANGE_INVALID", str(row["event_uid"]))
        events.append(ReferenceEvent(
            event_uid=str(row["event_uid"]),
            start_ns=start_ns,
            end_ns=end_ns,
            asset_id=None if pd.isna(row.get("asset_id")) else str(row.get("asset_id")),
            sensor_uid=None if pd.isna(row.get("sensor_uid")) else str(row.get("sensor_uid")),
            label=str(row["label"]),
            source_ref=str(row["source_ref"]),
        ))
    return events


def event_overlap(
    events: Sequence[ReferenceEvent], start_ns: int, end_ns: int, asset_id: str, sensor_uid: str | None
) -> tuple[bool, str, str]:
    matched = [
        event for event in events
        if event.start_ns < end_ns
        and event.end_ns > start_ns
        and (event.asset_id is None or event.asset_id == asset_id)
        and (event.sensor_uid is None or sensor_uid is None or event.sensor_uid == sensor_uid)
    ]
    return (
        bool(matched),
        "|".join(event.event_uid for event in matched),
        "|".join(sorted({event.label for event in matched})),
    )


def resolve_device(requested: str) -> torch.device:
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    device = torch.device(requested)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise PipelineError("CUDA_NOT_AVAILABLE", requested)
    return device


def _empty_spectral(status: str, interpolated_count: int = 0) -> dict[str, Any]:
    return {
        "spectral_status": status,
        "spectral_interpolated_sample_count": interpolated_count,
        "spectral_centroid_hz": None,
        "spectral_bandwidth_hz": None,
        "spectral_entropy": None,
        "dominant_frequency_hz": None,
        "dominant_power_ratio": None,
        "relative_power_0_10pct_nyquist": None,
        "relative_power_10_30pct_nyquist": None,
        "relative_power_30_100pct_nyquist": None,
    }


def _spectral_features_batch(
    grids: dict[str, np.ndarray],
    maximum_missing_ratio: float,
    sampling_hz: float,
    device: torch.device,
) -> dict[str, dict[str, Any]]:
    """Run one batched FFT per window instead of one GPU launch per sensor."""
    results: dict[str, dict[str, Any]] = {}
    eligible_names: list[str] = []
    eligible_values: list[np.ndarray] = []
    interpolated_counts: list[int] = []
    for sensor_uid, grid in grids.items():
        values, missing_count = _interpolate_for_spectrum(grid, maximum_missing_ratio)
        if not np.isfinite(grid).any():
            results[sensor_uid] = _empty_spectral("SKIPPED_NO_VALID_DATA", missing_count)
        elif values is None:
            results[sensor_uid] = _empty_spectral("SKIPPED_COVERAGE", missing_count)
        elif float(np.max(np.abs(values - values.mean()))) == 0.0:
            results[sensor_uid] = _empty_spectral("SKIPPED_CONSTANT", missing_count)
        else:
            eligible_names.append(sensor_uid)
            eligible_values.append(values)
            interpolated_counts.append(missing_count)
    if not eligible_names:
        return results

    tensor = torch.as_tensor(np.stack(eligible_values), dtype=torch.float64, device=device)
    centered = tensor - tensor.mean(dim=1, keepdim=True)
    window = torch.hann_window(tensor.shape[1], periodic=True, dtype=torch.float64, device=device)
    power = torch.fft.rfft(centered * window, dim=1).abs().square()[:, 1:]
    frequencies = torch.fft.rfftfreq(tensor.shape[1], d=1.0 / sampling_hz, device=device)[1:]
    total = power.sum(dim=1)
    probabilities = power / total[:, None].clamp_min(torch.finfo(torch.float64).tiny)
    centroid = (probabilities * frequencies[None, :]).sum(dim=1)
    bandwidth = torch.sqrt((probabilities * (frequencies[None, :] - centroid[:, None]).square()).sum(dim=1))
    entropy = -(probabilities * torch.log(probabilities.clamp_min(torch.finfo(torch.float64).tiny))).sum(dim=1)
    if probabilities.shape[1] > 1:
        entropy = entropy / math.log(probabilities.shape[1])
    dominant_indexes = torch.argmax(power, dim=1)
    nyquist = sampling_hz / 2.0

    def relative_band(low: float, high: float) -> torch.Tensor:
        mask = (frequencies >= low * nyquist) & (frequencies < high * nyquist)
        if not bool(mask.any().item()):
            return torch.zeros(tensor.shape[0], dtype=torch.float64, device=device)
        return power[:, mask].sum(dim=1) / total.clamp_min(torch.finfo(torch.float64).tiny)

    low_power = relative_band(0.0, 0.1)
    middle_power = relative_band(0.1, 0.3)
    high_power = relative_band(0.3, 1.01)
    for index, sensor_uid in enumerate(eligible_names):
        dominant_index = int(dominant_indexes[index].item())
        if float(total[index].item()) <= 0:
            results[sensor_uid] = _empty_spectral("SKIPPED_ZERO_POWER", interpolated_counts[index])
            continue
        results[sensor_uid] = {
            "spectral_status": "PASS",
            "spectral_interpolated_sample_count": interpolated_counts[index],
            "spectral_centroid_hz": float(centroid[index].item()),
            "spectral_bandwidth_hz": float(bandwidth[index].item()),
            "spectral_entropy": float(entropy[index].item()),
            "dominant_frequency_hz": float(frequencies[dominant_index].item()),
            "dominant_power_ratio": float(probabilities[index, dominant_index].item()),
            "relative_power_0_10pct_nyquist": float(low_power[index].item()),
            "relative_power_10_30pct_nyquist": float(middle_power[index].item()),
            "relative_power_30_100pct_nyquist": float(high_power[index].item()),
        }
    return results


def _regular_grid(
    window_times_ns: np.ndarray,
    values: np.ndarray,
    start_ns: int,
    expected_samples: int,
    interval_ns: int,
) -> np.ndarray:
    grid = np.full(expected_samples, np.nan, dtype=np.float64)
    offsets = np.rint((window_times_ns - start_ns) / interval_ns).astype(np.int64)
    valid = (offsets >= 0) & (offsets < expected_samples) & np.isfinite(values)
    grid[offsets[valid]] = values[valid]
    return grid


def _interpolate_for_spectrum(grid: np.ndarray, maximum_missing_ratio: float) -> tuple[np.ndarray | None, int]:
    valid = np.isfinite(grid)
    missing = int((~valid).sum())
    if valid.sum() < 4 or missing / grid.size > maximum_missing_ratio:
        return None, missing
    if missing == 0:
        return grid, 0
    indexes = np.arange(grid.size)
    return np.interp(indexes, indexes[valid], grid[valid]), missing


def _longest_true_run(mask: np.ndarray) -> int:
    if mask.size == 0 or not mask.any():
        return 0
    padded = np.concatenate((np.array([False]), mask, np.array([False])))
    changes = np.flatnonzero(padded[1:] != padded[:-1])
    return int(np.max(changes[1::2] - changes[::2]))


def _grid_correlation(left: np.ndarray, right: np.ndarray) -> tuple[float | None, int]:
    mask = np.isfinite(left) & np.isfinite(right)
    pair_count = int(mask.sum())
    if pair_count < 3:
        return None, pair_count
    x = left[mask]
    y = right[mask]
    if float(x.std()) == 0.0 or float(y.std()) == 0.0:
        return None, pair_count
    return float(np.corrcoef(x, y)[0, 1]), pair_count


def _window_sensor_features(
    sensor: SensorSpec,
    times_ns: np.ndarray,
    values: np.ndarray,
    grid: np.ndarray,
    start_ns: int,
    end_ns: int,
    config: PipelineConfig,
    spectral_features: dict[str, Any],
    events: Sequence[ReferenceEvent],
) -> dict[str, Any]:
    valid = np.isfinite(values)
    finite = values[valid]
    expected_samples = grid.size
    valid_count = int(finite.size)
    coverage = min(valid_count / expected_samples, 1.0)
    overlap, event_uids, event_labels = event_overlap(events, start_ns, end_ns, sensor.asset_id, sensor.sensor_uid)
    row: dict[str, Any] = {
        "dataset_id": config.dataset_id,
        "window_start": _ns_to_iso(start_ns, config.timezone),
        "window_end": _ns_to_iso(end_ns, config.timezone),
        "window_seconds": config.window_seconds,
        "stride_seconds": config.stride_seconds,
        "sensor_uid": sensor.sensor_uid,
        "asset_id": sensor.asset_id,
        "measurement_type": sensor.measurement_type,
        "unit": sensor.unit,
        "unit_status": sensor.unit_status,
        "expected_sample_count": expected_samples,
        "valid_sample_count": valid_count,
        "missing_sample_count": max(expected_samples - valid_count, 0),
        "longest_missing_run_seconds": _longest_true_run(~np.isfinite(grid)) * config.expected_interval_seconds,
        "coverage_ratio": coverage,
        "quality_status": "PASS" if coverage >= config.min_coverage_ratio else "INSUFFICIENT_COVERAGE",
        "reference_event_overlap": overlap,
        "reference_event_uids": event_uids,
        "reference_event_labels": event_labels,
        "reference_label_status": "REFERENCE_ONLY" if overlap else "UNLABELLED_NOT_ASSUMED_NORMAL",
    }
    for lag_seconds in config.correlation_lags_seconds:
        lag_steps = int(round(lag_seconds / config.expected_interval_seconds))
        if lag_steps <= 0:
            correlation, pair_count = 1.0 if valid_count >= 1 else None, valid_count
        elif lag_steps >= grid.size:
            correlation, pair_count = None, 0
        else:
            correlation, pair_count = _grid_correlation(grid[:-lag_steps], grid[lag_steps:])
        row[f"autocorrelation_lag_{lag_seconds}s"] = correlation
        row[f"autocorrelation_pair_count_lag_{lag_seconds}s"] = pair_count
    row.update(spectral_features)
    empty_features = {
        "mean": None, "std": None, "min": None, "max": None, "median": None,
        "p01": None, "p05": None, "p25": None, "p75": None, "p95": None, "p99": None,
        "range": None, "iqr": None, "rms": None, "mean_square_energy": None,
        "mad": None, "skewness": None, "excess_kurtosis": None, "slope_per_second": None,
        "first_last_delta": None, "mean_abs_change": None, "max_abs_change": None,
        "mean_abs_rate_per_second": None, "max_abs_rate_per_second": None,
        "flatline_step_ratio": None, "centered_zero_crossing_ratio": None, "robust_outlier_ratio": None,
    }
    if valid_count == 0:
        row.update(empty_features)
        return row

    quantiles = np.quantile(finite, [0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99])
    mean = float(finite.mean())
    centered = finite - mean
    std_population = float(finite.std(ddof=0))
    std_sample = float(finite.std(ddof=1)) if valid_count > 1 else 0.0
    median = float(quantiles[3])
    mad = float(np.median(np.abs(finite - median)))
    skewness = float(np.mean(centered**3) / std_population**3) if std_population > 0 else 0.0
    kurtosis = float(np.mean(centered**4) / std_population**4 - 3.0) if std_population > 0 else 0.0
    valid_times_seconds = (times_ns[valid] - start_ns) / 1_000_000_000
    time_centered = valid_times_seconds - valid_times_seconds.mean()
    denominator = float(np.square(time_centered).sum())
    slope = float((time_centered * centered).sum() / denominator) if denominator > 0 else None
    differences = np.diff(finite)
    time_differences = np.diff(valid_times_seconds)
    positive_time = time_differences > 0
    rates = np.abs(differences[positive_time] / time_differences[positive_time]) if positive_time.any() else np.empty(0)
    robust_scale = 1.4826 * mad
    robust_outlier_ratio = float((np.abs(finite - median) / robust_scale > config.robust_z_threshold).mean()) if robust_scale > 0 else 0.0
    row.update({
        "mean": mean,
        "std": std_sample,
        "min": float(finite.min()),
        "max": float(finite.max()),
        "median": median,
        "p01": float(quantiles[0]),
        "p05": float(quantiles[1]),
        "p25": float(quantiles[2]),
        "p75": float(quantiles[4]),
        "p95": float(quantiles[5]),
        "p99": float(quantiles[6]),
        "range": float(finite.max() - finite.min()),
        "iqr": float(quantiles[4] - quantiles[2]),
        "rms": float(np.sqrt(np.mean(np.square(finite)))),
        "mean_square_energy": float(np.mean(np.square(finite))),
        "mad": mad,
        "skewness": skewness,
        "excess_kurtosis": kurtosis,
        "slope_per_second": slope,
        "first_last_delta": float(finite[-1] - finite[0]),
        "mean_abs_change": float(np.mean(np.abs(differences))) if differences.size else None,
        "max_abs_change": float(np.max(np.abs(differences))) if differences.size else None,
        "mean_abs_rate_per_second": float(rates.mean()) if rates.size else None,
        "max_abs_rate_per_second": float(rates.max()) if rates.size else None,
        "flatline_step_ratio": float((np.abs(differences) <= config.flatline_epsilon).mean()) if differences.size else None,
        "centered_zero_crossing_ratio": float((centered[:-1] * centered[1:] < 0).mean()) if valid_count > 1 else None,
        "robust_outlier_ratio": robust_outlier_ratio,
    })
    return row


def _window_correlations(
    grids: dict[str, np.ndarray],
    start_ns: int,
    end_ns: int,
    config: PipelineConfig,
    events: Sequence[ReferenceEvent],
) -> list[dict[str, Any]]:
    by_asset: dict[str, list[SensorSpec]] = {}
    for sensor in config.sensors:
        by_asset.setdefault(sensor.asset_id, []).append(sensor)
    rows = []
    interval = config.expected_interval_seconds
    for asset_id, sensors in by_asset.items():
        for left_index, left in enumerate(sensors):
            for right in sensors[left_index + 1:]:
                best: tuple[float, int, int] | None = None
                lag_values: dict[str, Any] = {}
                for lag_seconds in config.correlation_lags_seconds:
                    lag_steps = int(round(lag_seconds / interval))
                    left_values = grids[left.sensor_uid]
                    right_values = grids[right.sensor_uid]
                    if lag_steps > 0:
                        left_values = left_values[:-lag_steps]
                        right_values = right_values[lag_steps:]
                    correlation, pair_count = _grid_correlation(left_values, right_values)
                    if correlation is not None and (best is None or abs(correlation) > abs(best[0])):
                        best = (correlation, lag_seconds, pair_count)
                    lag_values[f"corr_lag_{lag_seconds}s"] = correlation
                    lag_values[f"pair_count_lag_{lag_seconds}s"] = pair_count
                overlap, event_uids, event_labels = event_overlap(events, start_ns, end_ns, asset_id, None)
                rows.append({
                    "dataset_id": config.dataset_id,
                    "window_start": _ns_to_iso(start_ns, config.timezone),
                    "window_end": _ns_to_iso(end_ns, config.timezone),
                    "asset_id": asset_id,
                    "left_sensor_uid": left.sensor_uid,
                    "right_sensor_uid": right.sensor_uid,
                    "max_abs_correlation": abs(best[0]) if best else None,
                    "signed_correlation_at_max": best[0] if best else None,
                    "lag_seconds_at_max": best[1] if best else None,
                    "pair_count_at_max": best[2] if best else 0,
                    "interpretation": "ASSOCIATION_ONLY_NOT_CAUSAL",
                    "reference_event_overlap": overlap,
                    "reference_event_uids": event_uids,
                    "reference_event_labels": event_labels,
                    **lag_values,
                })
    return rows


def _compute_feature_window(
    config: PipelineConfig,
    events: Sequence[ReferenceEvent],
    device: torch.device,
    include_correlations: bool,
    start_ns: int,
    end_ns: int,
    window_times: np.ndarray,
    value_matrix: np.ndarray,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    expected_samples = int(config.window_seconds / config.expected_interval_seconds)
    interval_ns = int(config.expected_interval_seconds * 1_000_000_000)
    grids: dict[str, np.ndarray] = {}
    window_values: dict[str, np.ndarray] = {}
    for index, sensor in enumerate(config.sensors):
        values = value_matrix[:, index] if value_matrix.size else np.empty(0, dtype=np.float64)
        window_values[sensor.sensor_uid] = values
        grids[sensor.sensor_uid] = _regular_grid(window_times, values, start_ns, expected_samples, interval_ns)
    spectra = _spectral_features_batch(
        grids, config.spectral_max_missing_ratio, 1.0 / config.expected_interval_seconds, device
    )
    feature_rows = [
        _window_sensor_features(
            sensor, window_times, window_values[sensor.sensor_uid], grids[sensor.sensor_uid],
            start_ns, end_ns, config, spectra[sensor.sensor_uid], events,
        )
        for sensor in config.sensors
    ]
    correlation_rows = _window_correlations(grids, start_ns, end_ns, config, events) if include_correlations else []
    return feature_rows, correlation_rows


_FEATURE_WORKER_CONFIG: PipelineConfig | None = None
_FEATURE_WORKER_EVENTS: Sequence[ReferenceEvent] = ()
_FEATURE_WORKER_DEVICE = torch.device("cpu")
_FEATURE_WORKER_CORRELATIONS = False


def _initialize_feature_worker(
    config: PipelineConfig,
    events: Sequence[ReferenceEvent],
    include_correlations: bool,
) -> None:
    global _FEATURE_WORKER_CONFIG, _FEATURE_WORKER_EVENTS, _FEATURE_WORKER_DEVICE, _FEATURE_WORKER_CORRELATIONS
    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ["MKL_NUM_THREADS"] = "1"
    torch.set_num_threads(1)
    try:
        torch.set_num_interop_threads(1)
    except RuntimeError:
        pass
    _FEATURE_WORKER_CONFIG = config
    _FEATURE_WORKER_EVENTS = events
    _FEATURE_WORKER_DEVICE = torch.device("cpu")
    _FEATURE_WORKER_CORRELATIONS = include_correlations


def _process_feature_window_batch(
    tasks: Sequence[tuple[int, int, np.ndarray, np.ndarray]],
) -> list[tuple[list[dict[str, Any]], list[dict[str, Any]]]]:
    if _FEATURE_WORKER_CONFIG is None:
        raise RuntimeError("feature worker was not initialized")
    results = []
    for start_ns, end_ns, window_times, value_matrix in tasks:
        results.append(_compute_feature_window(
            _FEATURE_WORKER_CONFIG,
            _FEATURE_WORKER_EVENTS,
            _FEATURE_WORKER_DEVICE,
            _FEATURE_WORKER_CORRELATIONS,
            start_ns,
            end_ns,
            window_times,
            value_matrix,
        ))
    return results


def extract_features(
    files: Sequence[Path],
    config: PipelineConfig,
    features_output: Path,
    correlations_output: Path | None,
    reference_events_path: Path | None,
    chunksize: int,
    device_name: str,
    overwrite: bool,
    hash_inputs: bool,
    workers: int = 1,
    duplicate_policy: str = "error",
    duplicate_audit_manifest: Path | None = None,
    duplicate_audit_sha256: str | None = None,
    confirm_conflicting_action_reviewed: bool = False,
    confirm_conflicting_mean_approved: bool = False,
    conflicting_mean_approval_ref: str | None = None,
) -> dict[str, Any]:
    if workers < 1 or workers > 32:
        raise PipelineError("WORKER_COUNT_INVALID", str(workers))
    if duplicate_policy not in {"error", "safe", "exclude-conflicts", "mean-conflicts"}:
        raise PipelineError("DUPLICATE_POLICY_INVALID", duplicate_policy)
    authorization = _validate_duplicate_authorization(
        files, config, duplicate_policy, duplicate_audit_manifest, duplicate_audit_sha256,
        confirm_conflicting_action_reviewed, confirm_conflicting_mean_approved,
        conflicting_mean_approval_ref,
    )
    started_at = time.monotonic()
    requested_device = resolve_device(device_name)
    if workers > 1 and requested_device.type == "cuda" and device_name != "auto":
        raise PipelineError(
            "MULTIPROCESS_CUDA_UNSUPPORTED",
            "Use --workers 1 with CUDA, or --device cpu with multiple workers",
        )
    device = torch.device("cpu") if workers > 1 else requested_device
    events = load_reference_events(reference_events_path, config.timezone)
    feature_writer = StreamingCsvWriter(features_output, overwrite)
    correlation_writer = StreamingCsvWriter(correlations_output, overwrite) if correlations_output else None
    interval_ns = int(config.expected_interval_seconds * 1_000_000_000)
    window_ns = config.window_seconds * 1_000_000_000
    stride_ns = config.stride_seconds * 1_000_000_000
    carry = pd.DataFrame()
    next_start: int | None = None
    last_seen: int | None = None
    window_count = 0
    skipped_empty_window_count = 0
    duplicate_stats = {
        "duplicate_groups": 0,
        "IDENTICAL_DUPLICATE": 0,
        "COMPLEMENTARY_DUPLICATE": 0,
        "CONFLICTING_DUPLICATE": 0,
        "identical_groups_deduplicated": 0,
        "complementary_groups_coalesced": 0,
        "conflicting_groups_excluded": 0,
        "conflicting_groups_mean": 0,
        "rows_removed": 0,
    }
    include_correlations = correlation_writer is not None
    executor: ProcessPoolExecutor | None = None
    window_batch_size = 32
    task_batch: list[tuple[int, int, np.ndarray, np.ndarray]] = []
    pending: deque[Future[list[tuple[list[dict[str, Any]], list[dict[str, Any]]]]]] = deque()
    if workers > 1:
        executor = ProcessPoolExecutor(
            max_workers=workers,
            mp_context=mp.get_context("spawn"),
            initializer=_initialize_feature_worker,
            initargs=(config, events, include_correlations),
        )

    def write_result(result: tuple[list[dict[str, Any]], list[dict[str, Any]]]) -> None:
        feature_rows, correlation_rows = result
        feature_writer.write(feature_rows)
        if correlation_writer:
            correlation_writer.write(correlation_rows)

    def submit_batch() -> None:
        nonlocal task_batch
        if executor is None or not task_batch:
            return
        pending.append(executor.submit(_process_feature_window_batch, tuple(task_batch)))
        task_batch = []

    def drain_one() -> None:
        for result in pending.popleft().result():
            write_result(result)

    try:
        for frame in _iter_feature_frames(files, config, chunksize, duplicate_policy, duplicate_stats):
            times = _timestamp_ns(frame["event_time"])
            if np.any(np.diff(times) <= 0) or (last_seen is not None and int(times[0]) <= last_seen):
                raise PipelineError("NON_MONOTONIC_TIME", "feature extraction requires globally unique increasing timestamps")
            last_seen = int(times[-1])
            if not carry.empty:
                frame = pd.concat([carry, frame], ignore_index=True)
                times = _timestamp_ns(frame["event_time"])
            if next_start is None:
                next_start = int(times[0] // stride_ns * stride_ns)
            complete_through = int(times[-1]) + interval_ns
            while next_start + window_ns <= complete_through:
                end_ns = next_start + window_ns
                left = int(np.searchsorted(times, next_start, side="left"))
                right = int(np.searchsorted(times, end_ns, side="left"))
                if left == right:
                    if left < len(times) and stride_ns == window_ns:
                        jump_start = int(times[left] // stride_ns * stride_ns)
                        if jump_start > next_start:
                            skipped_empty_window_count += int((jump_start - next_start) // stride_ns)
                            next_start = jump_start
                            continue
                    skipped_empty_window_count += 1
                    next_start += stride_ns
                    continue
                window = frame.iloc[left:right]
                window_times = _timestamp_ns(window["event_time"]) if not window.empty else np.empty(0, dtype=np.int64)
                value_matrix = (
                    window.loc[:, [sensor.sensor_uid for sensor in config.sensors]].to_numpy(
                        dtype=np.float64, copy=True
                    )
                    if not window.empty
                    else np.empty((0, len(config.sensors)), dtype=np.float64)
                )
                task = (
                    next_start,
                    end_ns,
                    np.ascontiguousarray(window_times),
                    np.ascontiguousarray(value_matrix),
                )
                if executor is None:
                    write_result(_compute_feature_window(
                        config, events, device, include_correlations, *task
                    ))
                else:
                    task_batch.append(task)
                    if len(task_batch) >= window_batch_size:
                        submit_batch()
                    if len(pending) >= workers * 2:
                        drain_one()
                window_count += 1
                next_start += stride_ns
            carry_start = int(np.searchsorted(times, next_start, side="left"))
            carry = frame.iloc[carry_start:].copy()
        submit_batch()
        while pending:
            drain_one()
        if executor is not None:
            executor.shutdown(wait=True)
            executor = None
        feature_writer.commit()
        if correlation_writer:
            correlation_writer.commit()
    except Exception:
        if executor is not None:
            executor.shutdown(wait=True, cancel_futures=True)
        feature_writer.abort()
        if correlation_writer:
            correlation_writer.abort()
        raise

    manifest = {
        "contract_version": CONTRACT_VERSION,
        "created_at": datetime.now(UTC).isoformat(),
        "dataset_id": config.dataset_id,
        "config_path": str(config.path),
        "config_sha256": config.config_sha256,
        "asset_mapping_status": config.asset_mapping_status,
        "runtime": runtime_versions(False),
        "requested_device": str(requested_device),
        "effective_device": str(device),
        "workers": workers,
        "parallel_window_batch_size": window_batch_size if workers > 1 else 1,
        "parallel_mode": "PROCESS_PER_WINDOW_CPU" if workers > 1 else "SINGLE_PROCESS",
        "elapsed_seconds": time.monotonic() - started_at,
        "input_files": [_file_metadata(path, hash_inputs) for path in files],
        "features_output": str(features_output.expanduser().resolve()),
        "feature_row_count": feature_writer.row_count,
        "correlations_output": str(correlations_output.expanduser().resolve()) if correlations_output else None,
        "correlation_row_count": correlation_writer.row_count if correlation_writer else 0,
        "window_count": window_count,
        "skipped_empty_window_count": skipped_empty_window_count,
        "duplicate_policy": duplicate_policy,
        "duplicate_resolution": duplicate_stats,
        "duplicate_audit_sha256": authorization.get("audit_sha256") if authorization else None,
        "conflicting_mean_field_approved": duplicate_policy == "mean-conflicts" and confirm_conflicting_mean_approved,
        "conflicting_mean_approval_ref": conflicting_mean_approval_ref if duplicate_policy == "mean-conflicts" else None,
        "reference_event_count": len(events),
        "reference_events_are_ground_truth": False,
        "unlabelled_assumed_normal": False,
        "thresholds_inferred": False,
        "lag_correlation_is_causal": False,
    }
    manifest_path = features_output.with_name(f"{features_output.name}.manifest.json")
    _atomic_json(manifest_path, manifest)
    return manifest


def _common_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--input", action="append", required=True, help="File or quoted glob; repeatable")
    parser.add_argument("--chunksize", type=int, default=250_000)
    parser.add_argument("--allow-unconfirmed-mapping", action="store_true")
    parser.add_argument("--strict-versions", action="store_true")
    parser.add_argument("--hash-inputs", action="store_true", help="Expensive for year-scale files")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    versions = subparsers.add_parser("versions", help="Print runtime compatibility")
    versions.add_argument("--strict", action="store_true")

    validate = subparsers.add_parser("validate", help="Validate versions, mapping gate, and every CSV header")
    _common_arguments(validate)

    audit = subparsers.add_parser("audit-duplicates", help="Write internal duplicate group/row audit before resolution")
    _common_arguments(audit)
    audit.add_argument("--output-dir", type=Path, required=True)
    audit.add_argument("--overwrite", action="store_true")

    eda = subparsers.add_parser("eda", help="Generate global and daily read-only EDA")
    _common_arguments(eda)
    eda.add_argument("--output-dir", type=Path, required=True)
    eda.add_argument("--reservoir-size", type=int, default=200_000)
    eda.add_argument("--overwrite", action="store_true")

    features = subparsers.add_parser("features", help="Extract per-window and optional pair-correlation features")
    _common_arguments(features)
    features.add_argument("--features-output", type=Path, required=True)
    features.add_argument("--correlations-output", type=Path)
    features.add_argument("--reference-events", type=Path)
    features.add_argument("--device", default="auto", help="auto, cpu, cuda, or cuda:N")
    features.add_argument("--workers", type=int, default=1, help="CPU feature workers; use up to 4 on the field PC")
    features.add_argument(
        "--duplicate-policy", choices=["error", "safe", "exclude-conflicts", "mean-conflicts"], default="error"
    )
    features.add_argument("--duplicate-audit-manifest", type=Path)
    features.add_argument("--duplicate-audit-sha256")
    features.add_argument("--confirm-conflicting-action-reviewed", action="store_true")
    features.add_argument("--confirm-conflicting-mean-approved", action="store_true")
    features.add_argument("--conflicting-mean-approval-ref")
    features.add_argument("--overwrite", action="store_true")
    return parser


def _prepare(args: argparse.Namespace) -> tuple[PipelineConfig, list[Path]]:
    runtime_versions(args.strict_versions)
    config = load_config(args.config)
    validate_mapping_gate(config, args.allow_unconfirmed_mapping)
    files = discover_files(args.input)
    validate_single_input_format(files)
    validate_headers(files, config)
    _require(args.chunksize > 0, "CHUNKSIZE_INVALID", str(args.chunksize))
    return config, files


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "versions":
        print(json.dumps(runtime_versions(args.strict), ensure_ascii=False, indent=2))
        return 0
    config, files = _prepare(args)
    if args.command == "validate":
        print(json.dumps({
            "status": "VALID",
            "dataset_id": config.dataset_id,
            "mapping_status": config.mapping_status,
            "asset_mapping_status": config.asset_mapping_status,
            "sensor_count": len(config.sensors),
            "files": validate_headers(files, config),
            "timestamp_samples": validate_timestamp_samples(files, config),
        }, ensure_ascii=False, indent=2))
        return 0
    if args.command == "audit-duplicates":
        result = audit_duplicate_timestamps(files, config, args.output_dir, args.chunksize, args.overwrite)
        print(json.dumps({
            "status": "COMPLETED",
            "audit_sha256": result["audit_sha256"],
            "duplicate_timestamp_count": result["duplicate_timestamp_count"],
            "type_counts": result["type_counts"],
            "field_review_required": result["field_review_required"],
            "output": str(args.output_dir),
        }, ensure_ascii=False))
        return 0
    if args.command == "eda":
        result = run_eda(files, config, args.output_dir, args.chunksize, args.reservoir_size, args.overwrite, args.hash_inputs)
        print(json.dumps({"status": "COMPLETED", "output": str(args.output_dir), "source_rows": result["timestamp_quality"]["source_rows"]}, ensure_ascii=False))
        return 0
    if args.command == "features":
        result = extract_features(
            files, config, args.features_output, args.correlations_output, args.reference_events,
            args.chunksize, args.device, args.overwrite, args.hash_inputs, args.workers,
            args.duplicate_policy, args.duplicate_audit_manifest, args.duplicate_audit_sha256,
            args.confirm_conflicting_action_reviewed, args.confirm_conflicting_mean_approved,
            args.conflicting_mean_approval_ref,
        )
        print(json.dumps({"status": "COMPLETED", **result}, ensure_ascii=False))
        return 0
    raise AssertionError(args.command)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except PipelineError as error:
        print(json.dumps({"status": "FAILED", "code": error.code, "message": str(error)}, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(2) from error
