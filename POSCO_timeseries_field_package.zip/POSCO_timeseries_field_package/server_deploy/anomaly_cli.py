"""Field-safe CLI for phased anomaly analysis contracts and control gates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from anomaly_contract import AnomalyContractError
from anomaly_control import validate_controls
from anomaly_phase import generate_phases, review_phases

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_EVENTS = ROOT / "markdown" / "PIMS_우선추출_사건목록.md"
DEFAULT_PHASE_POLICY = Path(__file__).resolve().parent / "config" / "anomaly" / "phase_policy_v1.json"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)

    phases = commands.add_parser("phases", help="Generate non-overlapping event phase registry")
    phases.add_argument("--events", type=Path, default=DEFAULT_EVENTS)
    phases.add_argument("--policy", type=Path, default=DEFAULT_PHASE_POLICY)
    phases.add_argument("--output", type=Path, required=True)
    phases.add_argument("--top", type=int, default=6)
    phases.add_argument("--event", action="append", default=[])
    phases.add_argument("--overwrite", action="store_true")

    review = commands.add_parser("phase-review", help="Single-pass join large Feature CSVs to event phases")
    review.add_argument("--phases", type=Path, required=True)
    review.add_argument("--phase-manifest", type=Path, required=True)
    review.add_argument("--features-3s", type=Path, required=True)
    review.add_argument("--features-4s", type=Path, required=True)
    review.add_argument("--output", type=Path, required=True)
    review.add_argument("--chunksize", type=int, default=200_000)
    review.add_argument("--max-selected-rows", type=int, default=2_000_000)
    review.add_argument("--overwrite", action="store_true")

    controls = commands.add_parser("validate-controls", help="Validate proposed/confirmed control intervals")
    controls.add_argument("--controls", type=Path, required=True)
    controls.add_argument("--phases", type=Path, required=True)
    controls.add_argument("--features-3s", type=Path)
    controls.add_argument("--features-4s", type=Path)
    controls.add_argument("--output", type=Path, required=True)
    controls.add_argument("--chunksize", type=int, default=200_000)
    controls.add_argument("--overwrite", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.command == "phases":
        if args.top < 1:
            raise AnomalyContractError("TOP_INVALID", str(args.top))
        manifest = generate_phases(
            args.events, args.policy, args.output, None if args.event else args.top,
            set(args.event), args.overwrite,
        )
        print((args.output / "phase_receipt.txt").read_text(encoding="utf-8").strip())
        return 0
    if args.command == "phase-review":
        if args.chunksize < 1 or args.max_selected_rows < 1:
            raise AnomalyContractError("CHUNK_OR_LIMIT_INVALID", str(vars(args)))
        review_phases(
            args.phases, args.phase_manifest, args.features_3s, args.features_4s,
            args.output, args.chunksize, args.max_selected_rows, args.overwrite,
        )
        print((args.output / "event_phase_review_receipt.txt").read_text(encoding="utf-8").strip())
        return 0
    feature_values = (args.features_3s, args.features_4s)
    if any(feature_values) and not all(feature_values):
        raise AnomalyContractError("CONTROL_FEATURE_SCOPE_PAIR_REQUIRED", "Provide both 3S and 4S Feature files")
    feature_files = {"3S": args.features_3s, "4S": args.features_4s} if all(feature_values) else None
    validate_controls(
        args.controls, args.phases, feature_files, args.output, args.chunksize, args.overwrite
    )
    print((args.output / "control_review_receipt.txt").read_text(encoding="utf-8").strip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
