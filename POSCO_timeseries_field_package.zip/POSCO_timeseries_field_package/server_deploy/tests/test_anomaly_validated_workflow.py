import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

SERVER_DEPLOY = Path(__file__).resolve().parents[1]
if str(SERVER_DEPLOY) not in sys.path:
    sys.path.insert(0, str(SERVER_DEPLOY))

import anomaly_validated_workflow as workflow

POLICY = SERVER_DEPLOY / "config" / "anomaly" / "validated_workflow_policy_v1.json"


class ValidatedControlWorkflowTest(unittest.TestCase):
    def test_offline_stages_emit_compact_receipts_and_event_evaluation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            policy = json.loads(POLICY.read_text(encoding="utf-8"))
            policy["minimum_baseline_value_count"] = 10
            policy["maximum_control_median_shift_in_pooled_mad"] = 5.0
            policy_path = root / "policy.json"
            policy_path.write_text(json.dumps(policy), encoding="utf-8")
            controls = root / "validated.csv"
            control_rows = []
            dates = ["2024-01-01", "2024-02-01", "2024-03-01"]
            roles = ["TRAIN_CONTROL", "TRAIN_CONTROL", "VALIDATION_CONTROL"]
            for index, (date, role) in enumerate(zip(dates, roles), start=1):
                start = pd.Timestamp(f"{date}T00:00:00+09:00")
                control_rows.append({
                    "control_uid": f"CTRL-{index}", "asset_id": "M-317",
                    "start_time": start.isoformat(), "end_time": (start + pd.Timedelta(hours=2)).isoformat(),
                    "operation_mode": "RUNNING", "operation_mode_status": "CONFIRMED_BY_OWNER",
                    "health_state": "HEALTHY_STATE", "health_state_status": "CONFIRMED_BY_OWNER",
                    "control_role": role, "maintenance_epoch": "M317-EPOCH-1",
                    "validation_status": "VALID_FOR_BASELINE_FIT", "fit_eligible": "true", "online_eligible": "true",
                })
            pd.DataFrame(control_rows).to_csv(controls, index=False)
            intake = root / "vc00"
            workflow.intake_controls(controls, policy_path, intake, False)
            normalized = intake / "normalized_validated_controls.csv"
            self.assertTrue((pd.read_csv(normalized)["workflow_status"] == "READY").all())

            features_3s, features_4s = root / "3s.csv", root / "4s.csv"
            rng = np.random.default_rng(7)
            feature_rows = []
            for control in control_rows:
                starts = pd.date_range(control["start_time"], periods=24, freq="5min")
                for start in starts:
                    value = float(rng.normal(40, 1))
                    feature_rows.append(self._feature(start, value))
            pd.DataFrame(feature_rows).to_csv(features_3s, index=False)
            pd.DataFrame([self._feature(pd.Timestamp("2024-01-01T00:00:00+09:00"), 1, "M-419", "ASN-4S-M419-MOTOR-CURRENT")]).to_csv(features_4s, index=False)
            vc02 = root / "vc02"
            workflow.extract_control_features(normalized, features_3s, features_4s, policy_path, vc02, 13, False)
            control_features = vc02 / "control_feature_windows.csv"
            self.assertEqual(pd.read_csv(control_features)["control_uid"].nunique(), 3)

            vc03 = root / "vc03"
            workflow.control_stability(control_features, policy_path, vc03, False)
            vc04 = root / "vc04"
            workflow.select_features(vc03 / "control_stability_report.csv", policy_path, vc04, False)
            selected = pd.read_csv(vc04 / "selected_feature_contract.csv")
            self.assertTrue(selected["selected"].any())

            vc06 = root / "vc06"
            workflow.fit_m0(control_features, vc04 / "selected_feature_contract.csv", policy_path, vc06, False)
            params = vc06 / "baseline_parameters.csv"
            self.assertTrue((pd.read_csv(params)["fit_status"] == "FIT").any())

            score_control = root / "score-control"
            workflow.score_review(control_features, params, "control", score_control, False)
            vc08 = root / "vc08"
            workflow.select_threshold(score_control / "control_sensor_scores.csv", policy_path, vc08, False)

            event_rows = []
            for index, start in enumerate(pd.date_range("2024-04-01T00:00:00+09:00", periods=12, freq="5min")):
                row = self._feature(start, 55.0 if index < 6 else 40.0)
                row.update({
                    "occurrence_uid": "CASE-TEST#1", "event_uid": "CASE-TEST",
                    "phase": "PRE_1H" if index < 6 else "DURING",
                    "event_time_precision": "EXACT_MINUTE", "label_status": "PRECURSOR_EVALUATION_ONLY",
                })
                event_rows.append(row)
            event_path = root / "event-phase-windows.csv"
            pd.DataFrame(event_rows).to_csv(event_path, index=False)
            score_event = root / "score-event"
            workflow.score_review(event_path, params, "event", score_event, False)
            vc09 = root / "vc09"
            workflow.evaluate_events(
                score_event / "event_sensor_scores.csv", vc08 / "selected_threshold_policy.csv", vc09, False
            )
            result = pd.read_csv(vc09 / "event_detection_results.csv")
            self.assertEqual(result.loc[0, "detection_status"], "PRE_ALERT_DETECTED")
            for stage in (intake, vc02, vc03, vc04, vc06, score_control, vc08, score_event, vc09):
                self.assertTrue(any(stage.glob("*_receipt.txt")))

            all_output = root / "run-all"
            args = type("Args", (), {
                "controls": controls, "features_3s": features_3s, "features_4s": features_4s,
                "event_phase_windows": event_path, "policy": policy_path, "output": all_output,
                "chunksize": 13, "overwrite": False,
            })()
            workflow.run_all(args)
            compact = (all_output / "field_compact_report.txt").read_text(encoding="utf-8")
            self.assertIn("ANOMALY_VALIDATED_WORKFLOW=COMPLETED", compact)
            self.assertIn("VC09=VALID", compact)
            review_path = root / "compact-review.txt"
            workflow.compact_review(all_output, event_path, review_path)
            review = review_path.read_text(encoding="utf-8")
            self.assertIn("VC10=REVIEW", review)
            self.assertIn("VC10C|SOURCE:EVENT_PHASE_WINDOWS|EXPECTED:1|EVALUATED:1|MISSING:0", review)
            self.assertIn("VC10X|MISSING_UID:NONE", review)
            holdout_path = root / "holdout-review.txt"
            workflow.holdout_review(all_output, event_path, event_path, holdout_path)
            holdout = holdout_path.read_text(encoding="utf-8")
            self.assertIn("VC11=HOLDOUT_REVIEW", holdout)
            self.assertIn("ROLE:VALIDATION_CONTROL", holdout)
            self.assertIn("VC11E|CASE-TEST#1", holdout)
            vc12 = root / "vc12"
            workflow.poc_policy_review(all_output, policy_path, vc12, False)
            selected_policy = pd.read_csv(vc12 / "poc_selected_persistence_policy.csv")
            self.assertEqual(selected_policy.loc[0, "minimum_consecutive_windows"], 2)
            self.assertIn("VC12E|M-317|EXACT:1|PERSIST_DET:1", (vc12 / "vc12_compact_detail.txt").read_text())

    @staticmethod
    def _feature(start, value, asset="M-317", sensor="ASN-3S-M317-MOTOR-CURRENT"):
        return {
            "dataset_id": "TEST", "window_start": start.isoformat(),
            "window_end": (start + pd.Timedelta(minutes=5)).isoformat(),
            "asset_id": asset, "sensor_uid": sensor, "measurement_type": "MOTOR_CURRENT", "unit": "A",
            "quality_status": "PASS", "mean": value, "std": abs(value) * 0.02 + 0.1,
            "range": abs(value) * 0.05 + 0.2, "slope_per_second": value * 0.00001,
            "first_last_delta": value * 0.001, "max_abs_change": abs(value) * 0.01,
            "robust_outlier_ratio": 0.0, "spectral_status": "PASS",
            "spectral_entropy": 0.7, "dominant_power_ratio": 0.2,
        }


if __name__ == "__main__":
    unittest.main()
