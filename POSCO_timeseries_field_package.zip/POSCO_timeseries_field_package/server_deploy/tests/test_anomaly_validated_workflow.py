import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

SERVER_DEPLOY = Path(__file__).resolve().parents[1]
if str(SERVER_DEPLOY) not in sys.path:
    sys.path.insert(0, str(SERVER_DEPLOY))

import anomaly_validated_workflow as workflow
import anomaly_m0_shadow as shadow
import anomaly_candidate_graph as candidate_graph
import anomaly_candidate_review as candidate_review
import anomaly_candidate_figures as candidate_figures

POLICY = SERVER_DEPLOY / "config" / "anomaly" / "validated_workflow_policy_v1.json"


class ValidatedControlWorkflowTest(unittest.TestCase):
    def test_offline_stages_emit_compact_receipts_and_event_evaluation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            policy = json.loads(POLICY.read_text(encoding="utf-8"))
            policy["minimum_baseline_value_count"] = 10
            policy["maximum_control_median_shift_in_pooled_mad"] = 5.0
            policy_path = root / "policy.json"
            policy_path.write_text(json.dumps(policy), encoding="utf-8")
            controls = root / "validated.csv"
            control_rows = []
            dates = ["2024-01-01", "2024-02-01", "2024-03-01", "2024-03-15"]
            roles = ["TRAIN_CONTROL", "TRAIN_CONTROL", "VALIDATION_CONTROL", "TEST_CONTROL"]
            for index, (date, role) in enumerate(zip(dates, roles), start=1):
                start = pd.Timestamp(f"{date}T00:00:00+09:00")
                control_rows.append({
                    "control_uid": f"CTRL-{index}", "asset_id": "M-317",
                    "start_time": start.isoformat(), "end_time": (start + pd.Timedelta(hours=2)).isoformat(),
                    "operation_mode": "RUNNING", "operation_mode_status": "CONFIRMED_BY_OWNER",
                    "health_state": "HEALTHY_STATE", "health_state_status": "CONFIRMED_BY_OWNER",
                    "control_role": role, "maintenance_epoch": "M317-EPOCH-1",
                    "validation_status": "VALID_FOR_BASELINE_FIT", "fit_eligible": "true", "online_eligible": "true",
                })
            pd.DataFrame(control_rows).to_csv(controls, index=False)
            intake = root / "vc00"
            workflow.intake_controls(controls, policy_path, intake, False)
            normalized = intake / "normalized_validated_controls.csv"
            self.assertTrue((pd.read_csv(normalized)["workflow_status"] == "READY").all())
            self.assertEqual(len(pd.read_csv(normalized)), 4)

            features_3s, features_4s = root / "3s.csv", root / "4s.csv"
            rng = np.random.default_rng(7)
            feature_rows = []
            for control in control_rows:
                starts = pd.date_range(control["start_time"], periods=24, freq="5min")
                for start in starts:
                    value = float(rng.normal(40, 1))
                    feature_rows.append(self._feature(start, value))
            pd.DataFrame(feature_rows).to_csv(features_3s, index=False)
            pd.DataFrame([self._feature(pd.Timestamp("2024-01-01T00:00:00+09:00"), 1, "M-419", "ASN-4S-M419-MOTOR-CURRENT")]).to_csv(features_4s, index=False)
            vc02 = root / "vc02"
            workflow.extract_control_features(normalized, features_3s, features_4s, policy_path, vc02, 13, False)
            control_features = vc02 / "control_feature_windows.csv"
            self.assertEqual(pd.read_csv(control_features)["control_uid"].nunique(), 4)

            vc03 = root / "vc03"
            workflow.control_stability(control_features, policy_path, vc03, False)
            vc04 = root / "vc04"
            workflow.select_features(vc03 / "control_stability_report.csv", policy_path, vc04, False)
            selected = pd.read_csv(vc04 / "selected_feature_contract.csv")
            self.assertTrue(selected["selected"].any())

            vc06 = root / "vc06"
            workflow.fit_m0(control_features, vc04 / "selected_feature_contract.csv", policy_path, vc06, False)
            params = vc06 / "baseline_parameters.csv"
            self.assertTrue((pd.read_csv(params)["fit_status"] == "FIT").any())

            score_control = root / "score-control"
            workflow.score_review(control_features, params, "control", score_control, False)
            vc08 = root / "vc08"
            workflow.select_threshold(score_control / "control_sensor_scores.csv", policy_path, vc08, False)

            event_rows = []
            for index, start in enumerate(pd.date_range("2024-04-01T00:00:00+09:00", periods=12, freq="5min")):
                row = self._feature(start, 55.0 if index < 6 else 40.0)
                row.update({
                    "occurrence_uid": "CASE-TEST#1", "event_uid": "CASE-TEST",
                    "phase": "PRE_1H" if index < 6 else "DURING",
                    "event_time_precision": "EXACT_MINUTE", "label_status": "PRECURSOR_EVALUATION_ONLY",
                })
                event_rows.append(row)
            event_path = root / "event-phase-windows.csv"
            pd.DataFrame(event_rows).to_csv(event_path, index=False)
            reference_path = root / "reference-phases.csv"
            pd.DataFrame([{
                "occurrence_uid": "CASE-TEST#1", "asset_id": "M-317",
                "event_start": "2024-04-01T00:30:00+09:00", "event_time_precision": "EXACT_MINUTE",
            }]).to_csv(reference_path, index=False)
            score_event = root / "score-event"
            workflow.score_review(event_path, params, "event", score_event, False)
            vc09 = root / "vc09"
            workflow.evaluate_events(
                score_event / "event_sensor_scores.csv", vc08 / "selected_threshold_policy.csv", vc09, False
            )
            result = pd.read_csv(vc09 / "event_detection_results.csv")
            self.assertEqual(result.loc[0, "detection_status"], "PRE_ALERT_DETECTED")
            for stage in (intake, vc02, vc03, vc04, vc06, score_control, vc08, score_event, vc09):
                self.assertTrue(any(stage.glob("*_receipt.txt")))

            all_output = root / "run-all"
            args = type("Args", (), {
                "controls": controls, "features_3s": features_3s, "features_4s": features_4s,
                "event_phase_windows": event_path, "policy": policy_path, "output": all_output,
                "chunksize": 13, "overwrite": False,
            })()
            workflow.run_all(args)
            compact = (all_output / "field_compact_report.txt").read_text(encoding="utf-8")
            self.assertIn("ANOMALY_VALIDATED_WORKFLOW=COMPLETED", compact)
            self.assertIn("VC09=VALID", compact)
            review_path = root / "compact-review.txt"
            workflow.compact_review(all_output, event_path, review_path)
            review = review_path.read_text(encoding="utf-8")
            self.assertIn("VC10=REVIEW", review)
            self.assertIn("VC10C|SOURCE:EVENT_PHASE_WINDOWS|EXPECTED:1|EVALUATED:1|MISSING:0", review)
            self.assertIn("VC10X|MISSING_UID:NONE", review)
            holdout_path = root / "holdout-review.txt"
            workflow.holdout_review(all_output, event_path, event_path, holdout_path)
            holdout = holdout_path.read_text(encoding="utf-8")
            self.assertIn("VC11=HOLDOUT_REVIEW", holdout)
            self.assertIn("ROLE:VALIDATION_CONTROL", holdout)
            self.assertIn("VC11E|CASE-TEST#1", holdout)
            vc12 = root / "vc12"
            workflow.poc_policy_review(all_output, policy_path, vc12, False)
            selected_policy = pd.read_csv(vc12 / "poc_selected_persistence_policy.csv")
            self.assertEqual(selected_policy.loc[0, "minimum_consecutive_windows"], 2)
            self.assertIn("VC12E|M-317|EXACT:1|PERSIST_DET:1", (vc12 / "vc12_compact_detail.txt").read_text())
            vc13 = root / "vc13"
            workflow.freeze_m0_bundle(all_output, vc12, policy_path, vc13, False)
            bundle = json.loads((vc13 / "m0_model_bundle.json").read_text())
            self.assertEqual(bundle["contract_version"], workflow.M0_BUNDLE_CONTRACT)
            self.assertFalse(bundle["production_use_allowed"])
            self.assertEqual(len(bundle["models"]), 1)
            self.assertEqual(bundle["minimum_scored_parameter_ratio"], 0.95)
            invalid_bundle = dict(bundle)
            invalid_bundle.pop("minimum_scored_parameter_ratio")
            invalid_path = root / "invalid-bundle.json"
            invalid_path.write_text(json.dumps(invalid_bundle), encoding="utf-8")
            with self.assertRaises(workflow.AnomalyContractError) as raised:
                shadow.load_bundle(invalid_path)
            self.assertEqual(raised.exception.code, "M0_BUNDLE_FEATURE_COVERAGE_POLICY_REQUIRED")
            vc14 = root / "vc14"
            workflow.exact_lead_review(all_output, vc12, reference_path, vc14, False)
            lead = pd.read_csv(vc14 / "exact_event_lead_results.csv")
            self.assertTrue(lead.loc[0, "persistent_detection"])
            self.assertEqual(lead.loc[0, "online_evaluation_status"], "ONLINE_NOT_EVALUABLE_EVENT_EPOCH_UNVERIFIED")
            states = root / "states.csv"
            pd.DataFrame([{
                "state_uid": "STATE-1", "asset_id": "M-317",
                "start_time": "2024-04-01T00:00:00+09:00", "end_time": "2024-04-02T00:00:00+09:00",
                "maintenance_epoch": bundle["models"][0]["maintenance_epoch"],
                "operation_mode": "RUNNING", "operation_mode_status": "CONFIRMED_BY_OWNER",
                "health_state": "UNKNOWN", "health_state_status": "NOT_CONFIRMED",
            }]).to_csv(states, index=False)
            vc15 = root / "vc15"
            shadow.run_shadow(vc13 / "m0_model_bundle.json", states, [event_path], vc15, 5, False)
            shadow_result = pd.read_csv(vc15 / "m0_shadow_window_decisions.csv")
            self.assertTrue((shadow_result["decision"] == "POC_ANOMALY_CANDIDATE").any())
            self.assertTrue(shadow_result["machine_pre_candidate"].any())
            vc16 = root / "vc16"
            candidate_graph.build_graphs(vc15 / "m0_shadow_window_decisions.csv", vc16, False)
            graph_index = pd.read_csv(vc16 / "candidate_episode_index.csv")
            self.assertEqual(len(graph_index), 1)
            self.assertTrue(next((vc16 / "graphs").glob("*.svg")).read_text().startswith("<svg"))
            vc18 = root / "vc18"
            candidate_figures.build_figures(vc16 / "candidate_episode_index.csv", [event_path], vc18, 1, 0.3, 5, False)
            sensor_figure = next((vc18 / "figures").glob("*.svg")).read_text()
            self.assertIn("실제 5분 Sensor Mean", sensor_figure)
            self.assertIn("ASN-3S-M317-MOTOR-CURRENT", sensor_figure)
            review_sheet = pd.read_csv(vc16 / "candidate_field_review_template.csv", dtype=str).fillna("")
            review_sheet.loc[:, "field_decision"] = "CONFIRM_POC_CANDIDATE"
            review_sheet.loc[:, "confirmed_operation_mode"] = "RUNNING"
            review_sheet.loc[:, "maintenance_overlap"] = "NO"
            review_sheet.loc[:, "epoch_review_status"] = "MATCH"
            review_sheet.loc[:, "sensor_condition"] = "NO_SENSOR_ISSUE_CONFIRMED"
            review_sheet.loc[:, "reviewer_reference"] = "FIELD-REVIEW-1"
            review_sheet.loc[:, "reviewed_at"] = "2024-04-03T00:00:00+09:00"
            filled_review = root / "filled-review.csv"
            review_sheet.to_csv(filled_review, index=False)
            vc17 = root / "vc17"
            candidate_review.validate_review(vc16 / "candidate_episode_index.csv", filled_review, vc17, False)
            self.assertIn("CONFIRM:1", (vc17 / "vc17_compact_detail.txt").read_text())
            empty_states = root / "empty-states.csv"
            pd.DataFrame(columns=shadow.STATE_COLUMNS).to_csv(empty_states, index=False)
            vc15_review = root / "vc15-review"
            shadow.run_shadow(vc13 / "m0_model_bundle.json", empty_states, [event_path], vc15_review, 5, False)
            review_decisions = pd.read_csv(vc15_review / "m0_shadow_window_decisions.csv")
            self.assertTrue((review_decisions["decision"] == "POC_ANOMALY_PRE_CANDIDATE_REVIEW_REQUIRED").any())
            no_candidate = review_decisions.copy()
            no_candidate["machine_pre_candidate"] = False
            no_candidate["decision"] = "NO_CANDIDATE"
            no_candidate_path = root / "no-candidate.csv"
            no_candidate.to_csv(no_candidate_path, index=False)
            vc16_empty = root / "vc16-empty"
            candidate_graph.build_graphs(no_candidate_path, vc16_empty, False)
            self.assertEqual(len(pd.read_csv(vc16_empty / "candidate_episode_index.csv")), 0)
            self.assertIn("EP:0", (vc16_empty / "vc16_compact_detail.txt").read_text())

    @staticmethod
    def _feature(start, value, asset="M-317", sensor="ASN-3S-M317-MOTOR-CURRENT"):
        return {
            "dataset_id": "TEST", "window_start": start.isoformat(),
            "window_end": (start + pd.Timedelta(minutes=5)).isoformat(),
            "asset_id": asset, "sensor_uid": sensor, "measurement_type": "MOTOR_CURRENT", "unit": "A",
            "quality_status": "PASS", "mean": value, "std": abs(value) * 0.02 + 0.1,
            "range": abs(value) * 0.05 + 0.2, "slope_per_second": value * 0.00001,
            "first_last_delta": value * 0.001, "max_abs_change": abs(value) * 0.01,
            "robust_outlier_ratio": 0.0, "spectral_status": "PASS",
            "spectral_entropy": 0.7, "dominant_power_ratio": 0.2,
        }


if __name__ == "__main__":
    unittest.main()
