import json
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

SERVER_DEPLOY = Path(__file__).resolve().parents[1]
ROOT = SERVER_DEPLOY.parent
if str(SERVER_DEPLOY) not in sys.path:
    sys.path.insert(0, str(SERVER_DEPLOY))

import anomaly_phase as phase

EVENTS = ROOT / "markdown" / "PIMS_우선추출_사건목록.md"
POLICY = SERVER_DEPLOY / "config" / "anomaly" / "phase_policy_v1.json"


class AnomalyPhaseTest(unittest.TestCase):
    def test_top_six_generate_non_overlapping_56_phases_and_low_precision_gate(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "phases"
            manifest = phase.generate_phases(EVENTS, POLICY, output, 6, set(), False)
            second = phase.generate_phases(EVENTS, POLICY, Path(directory) / "phases-2", 6, set(), False)
            self.assertEqual(manifest["receipt_sha256"], second["receipt_sha256"])
            self.assertEqual(manifest["phase_count"], 56)
            self.assertEqual(manifest["low_time_precision_phase_count"], 8)
            rows = pd.read_csv(output / "reference_event_phases.csv")
            self.assertEqual(len(rows), 56)
            self.assertEqual(rows["phase_uid"].nunique(), 56)
            for _, group in rows.groupby("occurrence_uid"):
                ordered = group.sort_values("start_time")
                starts = pd.to_datetime(ordered["start_time"], utc=True).reset_index(drop=True)
                ends = pd.to_datetime(ordered["end_time"], utc=True).reset_index(drop=True)
                self.assertTrue(all(ends.iloc[index] <= starts.iloc[index + 1] for index in range(len(group) - 1)))
            case_009 = rows[rows["occurrence_uid"] == "CASE-009#1"]
            self.assertTrue((case_009["label_status"] == "LOW_TIME_PRECISION").all())
            self.assertTrue((case_009["lead_time_eligible"] == False).all())

    def test_single_pass_phase_review_marks_cross_occurrence_context(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            phase_dir = root / "phases"
            phase.generate_phases(EVENTS, POLICY, phase_dir, None, {"CASE-001", "CASE-003"}, False)
            feature_3s = root / "3s.csv"
            feature_4s = root / "4s.csv"
            self._write_features(feature_3s, [
                self._row("2025-01-07T09:40:00+09:00", "M-317", "ASN-3S-M317-MOTOR-CURRENT", 10.0),
                self._row("2025-01-07T09:45:00+09:00", "M-317", "ASN-3S-M317-MOTOR-CURRENT", 0.0),
            ])
            self._write_features(feature_4s, [
                self._row("2025-03-05T18:00:00+09:00", "M-419", "ASN-4S-M419-MOTOR-CURRENT", 0.0),
                self._row("2025-03-06T15:45:00+09:00", "M-419", "ASN-4S-M419-MOTOR-CURRENT", 5.0),
            ])
            review_dir = root / "review"
            manifest = phase.review_phases(
                phase_dir / "reference_event_phases.csv", phase_dir / "phase_manifest.json",
                feature_3s, feature_4s, review_dir, 1, 1000, False,
            )
            scan = manifest["scan"]
            self.assertEqual(scan["source_rows_scanned"], 4)
            self.assertGreater(scan["context_overlap_rows"], 0)
            self.assertGreater(scan["numerical_constant_rows"], 0)
            windows = pd.read_csv(review_dir / "event_phase_windows.csv")
            self.assertIn("SHARED_ACROSS_OCCURRENCE_CONTEXTS", set(windows["context_overlap_status"]))
            self.assertIn("REVIEW_NUMERICAL_CONSTANT", set(windows["spectral_review_status"]))
            summary = pd.read_csv(review_dir / "event_phase_feature_summary.csv")
            self.assertTrue((summary["baseline_status"] == "PHASE_CONTEXT_ONLY_NOT_CONFIRMED_NORMAL").all())

    @staticmethod
    def _row(start: str, asset: str, sensor: str, value_range: float):
        start_time = pd.Timestamp(start)
        return {
            "dataset_id": "TEST",
            "window_start": start_time.isoformat(),
            "window_end": (start_time + pd.Timedelta(minutes=5)).isoformat(),
            "sensor_uid": sensor,
            "asset_id": asset,
            "measurement_type": "MOTOR_CURRENT",
            "unit": "A",
            "valid_sample_count": 300,
            "missing_sample_count": 0,
            "longest_missing_run_seconds": 0,
            "coverage_ratio": 1.0,
            "quality_status": "PASS",
            "spectral_status": "PASS",
            "mean": 1.0,
            "std": 0.1,
            "range": value_range,
            "spectral_entropy": 0.5,
        }

    @staticmethod
    def _write_features(path: Path, rows):
        pd.DataFrame(rows).to_csv(path, index=False)


if __name__ == "__main__":
    unittest.main()
