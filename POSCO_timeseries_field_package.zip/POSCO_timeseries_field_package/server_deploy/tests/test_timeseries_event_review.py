import tempfile
import unittest
from pathlib import Path

import pandas as pd

from server_deploy import timeseries_event_review as review


ROOT = Path(__file__).resolve().parents[2]
EVENTS = ROOT / "markdown" / "PIMS_우선추출_사건목록.md"


class EventReviewTest(unittest.TestCase):
    def test_priority_markdown_parses_top_six_into_seven_occurrences(self):
        events = review.parse_priority_events(EVENTS)
        self.assertEqual(len(events), 30)
        occurrences = review.select_occurrences(events, 6, set())
        self.assertEqual([item.event.event_uid for item in occurrences], [
            "CASE-001", "CASE-003", "CASE-003", "CASE-013", "CASE-004", "CASE-002", "CASE-009",
        ])
        self.assertEqual(occurrences[0].start.isoformat(), "2025-01-07T09:45:00+09:00")
        self.assertEqual(occurrences[1].start.isoformat(), "2025-03-04T21:33:00+09:00")
        self.assertEqual(occurrences[2].start.isoformat(), "2025-03-06T15:43:00+09:00")
        self.assertEqual(occurrences[-1].precision, "DATE_RANGE_FULL_DAY")

    def test_chunk_scan_filters_assets_and_summarizes_before_during_after(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            events = review.parse_priority_events(EVENTS)
            occurrences = review.select_occurrences(events, None, {"CASE-001", "CASE-003"})
            rows_3s = self._rows("M-317", "ASN-3S-M317-MOTOR-CURRENT", "2025-01-07 08:00", 18)
            rows_3s += self._rows("M-319", "ASN-3S-M319-MOTOR-CURRENT", "2025-01-07 08:00", 18)
            rows_4s = self._rows("M-419", "ASN-4S-M419-MOTOR-CURRENT", "2025-03-04 20:00", 30)
            rows_4s += self._rows("M-419", "ASN-4S-M419-MOTOR-CURRENT", "2025-03-06 14:00", 30)
            path_3s, path_4s = root / "3s.csv", root / "4s.csv"
            pd.DataFrame(rows_3s).to_csv(path_3s, index=False)
            pd.DataFrame(rows_4s).to_csv(path_4s, index=False)
            windows, stats = review.scan_event_windows(
                {"3S": path_3s, "4S": path_4s}, occurrences, root / "windows.csv",
                before_hours=2, after_hours=2, chunksize=7, max_selected_rows=10_000,
            )
            self.assertEqual(stats["source_rows_scanned"], len(rows_3s) + len(rows_4s))
            self.assertGreater(stats["numerical_constant_spectral_pass_rows"], 0)
            self.assertIn("REVIEW_NUMERICAL_CONSTANT", set(windows["spectral_review_status"]))
            numerical_constant = windows["spectral_review_status"] == "REVIEW_NUMERICAL_CONSTANT"
            self.assertTrue(windows.loc[numerical_constant, "spectral_entropy"].isna().all())
            self.assertNotIn("M-319", set(windows["asset_id"]))
            self.assertEqual(set(windows["phase"]), {"BEFORE", "DURING", "AFTER"})
            summary = review.summarize_event_windows(windows, ["mean", "std"])
            self.assertFalse(summary.empty)
            self.assertTrue((summary["baseline_status"] == "CONTEXT_ONLY_NOT_CONFIRMED_NORMAL").all())
            review.write_markdown_report(root / "report.md", occurrences, windows, summary, 2, 2)
            self.assertIn("인과 판정이 아니다", (root / "report.md").read_text(encoding="utf-8"))

    @staticmethod
    def _rows(asset_id: str, sensor_uid: str, start: str, count: int):
        starts = pd.date_range(start, periods=count, freq="5min", tz="Asia/Seoul")
        rows = []
        for index, window_start in enumerate(starts):
            rows.append({
                "dataset_id": "TEST",
                "window_start": window_start.isoformat(),
                "window_end": (window_start + pd.Timedelta(minutes=5)).isoformat(),
                "sensor_uid": sensor_uid,
                "asset_id": asset_id,
                "measurement_type": "MOTOR_CURRENT",
                "unit": "A",
                "valid_sample_count": 300,
                "missing_sample_count": 0,
                "longest_missing_run_seconds": 0,
                "coverage_ratio": 1.0,
                "quality_status": "PASS",
                "spectral_status": "PASS",
                "mean": float(index),
                "std": float(index + 1),
                "max": float(index + 2),
                "range": 0.0 if index == 0 else 2.0,
                "slope_per_second": 0.01,
                "first_last_delta": 1.0,
                "max_abs_change": 0.5,
                "robust_outlier_ratio": 0.0,
                "spectral_entropy": 0.8,
                "dominant_power_ratio": 0.2,
            })
        return rows


if __name__ == "__main__":
    unittest.main()
