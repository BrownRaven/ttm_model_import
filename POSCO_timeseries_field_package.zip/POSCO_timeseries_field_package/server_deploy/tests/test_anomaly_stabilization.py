import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

SERVER_DEPLOY = Path(__file__).resolve().parents[1]
ROOT = SERVER_DEPLOY.parent
if str(SERVER_DEPLOY) not in sys.path:
    sys.path.insert(0, str(SERVER_DEPLOY))

HAS_VISUAL = importlib.util.find_spec("statsmodels") is not None

import anomaly_phase as phase
import anomaly_stabilization as stabilization

EVENTS = ROOT / "markdown" / "PIMS_우선추출_사건목록.md"
PHASE_POLICY = SERVER_DEPLOY / "config" / "anomaly" / "phase_policy_v1.json"
STABILIZATION_POLICY = SERVER_DEPLOY / "config" / "anomaly" / "stabilization_policy_v1.json"


@unittest.skipUnless(HAS_VISUAL, "statsmodels is not installed")
class AnomalyStabilizationTest(unittest.TestCase):
    def test_stationarity_test_distinguishes_stable_noise_and_trend(self):
        policy = stabilization.load_stabilization_policy(STABILIZATION_POLICY)
        stable = np.random.default_rng(2).normal(10, 1, 72)
        trending = np.arange(72, dtype=float) + np.random.default_rng(2).normal(0, 0.05, 72)
        self.assertEqual(
            stabilization._stationarity_test(stable, policy)["test_status"],
            "STRONG_STATIONARITY_CANDIDATE",
        )
        self.assertEqual(
            stabilization._stationarity_test(trending, policy)["test_status"],
            "NOT_STATIONARY_CANDIDATE",
        )

    def test_end_to_end_generates_proposed_candidate_and_field_figure(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            phase_dir = root / "phases"
            phase.generate_phases(EVENTS, PHASE_POLICY, phase_dir, None, {"CASE-001"}, False)
            feature_3s = root / "3s.csv"
            feature_4s = root / "4s.csv"
            event_end = pd.Timestamp("2025-01-07T14:10:00+09:00")
            starts = pd.date_range(event_end, periods=10 * 24 * 12, freq="5min")
            rng = np.random.default_rng(4)
            rows = []
            for start, value in zip(starts, rng.normal(40, 0.8, len(starts))):
                rows.append(self._feature(start, "M-317", "ASN-3S-M317-MOTOR-CURRENT", float(value)))
            pd.DataFrame(rows).to_csv(feature_3s, index=False)
            pd.DataFrame([
                self._feature(pd.Timestamp("2025-01-01T00:00:00+09:00"), "M-419", "ASN-4S-M419-MOTOR-CURRENT", 1.0)
            ]).to_csv(feature_4s, index=False)
            policy = json.loads(STABILIZATION_POLICY.read_text(encoding="utf-8"))
            policy.update({
                "horizon_days": 10,
                "stability_window_hours": 48,
                "candidate_scan_stride_hours": 6,
                "consecutive_passes": 2,
                "proposed_control_days": 7,
            })
            policy_path = root / "policy.json"
            policy_path.write_text(json.dumps(policy), encoding="utf-8")
            output = root / "stabilization"
            manifest = stabilization.run_stabilization_review(
                phase_dir / "reference_event_phases.csv", feature_3s, feature_4s,
                policy_path, output, 233, False,
            )
            self.assertEqual(manifest["occurrence_count"], 1)
            self.assertEqual(manifest["figure_count"], 1)
            candidates = pd.read_csv(output / "proposed_control_candidates.csv")
            self.assertEqual(candidates.loc[0, "candidate_status"], "STATISTICAL_STABILIZATION_CANDIDATE")
            self.assertEqual(candidates.loc[0, "normality_status"], "NOT_CONFIRMED_NORMAL")
            figure = next((output / "figures").glob("*.svg"))
            self.assertTrue(figure.stat().st_size > 1000)
            self.assertIn("STDLIB_SVG", manifest["runtime_versions"]["figure_renderer"])

    @staticmethod
    def _feature(start: pd.Timestamp, asset: str, sensor: str, value: float):
        return {
            "window_start": start.isoformat(),
            "window_end": (start + pd.Timedelta(minutes=5)).isoformat(),
            "asset_id": asset,
            "sensor_uid": sensor,
            "measurement_type": "MOTOR_CURRENT",
            "unit": "A",
            "quality_status": "PASS",
            "mean": value,
        }


if __name__ == "__main__":
    unittest.main()
