import csv
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

SERVER_DEPLOY = Path(__file__).resolve().parents[1]
CONFIG_3S = SERVER_DEPLOY / "config" / "timeseries" / "sinter3_wide_1s.json"
CONFIG_4S = SERVER_DEPLOY / "config" / "timeseries" / "sinter4_wide_1s.json"
ACTUAL_SAMPLE_3S = SERVER_DEPLOY.parent / "3S_1LINE_CSV.txt"
ACTUAL_SAMPLE_4S = SERVER_DEPLOY.parent / "4S_1LINE_CSV.txt"
HAS_STACK = all(importlib.util.find_spec(name) is not None for name in ("numpy", "pandas", "torch"))


class TimeSeriesConfigInventoryTest(unittest.TestCase):
    def test_sensor_inventory_is_13_plus_10_with_confirmed_temperature_and_current_units(self):
        config_3s = json.loads(CONFIG_3S.read_text(encoding="utf-8"))
        config_4s = json.loads(CONFIG_4S.read_text(encoding="utf-8"))
        self.assertEqual(len(config_3s["sensors"]), 13)
        self.assertEqual(len(config_4s["sensors"]), 10)
        self.assertEqual({item["asset_id"] for item in config_3s["sensors"]}, {"M-317", "M-319"})
        self.assertEqual({item["asset_id"] for item in config_4s["sensors"]}, {"M-417", "M-419"})
        self.assertEqual(sum(item["unit"] == "A" for item in config_3s["sensors"]), 2)
        self.assertEqual(sum(item["unit"] == "degC" for item in config_3s["sensors"]), 9)
        self.assertEqual(sum(item["unit"] == "l/min" for item in config_3s["sensors"]), 1)
        self.assertEqual(sum(item["unit"] == "Bar" for item in config_3s["sensors"]), 1)
        self.assertTrue(all(item["unit_status"] == "CONFIRMED_BY_OWNER" for item in config_3s["sensors"]))
        self.assertEqual(sum(item["unit"] == "A" for item in config_4s["sensors"]), 2)
        self.assertEqual(sum(item["unit"] == "degC" for item in config_4s["sensors"]), 8)
        self.assertEqual(config_3s["mapping_status"], "CONFIRMED_FROM_SAMPLE")
        self.assertEqual(config_3s["asset_mapping_status"], "CONFIRMED_FROM_HEADER")
        self.assertEqual(config_4s["mapping_status"], "CONFIRMED_FROM_SAMPLE")
        self.assertEqual(config_4s["asset_mapping_status"], "CONFIRMED_BY_OWNER")
        self.assertEqual(config_3s["timestamp"]["column"], "time")
        self.assertTrue(config_3s["timestamp"]["dayfirst"])
        self.assertEqual(config_4s["timestamp"]["column"], "time")
        self.assertTrue(config_4s["timestamp"]["dayfirst"])
        self.assertEqual(config_3s["timestamp"]["timezone_status"], "ASSUMED_LOCAL_KST_CONFIRM_REQUIRED")
        self.assertEqual(config_4s["timestamp"]["timezone_status"], "ASSUMED_LOCAL_KST_CONFIRM_REQUIRED")


@unittest.skipUnless(HAS_STACK, "target NumPy/pandas/PyTorch stack is not installed in the lightweight test runtime")
class TimeSeriesPipelineIntegrationTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(SERVER_DEPLOY))
        global pipeline, synthetic, compact
        import timeseries_pipeline as pipeline
        import timeseries_synthetic as synthetic
        import timeseries_compact_report as compact

    @unittest.skipUnless(
        ACTUAL_SAMPLE_3S.is_file() and ACTUAL_SAMPLE_4S.is_file(),
        "local one-line actual-format samples are intentionally not tracked",
    )
    def test_actual_headers_and_dayfirst_timestamp_samples(self):
        config_3s = pipeline.load_config(CONFIG_3S)
        config_4s = pipeline.load_config(CONFIG_4S)
        pipeline.validate_mapping_gate(config_3s, False)
        pipeline.validate_mapping_gate(config_4s, False)
        self.assertEqual(len(pipeline.validate_headers([ACTUAL_SAMPLE_3S], config_3s)[0]["header"]), 14)
        self.assertEqual(len(pipeline.validate_headers([ACTUAL_SAMPLE_4S], config_4s)[0]["header"]), 11)
        timestamp_3s = pipeline.validate_timestamp_samples([ACTUAL_SAMPLE_3S], config_3s)[0]
        timestamp_4s = pipeline.validate_timestamp_samples([ACTUAL_SAMPLE_4S], config_4s)[0]
        self.assertEqual(timestamp_3s["valid_timestamp_count"], 3)
        self.assertEqual(timestamp_4s["valid_timestamp_count"], 3)
        self.assertEqual(timestamp_3s["min_event_time"], "2024-12-08T00:27:22.140000+09:00")
        self.assertEqual(timestamp_4s["min_event_time"], "2025-02-02T00:14:54.850000+09:00")
        for source, config in ((ACTUAL_SAMPLE_3S, config_3s), (ACTUAL_SAMPLE_4S, config_4s)):
            parsed = next(pipeline.iter_parsed_chunks([source], config, 10))
            times = pipeline._timestamp_ns(parsed.frame["event_time"])
            self.assertTrue((pipeline.np.diff(times) == 1_000_000_000).all())

    def test_column_order_is_irrelevant_but_column_names_remain_exact(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            generated = synthetic.generate(root / "input", sample_count=600)
            item = next(value for value in generated["datasets"] if value["dataset"] == "3S")
            source = root / "input" / item["csv_file"]
            config = pipeline.load_config(CONFIG_3S)
            frame = pipeline.pd.read_csv(source, sep=";", dtype="string")
            reordered = root / "reordered.csv"
            reordered_columns = list(reversed(frame.columns.tolist()))
            frame.loc[:, reordered_columns].to_csv(reordered, sep=";", index=False)

            validation = pipeline.validate_headers([reordered], config)[0]
            self.assertFalse(validation["column_order_required"])
            original = next(pipeline.iter_parsed_chunks([source], config, 1000)).frame
            changed = next(pipeline.iter_parsed_chunks([reordered], config, 1000)).frame
            self.assertEqual(list(original.columns), list(changed.columns))
            for column in original.columns:
                self.assertTrue(original[column].equals(changed[column]))

            renamed = frame.rename(columns={frame.columns[1]: f"{frame.columns[1]}_WRONG"})
            renamed_path = root / "renamed.csv"
            renamed.to_csv(renamed_path, sep=";", index=False)
            with self.assertRaises(pipeline.PipelineError) as error:
                pipeline.validate_headers([renamed_path], config)
            self.assertEqual(error.exception.code, "CSV_HEADER_MISMATCH")
            self.assertIn("column_order_required", str(error.exception))

    def test_actual_shape_synthetic_eda_feature_and_correlation_smoke(self):
        expected = {
            "3S": {"config": CONFIG_3S, "features": 78, "correlations": 216},
            "4S": {"config": CONFIG_4S, "features": 60, "correlations": 120},
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            generated = synthetic.generate(root / "input")
            profile_paths = {}
            feature_paths = {}
            self.assertTrue(generated["synthetic_only"])
            self.assertFalse(generated["actual_source_values_copied"])
            self.assertFalse(generated["production_use_allowed"])
            self.assertFalse(generated["model_training_allowed"])
            for dataset in generated["datasets"]:
                expectation = expected[dataset["dataset"]]
                config = pipeline.load_config(expectation["config"])
                source = root / "input" / dataset["csv_file"]
                events = root / "input" / dataset["reference_events_file"]
                pipeline.validate_headers([source], config)
                timestamp_sample = pipeline.validate_timestamp_samples([source], config)
                self.assertEqual(timestamp_sample[0]["invalid_timestamp_count"], 0)
                eda_dir = root / f"eda-{dataset['dataset']}"
                profile = pipeline.run_eda([source], config, eda_dir, 317, 500, False, False)
                features_path = root / f"features-{dataset['dataset']}.csv"
                profile_paths[dataset["dataset"]] = eda_dir / "eda_profile.json"
                feature_paths[dataset["dataset"]] = features_path
                manifest = pipeline.extract_features(
                    [source], config, features_path, root / f"correlations-{dataset['dataset']}.csv",
                    events, 317, "cpu", False, False,
                )
                with features_path.open(encoding="utf-8", newline="") as handle:
                    features = list(csv.DictReader(handle))

                self.assertEqual(profile["timestamp_quality"]["source_rows"], 1800)
                self.assertEqual(profile["timestamp_quality"]["sampling_gap_count"], 0)
                self.assertEqual(profile["timestamp_quality"]["duplicate_timestamp_count"], 0)
                self.assertEqual(manifest["window_count"], 6)
                self.assertEqual(manifest["feature_row_count"], expectation["features"])
                self.assertEqual(manifest["correlation_row_count"], expectation["correlations"])
                self.assertTrue(any(row["quality_status"] == "PASS" for row in features))
                self.assertTrue(any(row["quality_status"] == "INSUFFICIENT_COVERAGE" for row in features))
                self.assertTrue(any(row["spectral_status"] == "PASS" for row in features))
                self.assertTrue(any(row["reference_label_status"] == "REFERENCE_ONLY" for row in features))
            report = compact.build_report(profile_paths, feature_paths)
            self.assertIn("TS_FIELD_REPORT=TS-FIELD-REPORT-v1", report)
            self.assertIn("D|3S|ROWS:1800", report)
            self.assertIn("D|4S|ROWS:1800", report)
            self.assertIn("U:l/min", report)
            self.assertIn("U:Bar", report)
            self.assertIn("AM:CONFIRMED_BY_OWNER", report)
            self.assertRegex(report, r"RID=[a-f0-9]{12}")


if __name__ == "__main__":
    unittest.main()
