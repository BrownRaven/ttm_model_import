import csv
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

SERVER_DEPLOY = Path(__file__).resolve().parents[1]
ROOT = SERVER_DEPLOY.parent
if str(SERVER_DEPLOY) not in sys.path:
    sys.path.insert(0, str(SERVER_DEPLOY))

import anomaly_control as control
import anomaly_phase as phase

EVENTS = ROOT / "markdown" / "PIMS_우선추출_사건목록.md"
POLICY = SERVER_DEPLOY / "config" / "anomaly" / "phase_policy_v1.json"


class AnomalyControlTest(unittest.TestCase):
    def test_confirmed_control_requires_no_event_overlap_and_feature_coverage(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            phase_dir = root / "phases"
            phase.generate_phases(EVENTS, POLICY, phase_dir, None, {"CASE-001"}, False)
            controls_path = root / "controls.csv"
            self._write_controls(controls_path, [self._control(
                "CTRL-M317-001", "2024-11-20T00:00:00+09:00", "2024-11-27T00:00:00+09:00"
            )])
            feature_3s = root / "3s.csv"
            starts = pd.date_range("2024-11-20T00:00:00+09:00", periods=2016, freq="5min")
            pd.DataFrame([self._feature_row(start, "M-317", "ASN-3S-M317-MOTOR-CURRENT") for start in starts]).to_csv(feature_3s, index=False)
            feature_4s = root / "4s.csv"
            pd.DataFrame([self._feature_row(pd.Timestamp("2024-01-01T00:00:00+09:00"), "M-419", "ASN-4S-M419-MOTOR-CURRENT")]).to_csv(feature_4s, index=False)
            output = root / "validated"
            manifest = control.validate_controls(
                controls_path, phase_dir / "reference_event_phases.csv",
                {"3S": feature_3s, "4S": feature_4s}, output, 127, False,
            )
            self.assertEqual(manifest["fit_eligible_count"], 1)
            validated = pd.read_csv(output / "validated_control_intervals.csv")
            self.assertEqual(validated.loc[0, "validation_status"], "VALID_FOR_BASELINE_FIT")
            self.assertGreaterEqual(validated.loc[0, "window_coverage_ratio"], 0.99)

    def test_event_context_overlap_and_missing_coverage_block_fit(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            phase_dir = root / "phases"
            phase.generate_phases(EVENTS, POLICY, phase_dir, None, {"CASE-001"}, False)
            controls_path = root / "controls.csv"
            self._write_controls(controls_path, [self._control(
                "CTRL-M317-BLOCKED", "2025-01-01T00:00:00+09:00", "2025-01-08T00:00:00+09:00"
            )])
            output = root / "validated"
            manifest = control.validate_controls(
                controls_path, phase_dir / "reference_event_phases.csv", None, output, 100, False
            )
            self.assertEqual(manifest["fit_eligible_count"], 0)
            validated = pd.read_csv(output / "validated_control_intervals.csv")
            failures = validated.loc[0, "failure_codes"]
            self.assertIn("CONTROL_EVENT_CONTEXT_OVERLAP", failures)
            self.assertIn("CONTROL_FEATURE_COVERAGE_REQUIRED", failures)

    @staticmethod
    def _control(uid: str, start: str, end: str):
        return {
            "control_uid": uid,
            "asset_id": "M-317",
            "start_time": start,
            "end_time": end,
            "timezone": "Asia/Seoul",
            "operation_state": "RUNNING",
            "operation_state_status": "CONFIRMED_BY_OWNER",
            "maintenance_overlap_status": "NO_OVERLAP_CONFIRMED",
            "communication_status": "HEALTHY_CONFIRMED",
            "event_exclusion_status": "PENDING_VALIDATION",
            "review_status": "CONFIRMED_CONTROL",
            "reviewed_by_ref": "FIELD-REVIEW-TEST",
            "reviewed_at": "2026-08-24T10:00:00+09:00",
            "source_ref": "TEST",
            "notes": "",
        }

    @staticmethod
    def _write_controls(path: Path, rows):
        with path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=control.CONTROL_FIELDS)
            writer.writeheader()
            writer.writerows(rows)

    @staticmethod
    def _feature_row(start: pd.Timestamp, asset: str, sensor: str):
        return {
            "window_start": start.isoformat(),
            "window_end": (start + pd.Timedelta(minutes=5)).isoformat(),
            "asset_id": asset,
            "sensor_uid": sensor,
            "quality_status": "PASS",
        }


if __name__ == "__main__":
    unittest.main()
