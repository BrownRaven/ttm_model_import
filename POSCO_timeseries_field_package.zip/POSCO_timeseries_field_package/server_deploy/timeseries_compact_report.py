"""Print a short, manually transcribable field receipt from EDA/feature outputs."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Any, Sequence

REPORT_VERSION = "TS-FIELD-REPORT-v1"


def _number(value: Any) -> str:
    if value is None or value == "":
        return "NA"
    return f"{float(value):.8g}"


def _parse_scoped(values: Sequence[str]) -> dict[str, Path]:
    output = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"expected SCOPE=PATH, got {value!r}")
        scope, path = value.split("=", 1)
        output[scope.upper()] = Path(path).expanduser().resolve()
    return output


def _feature_summary(path: Path) -> dict[str, Any]:
    quality: Counter[str] = Counter()
    spectral: Counter[str] = Counter()
    references = 0
    rows = 0
    windows: set[str] = set()
    with path.open(encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            rows += 1
            quality[row["quality_status"]] += 1
            spectral[row["spectral_status"]] += 1
            references += int(row["reference_label_status"] == "REFERENCE_ONLY")
            windows.add(row["window_start"])
    return {
        "rows": rows,
        "windows": len(windows),
        "quality_pass": quality["PASS"],
        "quality_insufficient": quality["INSUFFICIENT_COVERAGE"],
        "spectral_pass": spectral["PASS"],
        "reference_rows": references,
    }


def build_report(profiles: dict[str, Path], features: dict[str, Path]) -> str:
    lines = [f"TS_FIELD_REPORT={REPORT_VERSION}"]
    runtime_written = False
    for scope in sorted(profiles):
        profile = json.loads(profiles[scope].read_text(encoding="utf-8"))
        if not runtime_written:
            runtime = profile["runtime"]
            lines.append(
                f"RUNTIME=PY:{runtime['python']}|NP:{runtime['numpy']}|PD:{runtime['pandas']}|"
                f"PT:{runtime['torch']}|CUDA:{int(runtime['cuda_available'])}|VM:{len(runtime['mismatches'])}"
            )
            runtime_written = True
        time = profile["timestamp_quality"]
        lines.append(
            f"D|{scope}|ROWS:{time['source_rows']}|VT:{time['valid_timestamp_rows']}|"
            f"IT:{time['invalid_timestamp_rows']}|DUP:{time['duplicate_timestamp_count']}|"
            f"REV:{time['reversed_timestamp_count']}|GAP:{time['sampling_gap_count']}|"
            f"EMISS:{time['estimated_missing_timestamp_count']}|FROM:{time['min_event_time']}|TO:{time['max_event_time']}|"
            f"TZ:{time.get('timezone', 'NA')}|TZS:{time.get('timezone_status', 'NA')}|"
            f"AM:{profile.get('asset_mapping_status', 'NA')}|CFG:{profile['config_sha256'][:12]}"
        )
        for sensor_uid, sensor in profile["sensors"].items():
            quantiles = sensor["approximate_quantiles"]
            lines.append(
                f"S|{scope}|{sensor_uid}|U:{sensor['unit'] or 'NA'}|N:{sensor['total_rows']}|"
                f"VR:{_number(sensor['valid_ratio'])}|MISS:{sensor['missing_count']}|NN:{sensor['non_numeric_count']}|"
                f"INF:{sensor['infinite_count']}|MIN:{_number(sensor['min'])}|P01:{_number(quantiles.get('p01'))}|"
                f"P50:{_number(quantiles.get('p50'))}|P99:{_number(quantiles.get('p99'))}|MAX:{_number(sensor['max'])}|"
                f"MEAN:{_number(sensor['mean'])}|STD:{_number(sensor['std'])}"
            )
        if scope in features:
            feature = _feature_summary(features[scope])
            lines.append(
                f"F|{scope}|W:{feature['windows']}|ROWS:{feature['rows']}|QP:{feature['quality_pass']}|"
                f"QI:{feature['quality_insufficient']}|FFT:{feature['spectral_pass']}|REF:{feature['reference_rows']}"
            )
    body = "\n".join(lines)
    return body + f"\nRID={hashlib.sha256(body.encode('utf-8')).hexdigest()[:12]}\n"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", action="append", required=True, help="SCOPE=eda_profile.json; repeatable")
    parser.add_argument("--features", action="append", default=[], help="SCOPE=features.csv; repeatable")
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    report = build_report(_parse_scoped(args.profile), _parse_scoped(args.features))
    if args.output:
        destination = args.output.expanduser().resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(report, encoding="utf-8")
    print(report, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
