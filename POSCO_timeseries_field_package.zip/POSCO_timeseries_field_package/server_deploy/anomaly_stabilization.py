"""Statsmodels-based post-event stabilization figures for field control review.

A statistical stabilization candidate is not a confirmed normal interval. Figures and
candidate rows always require operation-state, maintenance, communication, and field review.
"""

from __future__ import annotations

import json
import math
import warnings
from dataclasses import dataclass
from html import escape
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd

from anomaly_contract import (
    ANOMALY_CONTRACT_VERSION,
    ASSET_SCOPE,
    AnomalyContractError,
    canonical_sha256,
    content_identity,
    ensure_output_directory,
    file_identity,
    require,
    require_columns,
    sha256_file,
    write_json,
)
from anomaly_phase import load_phase_intervals

STABILIZATION_CONTRACT = "PIMS-ANOMALY-STABILIZATION-v1"


@dataclass(frozen=True)
class OccurrenceReview:
    occurrence_uid: str
    event_uid: str
    priority: int
    asset_id: str
    event_start: pd.Timestamp
    event_end: pd.Timestamp
    time_precision: str


def _require_statsmodels() -> tuple[Any, Any, Any]:
    try:
        import statsmodels.api as sm
        from statsmodels.tsa.stattools import adfuller, kpss
    except ImportError as exc:
        raise AnomalyContractError(
            "STATSMODELS_REQUIRED",
            "Install the approved statsmodels build in the field environment",
        ) from exc
    return sm, adfuller, kpss


def load_stabilization_policy(path: Path) -> dict[str, Any]:
    policy = json.loads(path.expanduser().resolve().read_text(encoding="utf-8"))
    require(policy.get("contract_version") == STABILIZATION_CONTRACT, "STABILIZATION_POLICY_VERSION_INVALID", str(path))
    for key in (
        "horizon_days", "minimum_post_event_buffer_hours", "stability_window_hours",
        "candidate_scan_stride_hours", "consecutive_passes", "proposed_control_days",
    ):
        require(float(policy[key]) > 0, "STABILIZATION_POLICY_VALUE_INVALID", key)
    require(0 < float(policy["minimum_hourly_coverage_ratio"]) <= 1, "STABILIZATION_COVERAGE_INVALID", "policy")
    require(0 < float(policy["minimum_sensor_consensus_ratio"]) <= 1, "STABILIZATION_CONSENSUS_INVALID", "policy")
    return policy


def occurrences_from_phases(phases: Sequence[Any]) -> list[OccurrenceReview]:
    by_occurrence: dict[str, Any] = {}
    for phase in phases:
        by_occurrence.setdefault(phase.occurrence_uid, phase)
    rows = []
    for uid, phase in by_occurrence.items():
        rows.append(OccurrenceReview(
            occurrence_uid=uid,
            event_uid=phase.event_uid,
            priority=phase.priority,
            asset_id=phase.asset_id,
            event_start=pd.Timestamp(phase.event_start).tz_convert("UTC"),
            event_end=pd.Timestamp(phase.event_end).tz_convert("UTC"),
            time_precision=phase.event_time_precision,
        ))
    return sorted(rows, key=lambda row: (row.priority, row.occurrence_uid))


def aggregate_hourly_feature_means(
    feature_files: dict[str, Path],
    occurrences: Sequence[OccurrenceReview],
    horizon_days: int,
    chunksize: int,
) -> tuple[pd.DataFrame, int]:
    grouped_chunks: list[pd.DataFrame] = []
    scanned = 0
    by_scope = {
        scope: [item for item in occurrences if ASSET_SCOPE[item.asset_id] == scope]
        for scope in feature_files
    }
    required = [
        "window_start", "window_end", "asset_id", "sensor_uid", "measurement_type",
        "unit", "quality_status", "mean",
    ]
    for scope, source in feature_files.items():
        source = source.expanduser().resolve()
        header = pd.read_csv(source, nrows=0).columns
        require_columns(header, required, "FEATURE_HEADER_INVALID")
        for chunk in pd.read_csv(source, usecols=required, chunksize=chunksize, low_memory=False):
            scanned += len(chunk)
            starts = pd.to_datetime(chunk["window_start"], errors="coerce", utc=True)
            ends = pd.to_datetime(chunk["window_end"], errors="coerce", utc=True)
            require(not starts.isna().any() and not ends.isna().any(), "FEATURE_TIME_INVALID", str(source))
            midpoints = starts + (ends - starts) / 2
            numeric = pd.to_numeric(chunk["mean"], errors="coerce")
            for occurrence in by_scope[scope]:
                horizon_end = occurrence.event_end + pd.Timedelta(days=horizon_days)
                mask = (
                    (chunk["asset_id"] == occurrence.asset_id)
                    & (midpoints >= occurrence.event_end)
                    & (midpoints < horizon_end)
                )
                if not mask.any():
                    continue
                selected = chunk.loc[mask, ["sensor_uid", "measurement_type", "unit", "quality_status"]].copy()
                selected["hour_start"] = midpoints.loc[mask].dt.floor("h")
                selected["metric_value"] = numeric.loc[mask]
                selected["valid_value"] = selected["metric_value"].notna().astype(int)
                selected["quality_pass"] = (selected["quality_status"] == "PASS").astype(int)
                selected["occurrence_uid"] = occurrence.occurrence_uid
                selected["event_uid"] = occurrence.event_uid
                selected["priority"] = occurrence.priority
                selected["asset_id"] = occurrence.asset_id
                grouped = selected.groupby(
                    ["occurrence_uid", "event_uid", "priority", "asset_id", "sensor_uid", "measurement_type", "unit", "hour_start"],
                    dropna=False, sort=False,
                ).agg(
                    metric_sum=("metric_value", "sum"),
                    metric_count=("valid_value", "sum"),
                    source_window_count=("valid_value", "size"),
                    quality_pass_count=("quality_pass", "sum"),
                ).reset_index()
                grouped_chunks.append(grouped)
    if not grouped_chunks:
        return pd.DataFrame(), scanned
    combined = pd.concat(grouped_chunks, ignore_index=True)
    keys = ["occurrence_uid", "event_uid", "priority", "asset_id", "sensor_uid", "measurement_type", "unit", "hour_start"]
    hourly = combined.groupby(keys, dropna=False, sort=False).agg(
        metric_sum=("metric_sum", "sum"),
        metric_count=("metric_count", "sum"),
        source_window_count=("source_window_count", "sum"),
        quality_pass_count=("quality_pass_count", "sum"),
    ).reset_index()
    hourly["hourly_mean"] = hourly["metric_sum"] / hourly["metric_count"].replace(0, np.nan)
    hourly["hourly_coverage_ratio"] = (hourly["source_window_count"] / 12.0).clip(upper=1.0)
    hourly["quality_pass_ratio"] = hourly["quality_pass_count"] / hourly["source_window_count"].replace(0, np.nan)
    return hourly.sort_values(["priority", "occurrence_uid", "sensor_uid", "hour_start"]), scanned


def _excluded_hours(phases: Sequence[Any], asset_id: str, start: pd.Timestamp, end: pd.Timestamp) -> pd.DatetimeIndex:
    excluded: set[pd.Timestamp] = set()
    for phase in phases:
        if phase.asset_id != asset_id:
            continue
        phase_start = pd.Timestamp(phase.start_time).tz_convert("UTC")
        phase_end = pd.Timestamp(phase.end_time).tz_convert("UTC")
        overlap_start, overlap_end = max(start, phase_start), min(end, phase_end)
        if overlap_start >= overlap_end:
            continue
        excluded.update(pd.date_range(overlap_start.floor("h"), overlap_end.ceil("h"), freq="h", inclusive="left"))
    return pd.DatetimeIndex(sorted(excluded))


def _stationarity_test(values: np.ndarray, policy: dict[str, Any]) -> dict[str, Any]:
    sm, adfuller, kpss = _require_statsmodels()
    result = {
        "ols_slope_per_hour": math.nan, "ols_slope_pvalue": math.nan,
        "adf_pvalue": math.nan, "kpss_pvalue": math.nan,
        "robust_first_last_shift": math.nan, "test_status": "NOT_EVALUABLE",
    }
    if len(values) < 12 or not np.isfinite(values).all():
        return result
    value_range = float(np.ptp(values))
    tolerance = np.finfo(np.float64).eps * max(float(np.max(np.abs(values))), 1.0) * 16
    if value_range <= tolerance:
        result["test_status"] = "CONSTANT_OPERATION_STATE_CONFIRMATION_REQUIRED"
        return result
    x = np.arange(len(values), dtype=np.float64)
    design = sm.add_constant(x)
    fit = sm.OLS(values, design).fit(cov_type="HAC", cov_kwds={"maxlags": int(policy["ols_hac_maxlags"])})
    result["ols_slope_per_hour"] = float(fit.params[1])
    result["ols_slope_pvalue"] = float(fit.pvalues[1])
    median = float(np.median(values))
    robust_scale = 1.4826 * float(np.median(np.abs(values - median)))
    if robust_scale > 0:
        half = max(1, len(values) // 4)
        result["robust_first_last_shift"] = abs(float(np.median(values[-half:]) - np.median(values[:half]))) / robust_scale
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            result["adf_pvalue"] = float(adfuller(values, autolag="AIC")[1])
        except (ValueError, np.linalg.LinAlgError):
            pass
        try:
            result["kpss_pvalue"] = float(kpss(values, regression="c", nlags="auto")[1])
        except (ValueError, np.linalg.LinAlgError, OverflowError):
            pass
    alpha = float(policy["significance_alpha"])
    flat_trend = result["ols_slope_pvalue"] >= alpha
    bounded_shift = result["robust_first_last_shift"] <= float(policy["maximum_robust_first_last_shift"])
    kpss_stationary = result["kpss_pvalue"] >= alpha
    adf_stationary = result["adf_pvalue"] <= alpha
    if flat_trend and bounded_shift and kpss_stationary and adf_stationary:
        result["test_status"] = "STRONG_STATIONARITY_CANDIDATE"
    elif flat_trend and bounded_shift and kpss_stationary:
        result["test_status"] = "PARTIAL_STATIONARITY_CANDIDATE"
    else:
        result["test_status"] = "NOT_STATIONARY_CANDIDATE"
    return result


def find_sensor_candidates(
    hourly: pd.DataFrame,
    occurrences: Sequence[OccurrenceReview],
    phases: Sequence[Any],
    policy: dict[str, Any],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    occurrence_map = {item.occurrence_uid: item for item in occurrences}
    accepted = set(policy["accepted_test_statuses"])
    stability_hours = int(policy["stability_window_hours"])
    stride = int(policy["candidate_scan_stride_hours"])
    consecutive_required = int(policy["consecutive_passes"])
    minimum_coverage = float(policy["minimum_hourly_coverage_ratio"])
    for (occurrence_uid, sensor_uid), group in hourly.groupby(["occurrence_uid", "sensor_uid"], sort=False):
        occurrence = occurrence_map[occurrence_uid]
        horizon_end = occurrence.event_end + pd.Timedelta(days=int(policy["horizon_days"]))
        index = pd.date_range(occurrence.event_end.floor("h"), horizon_end.ceil("h"), freq="h", inclusive="left")
        series = group.set_index("hour_start").reindex(index)
        excluded = set(_excluded_hours(phases, occurrence.asset_id, index[0], index[-1] + pd.Timedelta(hours=1)))
        search_start = occurrence.event_end + pd.Timedelta(hours=float(policy["minimum_post_event_buffer_hours"]))
        run: list[tuple[pd.Timestamp, float, dict[str, Any]]] = []
        chosen = None
        for candidate in pd.date_range(search_start.ceil("h"), horizon_end - pd.Timedelta(hours=stability_hours), freq=f"{stride}h"):
            segment_index = pd.date_range(candidate, periods=stability_hours, freq="h")
            if any(timestamp in excluded for timestamp in segment_index):
                run = []
                continue
            segment = series.reindex(segment_index)
            valid = segment["hourly_mean"].notna() & (segment["hourly_coverage_ratio"] >= minimum_coverage)
            coverage = float(valid.mean())
            if coverage < minimum_coverage:
                run = []
                continue
            test = _stationarity_test(segment.loc[valid, "hourly_mean"].to_numpy(dtype=np.float64), policy)
            evaluation = (candidate, coverage, test)
            if test["test_status"] in accepted:
                run.append(evaluation)
                if len(run) >= consecutive_required:
                    chosen = run[0]
                    break
            else:
                run = []
        metadata = group.iloc[0]
        test = chosen[2] if chosen else {"test_status": "NO_STABILIZATION_CANDIDATE"}
        rows.append({
            "occurrence_uid": occurrence_uid,
            "event_uid": occurrence.event_uid,
            "priority": occurrence.priority,
            "asset_id": occurrence.asset_id,
            "sensor_uid": sensor_uid,
            "measurement_type": metadata["measurement_type"],
            "unit": metadata["unit"],
            "candidate_start": chosen[0].isoformat() if chosen else None,
            "candidate_test_end": (chosen[0] + pd.Timedelta(hours=stability_hours)).isoformat() if chosen else None,
            "candidate_coverage_ratio": chosen[1] if chosen else 0.0,
            **test,
            "candidate_status": test["test_status"],
            "normality_status": "NOT_CONFIRMED_NORMAL",
            "field_review_status": "FIELD_CONFIRMATION_REQUIRED",
        })
    return pd.DataFrame(rows)


def build_asset_candidates(
    sensor_candidates: pd.DataFrame,
    hourly: pd.DataFrame,
    occurrences: Sequence[OccurrenceReview],
    phases: Sequence[Any],
    policy: dict[str, Any],
) -> pd.DataFrame:
    rows = []
    occurrence_map = {item.occurrence_uid: item for item in occurrences}
    accepted = set(policy["accepted_test_statuses"])
    proposed_days = int(policy["proposed_control_days"])
    min_consensus = float(policy["minimum_sensor_consensus_ratio"])
    min_coverage = float(policy["minimum_hourly_coverage_ratio"])
    for occurrence_uid, group in sensor_candidates.groupby("occurrence_uid", sort=False):
        occurrence = occurrence_map[occurrence_uid]
        accepted_group = group[group["candidate_status"].isin(accepted) & group["candidate_start"].notna()].copy()
        consensus = len(accepted_group) / len(group) if len(group) else 0.0
        candidate_start = pd.to_datetime(accepted_group["candidate_start"], utc=True).max() if not accepted_group.empty else pd.NaT
        candidate_end = candidate_start + pd.Timedelta(days=proposed_days) if pd.notna(candidate_start) else pd.NaT
        status = "NO_SENSOR_CONSENSUS"
        coverage = 0.0
        event_overlap = False
        if pd.notna(candidate_start) and consensus >= min_consensus:
            excluded = _excluded_hours(phases, occurrence.asset_id, candidate_start, candidate_end)
            event_overlap = len(excluded) > 0
            relevant = hourly[
                (hourly["occurrence_uid"] == occurrence_uid)
                & (hourly["hour_start"] >= candidate_start)
                & (hourly["hour_start"] < candidate_end)
            ]
            expected = proposed_days * 24 * max(1, group["sensor_uid"].nunique())
            valid = relevant[
                relevant["hourly_mean"].notna()
                & (relevant["hourly_coverage_ratio"] >= min_coverage)
            ]
            coverage = min(len(valid) / expected, 1.0)
            if event_overlap:
                status = "BLOCKED_EVENT_CONTEXT_OVERLAP"
            elif coverage < min_coverage:
                status = "BLOCKED_7D_COVERAGE"
            else:
                status = "STATISTICAL_STABILIZATION_CANDIDATE"
        rows.append({
            "occurrence_uid": occurrence_uid,
            "event_uid": occurrence.event_uid,
            "priority": occurrence.priority,
            "asset_id": occurrence.asset_id,
            "candidate_control_start": candidate_start.isoformat() if pd.notna(candidate_start) else None,
            "candidate_control_end": candidate_end.isoformat() if pd.notna(candidate_end) else None,
            "sensor_count": len(group),
            "candidate_sensor_count": len(accepted_group),
            "sensor_consensus_ratio": consensus,
            "proposed_control_coverage_ratio": coverage,
            "event_context_overlap": event_overlap,
            "candidate_status": status,
            "operation_state_status": "CONFIRMATION_REQUIRED",
            "maintenance_status": "CONFIRMATION_REQUIRED",
            "communication_status": "CONFIRMATION_REQUIRED",
            "review_status": "PROPOSED",
            "normality_status": "NOT_CONFIRMED_NORMAL",
            "online_eligible": False,
        })
    return pd.DataFrame(rows)


def render_figures(
    hourly: pd.DataFrame,
    sensor_candidates: pd.DataFrame,
    asset_candidates: pd.DataFrame,
    occurrences: Sequence[OccurrenceReview],
    phases: Sequence[Any],
    policy: dict[str, Any],
    output_dir: Path,
) -> list[Path]:
    """Render browser-openable SVG using only the Python standard library."""
    sm, _, _ = _require_statsmodels()
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    width, left, right, top, panel_height, gap = 1600, 150, 40, 125, 250, 28

    def x_position(timestamp: pd.Timestamp, start: pd.Timestamp, end: pd.Timestamp) -> float:
        ratio = (timestamp.value - start.value) / max(end.value - start.value, 1)
        return left + min(max(ratio, 0.0), 1.0) * (width - left - right)

    def polyline_segments(index: pd.DatetimeIndex, values: np.ndarray, x_start: pd.Timestamp, x_end: pd.Timestamp, y_min: float, y_max: float, panel_top: float) -> list[str]:
        segments, points = [], []
        for timestamp, value in zip(index, values):
            if not np.isfinite(value):
                if len(points) > 1:
                    segments.append(" ".join(points))
                points = []
                continue
            x = x_position(pd.Timestamp(timestamp), x_start, x_end)
            y = panel_top + panel_height - 35 - (float(value) - y_min) / max(y_max - y_min, 1e-12) * (panel_height - 70)
            points.append(f"{x:.2f},{y:.2f}")
        if len(points) > 1:
            segments.append(" ".join(points))
        return segments

    for occurrence in occurrences:
        data = hourly[hourly["occurrence_uid"] == occurrence.occurrence_uid]
        sensors = sorted(data["sensor_uid"].unique())
        if not sensors:
            continue
        height = top + len(sensors) * (panel_height + gap) + 70
        x_start = pd.Timestamp(data["hour_start"].min())
        x_end = pd.Timestamp(data["hour_start"].max()) + pd.Timedelta(hours=1)
        asset_row = asset_candidates[asset_candidates["occurrence_uid"] == occurrence.occurrence_uid].iloc[0]
        svg = [
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
            '<rect width="100%" height="100%" fill="white"/>',
            '<style>text{font-family:Arial,"Malgun Gothic","Noto Sans KR",sans-serif;fill:#172033}.small{font-size:12px}.axis{stroke:#cbd5e1;stroke-width:1}.grid{stroke:#e2e8f0;stroke-width:1}.raw{fill:none;stroke:#94a3b8;stroke-width:1}.smooth{fill:none;stroke:#2563eb;stroke-width:2}</style>',
            f'<text x="{left}" y="30" font-size="20" font-weight="bold">{escape(occurrence.occurrence_uid)} / {escape(occurrence.asset_id)} — 통계적 안정화 후보 (현장 정상 확인 필요)</text>',
            f'<text x="{left}" y="55" font-size="13">Status: {escape(str(asset_row["candidate_status"]))} | Time precision: {escape(occurrence.time_precision)} | 정상 확정 아님</text>',
            '<text x="150" y="82" class="small">회색: 시간별 Feature mean</text>',
            '<text x="370" y="82" class="small" fill="#2563eb">파랑: Statsmodels LOWESS</text>',
            '<text x="610" y="82" class="small" fill="#dc2626">빨강: 사건 종료</text>',
            '<text x="780" y="82" class="small" fill="#f59e0b">주황: 센서 안정화 후보</text>',
            '<text x="1040" y="82" class="small" fill="#16a34a">녹색: 제안 7일 대조구간</text>',
        ]
        relevant_phases = [phase for phase in phases if phase.asset_id == occurrence.asset_id]
        for panel_index, sensor_uid in enumerate(sensors):
            panel_top = top + panel_index * (panel_height + gap)
            plot_top, plot_bottom = panel_top + 30, panel_top + panel_height - 35
            svg.extend([
                f'<rect x="{left}" y="{plot_top}" width="{width-left-right}" height="{plot_bottom-plot_top}" fill="#ffffff" stroke="#cbd5e1"/>',
                f'<text x="{left}" y="{panel_top+18}" font-size="13" font-weight="bold">{escape(sensor_uid)}</text>',
            ])
            sensor = data[data["sensor_uid"] == sensor_uid].sort_values("hour_start")
            full_index = pd.date_range(sensor["hour_start"].min(), sensor["hour_start"].max(), freq="h")
            series = sensor.set_index("hour_start")["hourly_mean"].reindex(full_index)
            finite = series.dropna()
            if finite.empty:
                continue
            y_min, y_max = float(finite.min()), float(finite.max())
            padding = max((y_max - y_min) * 0.08, abs(y_max) * 0.001, 1e-9)
            y_min, y_max = y_min - padding, y_max + padding
            for tick_index in range(5):
                y = plot_top + tick_index * (plot_bottom - plot_top) / 4
                value = y_max - tick_index * (y_max - y_min) / 4
                svg.append(f'<line x1="{left}" y1="{y:.2f}" x2="{width-right}" y2="{y:.2f}" class="grid"/>')
                svg.append(f'<text x="{left-8}" y="{y+4:.2f}" text-anchor="end" class="small">{value:.5g}</text>')
            for tick_index in range(6):
                timestamp = x_start + (x_end - x_start) * tick_index / 5
                x = x_position(timestamp, x_start, x_end)
                svg.append(f'<line x1="{x:.2f}" y1="{plot_top}" x2="{x:.2f}" y2="{plot_bottom}" class="grid"/>')
                if panel_index == len(sensors) - 1:
                    svg.append(f'<text x="{x:.2f}" y="{plot_bottom+20}" text-anchor="middle" class="small">{timestamp.strftime("%Y-%m-%d")}</text>')
            for phase in relevant_phases:
                phase_start = pd.Timestamp(phase.start_time).tz_convert("UTC")
                phase_end = pd.Timestamp(phase.end_time).tz_convert("UTC")
                overlap_start, overlap_end = max(x_start, phase_start), min(x_end, phase_end)
                if overlap_start < overlap_end:
                    x1, x2 = x_position(overlap_start, x_start, x_end), x_position(overlap_end, x_start, x_end)
                    svg.append(f'<rect x="{x1:.2f}" y="{plot_top}" width="{max(x2-x1,1):.2f}" height="{plot_bottom-plot_top}" fill="#fecaca" opacity="0.18"/>')
            if pd.notna(asset_row["candidate_control_start"]):
                control_start = pd.Timestamp(asset_row["candidate_control_start"])
                control_end = pd.Timestamp(asset_row["candidate_control_end"])
                x1, x2 = x_position(control_start, x_start, x_end), x_position(control_end, x_start, x_end)
                svg.append(f'<rect x="{x1:.2f}" y="{plot_top}" width="{max(x2-x1,1):.2f}" height="{plot_bottom-plot_top}" fill="#22c55e" opacity="0.14"/>')
            for points in polyline_segments(full_index, series.to_numpy(dtype=float), x_start, x_end, y_min, y_max, panel_top):
                svg.append(f'<polyline points="{points}" class="raw"/>')
            if len(finite) >= 8:
                smooth = sm.nonparametric.lowess(finite.to_numpy(), np.arange(len(finite)), frac=float(policy["lowess_fraction"]), return_sorted=False)
                for points in polyline_segments(pd.DatetimeIndex(finite.index), np.asarray(smooth), x_start, x_end, y_min, y_max, panel_top):
                    svg.append(f'<polyline points="{points}" class="smooth"/>')
            event_x = x_position(occurrence.event_end, x_start, x_end)
            svg.append(f'<line x1="{event_x:.2f}" y1="{plot_top}" x2="{event_x:.2f}" y2="{plot_bottom}" stroke="#dc2626" stroke-width="2" stroke-dasharray="7 4"/>')
            candidate = sensor_candidates[(sensor_candidates["occurrence_uid"] == occurrence.occurrence_uid) & (sensor_candidates["sensor_uid"] == sensor_uid)]
            if not candidate.empty and pd.notna(candidate.iloc[0]["candidate_start"]):
                candidate_x = x_position(pd.Timestamp(candidate.iloc[0]["candidate_start"]), x_start, x_end)
                svg.append(f'<line x1="{candidate_x:.2f}" y1="{plot_top}" x2="{candidate_x:.2f}" y2="{plot_bottom}" stroke="#f59e0b" stroke-width="2" stroke-dasharray="3 4"/>')
            unit = escape(str(sensor.iloc[0]["unit"]))
            svg.append(f'<text x="25" y="{(plot_top+plot_bottom)/2:.2f}" class="small">{unit}</text>')
        svg.append(f'<text x="{left}" y="{height-22}" font-size="12">STATISTICAL_STABILIZATION_CANDIDATE ≠ CONFIRMED_CONTROL. 운전상태·정비·통신상태 현장 확인 필수.</text>')
        svg.append('</svg>')
        path = output_dir / f"{occurrence.priority:02d}_{occurrence.occurrence_uid}_{occurrence.asset_id}.svg"
        path.write_text("\n".join(svg) + "\n", encoding="utf-8")
        paths.append(path)
    return paths


def run_stabilization_review(
    phases_path: Path,
    features_3s: Path,
    features_4s: Path,
    policy_path: Path,
    output_dir: Path,
    chunksize: int,
    overwrite: bool,
) -> dict[str, Any]:
    output = ensure_output_directory(output_dir, overwrite)
    policy = load_stabilization_policy(policy_path)
    phases = load_phase_intervals(phases_path)
    occurrences = occurrences_from_phases(phases)
    feature_files = {"3S": features_3s.expanduser().resolve(), "4S": features_4s.expanduser().resolve()}
    hourly, scanned = aggregate_hourly_feature_means(
        feature_files, occurrences, int(policy["horizon_days"]), chunksize
    )
    require(not hourly.empty, "STABILIZATION_DATA_EMPTY", "No post-event Feature rows")
    hourly_path = output / "stabilization_hourly_features.csv"
    hourly.to_csv(hourly_path, index=False)
    sensor_candidates = find_sensor_candidates(hourly, occurrences, phases, policy)
    sensor_path = output / "sensor_stabilization_candidates.csv"
    sensor_candidates.to_csv(sensor_path, index=False)
    asset_candidates = build_asset_candidates(sensor_candidates, hourly, occurrences, phases, policy)
    asset_path = output / "proposed_control_candidates.csv"
    asset_candidates.to_csv(asset_path, index=False)
    figures = render_figures(hourly, sensor_candidates, asset_candidates, occurrences, phases, policy, output / "figures")
    try:
        import statsmodels
        versions = {"statsmodels": statsmodels.__version__, "figure_renderer": "STDLIB_SVG-v1"}
    except ImportError:
        versions = {}
    payload = {
        "contract_version": ANOMALY_CONTRACT_VERSION,
        "stabilization_contract_version": STABILIZATION_CONTRACT,
        "phases_source": content_identity(phases_path),
        "policy_source": content_identity(policy_path),
        "feature_sources": {scope: file_identity(path, include_sha256=False) for scope, path in feature_files.items()},
        "runtime_versions": versions,
        "source_rows_scanned": scanned,
        "hourly_rows": len(hourly),
        "occurrence_count": len(occurrences),
        "sensor_candidate_count": int(sensor_candidates["candidate_start"].notna().sum()),
        "proposed_control_candidate_count": int((asset_candidates["candidate_status"] == "STATISTICAL_STABILIZATION_CANDIDATE").sum()),
        "figure_count": len(figures),
        "outputs": {
            "hourly_sha256": sha256_file(hourly_path),
            "sensor_candidates_sha256": sha256_file(sensor_path),
            "asset_candidates_sha256": sha256_file(asset_path),
            "figure_sha256": {path.name: sha256_file(path) for path in figures},
        },
        "safety": policy["safety"],
    }
    receipt = canonical_sha256(payload)
    manifest = {**payload, "receipt_sha256": receipt}
    write_json(output / "stabilization_manifest.json", manifest)
    compact = (
        f"ANOMALY_STABILIZATION=VALID|OCCURRENCES:{len(occurrences)}|SCANNED:{scanned}|"
        f"HOURLY:{len(hourly)}|SENSOR_CAND:{payload['sensor_candidate_count']}|"
        f"CONTROL_CAND:{payload['proposed_control_candidate_count']}|FIG:{len(figures)}|SHA:{receipt}\n"
    )
    (output / "stabilization_receipt.txt").write_text(compact, encoding="utf-8")
    return manifest
