"""Cross-platform field launcher for Synthetic smoke and actual-file EDA/features."""

from __future__ import annotations

import argparse
import csv
import hashlib
import multiprocessing as mp
import os
from concurrent.futures import ProcessPoolExecutor
import json
import tempfile
from pathlib import Path
from typing import Any, Sequence

from timeseries_compact_report import build_report
from timeseries_pipeline import (
    BUILD_VERSION,
    CONTRACT_VERSION,
    discover_files,
    extract_features,
    load_config,
    run_eda,
    runtime_versions,
    validate_headers,
    validate_single_input_format,
    validate_timestamp_samples,
)
from timeseries_synthetic import generate

SERVER_DEPLOY = Path(__file__).resolve().parent
CONFIG_3S = SERVER_DEPLOY / "config" / "timeseries" / "sinter3_wide_1s.json"
CONFIG_4S = SERVER_DEPLOY / "config" / "timeseries" / "sinter4_wide_1s.json"


def _smoke_receipt(root: Path, runtime: dict[str, Any], manifests: dict[str, dict[str, Any]], synthetic: dict[str, Any]) -> str:
    source = {item["dataset"]: item for item in synthetic["datasets"]}
    lines = [
        f"TS_SMOKE=VALID|CONTRACT={CONTRACT_VERSION}|BUILD={BUILD_VERSION}",
        f"RUNTIME=PY:{runtime['python']}|NP:{runtime['numpy']}|PD:{runtime['pandas']}|"
        f"PT:{runtime['torch']}|PA:{runtime['pyarrow']}|CUDA:{int(runtime['cuda_available'])}|"
        f"VM:{len(runtime['mismatches'])}",
    ]
    for scope in ("3S", "4S"):
        manifest = manifests[scope]
        expected_correlations = 216 if scope == "3S" else 120
        with (root / f"{scope}-features.csv").open(encoding="utf-8", newline="") as handle:
            feature_rows = list(csv.DictReader(handle))
        feature_contract_valid = (
            any(row["quality_status"] == "PASS" for row in feature_rows)
            and any(row["spectral_status"] == "PASS" for row in feature_rows)
            and any(row["reference_label_status"] == "REFERENCE_ONLY" for row in feature_rows)
        )
        if manifest["window_count"] != 6 or manifest["correlation_row_count"] != expected_correlations or not feature_contract_valid:
            raise RuntimeError(f"{scope} smoke contract mismatch: {manifest}")
        lines.append(
            f"{scope}=R:1800|S:{13 if scope == '3S' else 10}|W:{manifest['window_count']}|"
            f"F:{manifest['feature_row_count']}|C:{manifest['correlation_row_count']}|FFT:1|AC:1|REF:1|"
            f"SHA:{source[scope]['sha256'][:12]}|CFG:{source[scope]['config_sha256'][:12]}"
        )
    lines.append("SAFE=SYNTHETIC_ONLY:1|ACTUAL_VALUES:0|PROD:0|TRAIN:0|THRESHOLD:0")
    body = "\n".join(lines)
    return body + f"\nRID={hashlib.sha256(body.encode('utf-8')).hexdigest()[:12]}\n"


def run_smoke(strict_versions: bool, keep_output: Path | None) -> str:
    runtime = runtime_versions(strict_versions)
    temporary = None
    if keep_output is None:
        temporary = tempfile.TemporaryDirectory(prefix="posco-timeseries-smoke-")
        root = Path(temporary.name)
    else:
        root = keep_output.expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
    try:
        input_dir = root / "input"
        synthetic = generate(input_dir)
        manifests = {}
        for scope, config_path in (("3S", CONFIG_3S), ("4S", CONFIG_4S)):
            config = load_config(config_path)
            item = next(value for value in synthetic["datasets"] if value["dataset"] == scope)
            source = input_dir / item["csv_file"]
            events = input_dir / item["reference_events_file"]
            validate_headers([source], config)
            validate_timestamp_samples([source], config)
            run_eda([source], config, root / f"{scope}-eda", 317, 500, True, False)
            manifests[scope] = extract_features(
                [source], config, root / f"{scope}-features.csv", root / f"{scope}-correlations.csv",
                events, 317, "cpu", True, False,
            )
        receipt = _smoke_receipt(root, runtime, manifests, synthetic)
        if keep_output is not None:
            (root / "field_receipt.txt").write_text(receipt, encoding="utf-8")
        return receipt
    finally:
        if temporary is not None:
            temporary.cleanup()


def _run_eda_task(
    files: Sequence[Path],
    config_path: Path,
    eda_dir: Path,
    chunksize: int,
    reservoir_size: int,
    overwrite: bool,
    hash_inputs: bool,
) -> None:
    run_eda(
        files, load_config(config_path), eda_dir, chunksize,
        reservoir_size, overwrite, hash_inputs,
    )


def run_field(args: argparse.Namespace) -> str:
    runtime_versions(args.strict_versions)
    output = args.output.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    if args.workers < 1 or args.workers > 4:
        raise ValueError("--workers must be between 1 and 4 for the field package")
    if "TIMESERIES_ARROW_THREADS" not in os.environ:
        arrow_threads = max(1, args.workers // 2) if args.parallel_scopes else args.workers
        os.environ["TIMESERIES_ARROW_THREADS"] = str(min(arrow_threads, 4))
    profiles: dict[str, Path] = {}
    feature_outputs: dict[str, Path] = {}
    jobs = []
    for scope, config_path, patterns, events in (
        ("3S", CONFIG_3S, args.input_3s, args.events_3s),
        ("4S", CONFIG_4S, args.input_4s, args.events_4s),
    ):
        config = load_config(config_path)
        files = discover_files(patterns)
        validate_single_input_format(files)
        validate_headers(files, config)
        validate_timestamp_samples(files, config)
        eda_dir = output / f"{scope}-eda"
        profiles[scope] = eda_dir / "eda_profile.json"
        jobs.append((scope, config_path, config, files, events, eda_dir))

    if args.parallel_scopes:
        with ProcessPoolExecutor(max_workers=2, mp_context=mp.get_context("spawn")) as executor:
            futures = [
                executor.submit(
                    _run_eda_task, files, config_path, eda_dir, args.chunksize,
                    args.reservoir_size, args.overwrite, args.hash_inputs,
                )
                for _, config_path, _, files, _, eda_dir in jobs
            ]
            for future in futures:
                future.result()
    else:
        for _, _, config, files, _, eda_dir in jobs:
            run_eda(
                files, config, eda_dir, args.chunksize, args.reservoir_size,
                args.overwrite, args.hash_inputs,
            )

    if args.features:
        for scope, _, config, files, events, _ in jobs:
            feature_path = output / f"{scope}-features.csv"
            extract_features(
                files, config, feature_path, output / f"{scope}-correlations.csv",
                events, args.chunksize, args.device, args.overwrite, args.hash_inputs, args.workers,
            )
            feature_outputs[scope] = feature_path
    report = build_report(profiles, feature_outputs)
    (output / "field_report.txt").write_text(report, encoding="utf-8")
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    smoke = commands.add_parser("smoke")
    smoke.add_argument("--strict-versions", action="store_true")
    smoke.add_argument("--keep-output", type=Path)

    field = commands.add_parser("field")
    field.add_argument("--input-3s", action="append", required=True, help="File or glob; repeatable")
    field.add_argument("--input-4s", action="append", required=True, help="File or glob; repeatable")
    field.add_argument("--output", type=Path, required=True)
    field.add_argument("--events-3s", type=Path)
    field.add_argument("--events-4s", type=Path)
    field.add_argument("--features", action="store_true")
    field.add_argument("--device", default="auto")
    field.add_argument("--workers", type=int, default=1, help="Feature CPU workers; maximum/recommended: 4")
    field.add_argument(
        "--parallel-scopes", action="store_true",
        help="Run 3S and 4S EDA concurrently in two processes; useful when storage bandwidth permits",
    )
    field.add_argument("--chunksize", type=int, default=250_000)
    field.add_argument("--reservoir-size", type=int, default=200_000)
    field.add_argument("--strict-versions", action=argparse.BooleanOptionalAction, default=True)
    field.add_argument("--overwrite", action="store_true")
    field.add_argument("--hash-inputs", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    report = run_smoke(args.strict_versions, args.keep_output) if args.command == "smoke" else run_field(args)
    print(report, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
